//
//  PayPathApp.swift
//  PayPath
//
//  Created by Vansh Chawla on 19/07/2025.
//

import SwiftUI

@main
struct PayPathApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
