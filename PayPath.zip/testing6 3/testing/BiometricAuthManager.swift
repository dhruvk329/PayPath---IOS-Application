import LocalAuthentication
import SwiftUI

class BiometricAuthManager: ObservableObject {
    @Published var isAuthenticated = false
    @Published var canUseBiometrics = false
    @Published var biometricType: LABiometryType = .none
    @Published var authenticationError: String?
    
    init() {
        checkBiometricAvailability()
    }
    
    func checkBiometricAvailability() {
        let context = LAContext()
        var error: NSError?
        
        canUseBiometrics = context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)
        biometricType = context.biometryType
        
        print("🔐 Biometric availability check:")
        print("   Can use biometrics: \(canUseBiometrics)")
        print("   Biometric type: \(biometricType)")
        
        if let error = error {
            print("   Error: \(error.localizedDescription)")
            authenticationError = error.localizedDescription
        }
    }
    
    func authenticateWithBiometrics() async -> Bool {
        print("🔐 Starting biometric authentication...")
        
        guard canUseBiometrics else {
            print("❌ Biometrics not available")
            await MainActor.run {
                authenticationError = "Biometric authentication not available"
                isAuthenticated = false
            }
            return false
        }
        
        let context = LAContext()
        context.localizedCancelTitle = "Cancel"
        context.localizedFallbackTitle = "Use Passcode"
        
        do {
            print("🔐 Evaluating biometric policy...")
            let result = try await context.evaluatePolicy(
                .deviceOwnerAuthenticationWithBiometrics,
                localizedReason: "Authenticate to access your loan tracker"
            )
            
            print("✅ Biometric authentication result: \(result)")
            
            await MainActor.run {
                isAuthenticated = result
                authenticationError = nil
            }
            
            return result
        } catch {
            print("❌ Biometric authentication error: \(error)")
            
            await MainActor.run {
                isAuthenticated = false
                
                // Handle all possible errors
                if let laError = error as? LAError {
                    print("   LAError code: \(laError.code.rawValue)")
                    switch laError.code {
                    case .biometryNotAvailable:
                        authenticationError = "Biometric authentication is not available"
                    case .biometryNotEnrolled:
                        authenticationError = "No biometric data enrolled"
                    case .biometryLockout:
                        authenticationError = "Biometric authentication is locked. Use passcode to unlock"
                    case .userCancel:
                        authenticationError = "Authentication cancelled"
                    case .userFallback:
                        authenticationError = "User chose to use passcode"
                    case .systemCancel:
                        authenticationError = "Authentication cancelled by system"
                    case .passcodeNotSet:
                        authenticationError = "Passcode not set on device"
                    case .touchIDNotAvailable:
                        authenticationError = "Touch ID not available"
                    case .touchIDNotEnrolled:
                        authenticationError = "Touch ID not enrolled"
                    case .touchIDLockout:
                        authenticationError = "Touch ID is locked"
                    case .invalidContext:
                        authenticationError = "Invalid authentication context"
                    case .notInteractive:
                        authenticationError = "Authentication not interactive"
                    case .appCancel:
                        authenticationError = "Authentication cancelled by app"
                    default:
                        authenticationError = "Authentication failed: \(laError.localizedDescription)"
                    }
                } else {
                    // Handle any other type of error
                    authenticationError = "Authentication failed: \(error.localizedDescription)"
                }
            }
            return false
        }
    }
    
    func authenticateWithPasscode() async -> Bool {
        print("🔐 Starting passcode authentication...")
        
        let context = LAContext()
        
        do {
            let result = try await context.evaluatePolicy(
                .deviceOwnerAuthentication,
                localizedReason: "Authenticate to access your loan tracker"
            )
            
            print("✅ Passcode authentication result: \(result)")
            
            await MainActor.run {
                isAuthenticated = result
                authenticationError = nil
            }
            
            return result
        } catch {
            print("❌ Passcode authentication error: \(error)")
            
            await MainActor.run {
                isAuthenticated = false
                
                // Handle all possible errors for passcode authentication
                if let laError = error as? LAError {
                    switch laError.code {
                    case .userCancel:
                        authenticationError = "Authentication cancelled"
                    case .systemCancel:
                        authenticationError = "Authentication cancelled by system"
                    case .passcodeNotSet:
                        authenticationError = "Passcode not set on device"
                    case .invalidContext:
                        authenticationError = "Invalid authentication context"
                    case .notInteractive:
                        authenticationError = "Authentication not interactive"
                    case .appCancel:
                        authenticationError = "Authentication cancelled by app"
                    default:
                        authenticationError = "Passcode authentication failed: \(laError.localizedDescription)"
                    }
                } else {
                    authenticationError = "Passcode authentication failed: \(error.localizedDescription)"
                }
            }
            return false
        }
    }
    
    var biometricTypeString: String {
        switch biometricType {
        case .faceID:
            return "Face ID"
        case .touchID:
            return "Touch ID"
        case .opticID:
            return "Optic ID"
        default:
            return "Biometric Authentication"
        }
    }
    
    var biometricIcon: String {
        switch biometricType {
        case .faceID:
            return "faceid"
        case .touchID:
            return "touchid"
        case .opticID:
            return "opticid"
        default:
            return "person.badge.key"
        }
    }
}
