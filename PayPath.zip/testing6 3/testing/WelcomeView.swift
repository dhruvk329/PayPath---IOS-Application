import SwiftUI

struct WelcomeView: View {
    @State private var showContent = false
    @State private var animateBackground = false
    @State private var animateLogo = false
    @State private var showSwipeHint = false
    @State private var dragOffset = CGSize.zero
    @Environment(\.colorScheme) var colorScheme
    
    let onSwipeUp: () -> Void
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Dynamic animated background
                Group {
                    if colorScheme == .dark {
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color(red: 0.05, green: 0.05, blue: 0.15),
                                Color(red: 0.1, green: 0.1, blue: 0.25),
                                Color(red: 0.15, green: 0.2, blue: 0.35),
                                Color(red: 0.1, green: 0.15, blue: 0.3)
                            ]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    } else {
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color(red: 0.95, green: 0.97, blue: 1.0),
                                Color(red: 0.9, green: 0.95, blue: 1.0),
                                Color(red: 0.85, green: 0.9, blue: 0.98),
                                Color(red: 0.9, green: 0.92, blue: 0.99)
                            ]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    }
                }
                .ignoresSafeArea()
                .scaleEffect(animateBackground ? 1.05 : 1.0)
                .animation(.easeInOut(duration: 8).repeatForever(autoreverses: true), value: animateBackground)
                
                // Floating background elements
                ForEach(0..<12, id: \.self) { index in
                    let colors: [Color] = colorScheme == .dark ?
                        [Color.blue.opacity(0.15), Color.purple.opacity(0.12), Color.cyan.opacity(0.1), Color.pink.opacity(0.08)] :
                        [Color.blue.opacity(0.08), Color.purple.opacity(0.06), Color.pink.opacity(0.04), Color.cyan.opacity(0.05)]
                    
                    Circle()
                        .fill(
                            RadialGradient(
                                gradient: Gradient(colors: [colors[index % 4], Color.clear]),
                                center: .center,
                                startRadius: 20,
                                endRadius: 80
                            )
                        )
                        .frame(width: CGFloat.random(in: 100...200))
                        .position(
                            x: CGFloat.random(in: 0...geometry.size.width),
                            y: CGFloat.random(in: 0...geometry.size.height)
                        )
                        .blur(radius: 3)
                        .scaleEffect(animateBackground ? 1.3 : 0.7)
                        .animation(
                            .easeInOut(duration: Double.random(in: 4...8))
                            .repeatForever(autoreverses: true)
                            .delay(Double(index) * 0.3),
                            value: animateBackground
                        )
                }
                
                // Main content
                VStack(spacing: 0) {
                    Spacer()
                    
                    // Logo and title section
                    VStack(spacing: 30) {
                        // Animated logo with multiple rings
                        ZStack {
                            // Outer pulsing ring
                            Circle()
                                .stroke(
                                    LinearGradient(
                                        gradient: Gradient(colors: [
                                            Color.blue.opacity(0.4),
                                            Color.purple.opacity(0.4),
                                            Color.cyan.opacity(0.3),
                                            Color.blue.opacity(0.4)
                                        ]),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ),
                                    lineWidth: 4
                                )
                                .frame(width: 180, height: 180)
                                .scaleEffect(animateLogo ? 1.2 : 1.0)
                                .opacity(animateLogo ? 0.6 : 0.3)
                                .animation(.easeInOut(duration: 3).repeatForever(autoreverses: true), value: animateLogo)
                            
                            // Middle ring
                            Circle()
                                .stroke(
                                    LinearGradient(
                                        gradient: Gradient(colors: [
                                            Color.purple.opacity(0.5),
                                            Color.blue.opacity(0.5),
                                            Color.pink.opacity(0.4)
                                        ]),
                                        startPoint: .topTrailing,
                                        endPoint: .bottomLeading
                                    ),
                                    lineWidth: 3
                                )
                                .frame(width: 150, height: 150)
                                .scaleEffect(animateLogo ? 1.1 : 0.9)
                                .opacity(animateLogo ? 0.8 : 0.5)
                                .animation(.easeInOut(duration: 2.5).repeatForever(autoreverses: true).delay(0.5), value: animateLogo)
                            
                            // Main logo background
                            Circle()
                                .fill(
                                    LinearGradient(
                                        gradient: Gradient(colors: [
                                            Color.blue,
                                            Color.purple,
                                            Color.blue.opacity(0.8),
                                            Color.cyan
                                        ]),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 120, height: 120)
                                .shadow(
                                    color: colorScheme == .dark ? Color.blue.opacity(0.5) : Color.blue.opacity(0.4),
                                    radius: 25,
                                    x: 0,
                                    y: 15
                                )
                                .scaleEffect(animateLogo ? 1.08 : 1.0)
                                .animation(.easeInOut(duration: 4).repeatForever(autoreverses: true).delay(1), value: animateLogo)
                            
                            // Logo icon
                            Image(systemName: "dollarsign.circle.fill")
                                .font(.system(size: 65, weight: .medium))
                                .foregroundColor(.white)
                                .rotationEffect(.degrees(animateLogo ? 10 : -10))
                                .scaleEffect(animateLogo ? 1.1 : 0.9)
                                .animation(.easeInOut(duration: 5).repeatForever(autoreverses: true).delay(1.5), value: animateLogo)
                        }
                        .opacity(showContent ? 1 : 0)
                        .scaleEffect(showContent ? 1 : 0.5)
                        .animation(.spring(response: 1.2, dampingFraction: 0.6).delay(0.3), value: showContent)
                        
                        // Title and subtitle
                        VStack(spacing: 15) {
                            Text("Welcome to")
                                .font(.system(size: 28, weight: .medium, design: .rounded))
                                .foregroundColor(colorScheme == .dark ? .white.opacity(0.8) : .gray.opacity(0.8))
                                .opacity(showContent ? 1 : 0)
                                .offset(y: showContent ? 0 : 30)
                                .animation(.spring(response: 1.0, dampingFraction: 0.7).delay(0.8), value: showContent)
                            
                            Text("PayPath")
                                .font(.system(size: 48, weight: .bold, design: .rounded))
                                .foregroundStyle(
                                    LinearGradient(
                                        gradient: Gradient(colors: [
                                            Color.blue,
                                            Color.purple,
                                            Color.cyan,
                                            Color.blue.opacity(0.8)
                                        ]),
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                )
                                .scaleEffect(animateLogo ? 1.05 : 1.0)
                                .animation(.easeInOut(duration: 3).repeatForever(autoreverses: true).delay(2), value: animateLogo)
                                .opacity(showContent ? 1 : 0)
                                .offset(y: showContent ? 0 : 50)
                                .animation(.spring(response: 1.2, dampingFraction: 0.6).delay(1.0), value: showContent)
                            
                            Text("Your smart loan tracking companion")
                                .font(.title3)
                                .fontWeight(.medium)
                                .foregroundColor(colorScheme == .dark ? .white.opacity(0.7) : .gray.opacity(0.7))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 40)
                                .opacity(showContent ? 1 : 0)
                                .offset(y: showContent ? 0 : 30)
                                .animation(.spring(response: 1.0, dampingFraction: 0.7).delay(1.2), value: showContent)
                        }
                    }
                    
                    Spacer()
                    
                    // Swipe instruction section
                    VStack(spacing: 25) {
                        // Animated swipe indicator
                        VStack(spacing: 15) {
                            Image(systemName: "arrow.up")
                                .font(.system(size: 32, weight: .medium))
                                .foregroundColor(colorScheme == .dark ? .white : .blue)
                                .offset(y: showSwipeHint ? -15 : 0)
                                .opacity(showSwipeHint ? 1.0 : 0.6)
                                .animation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true), value: showSwipeHint)
                            
                            Text("Swipe up to begin")
                                .font(.title2)
                                .fontWeight(.semibold)
                                .foregroundColor(colorScheme == .dark ? .white : .primary)
                        }
                        .opacity(showContent ? 1 : 0)
                        .offset(y: showContent ? 0 : 40)
                        .animation(.spring(response: 1.0, dampingFraction: 0.7).delay(1.8), value: showContent)
                        
                        // Feature highlights
                        VStack(spacing: 12) {
                            FeatureRow(icon: "shield.checkered", text: "Secure & Private", colorScheme: colorScheme)
                            FeatureRow(icon: "chart.line.uptrend.xyaxis", text: "Smart Analytics", colorScheme: colorScheme)
                            FeatureRow(icon: "bell.badge", text: "Payment Reminders", colorScheme: colorScheme)
                        }
                        .opacity(showContent ? 1 : 0)
                        .offset(y: showContent ? 0 : 30)
                        .animation(.spring(response: 1.0, dampingFraction: 0.7).delay(2.0), value: showContent)
                    }
                    .padding(.horizontal, 40)
                    
                    Spacer()
                    
                    // Bottom indicator dots
                    HStack(spacing: 8) {
                        ForEach(0..<5, id: \.self) { index in
                            Circle()
                                .fill(
                                    LinearGradient(
                                        gradient: Gradient(colors: [
                                            Color.blue.opacity(0.6),
                                            Color.purple.opacity(0.6)
                                        ]),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 8, height: 8)
                                .scaleEffect(showSwipeHint ? 1.3 : 0.8)
                                .animation(
                                    .easeInOut(duration: 1.2)
                                    .repeatForever(autoreverses: true)
                                    .delay(Double(index) * 0.2),
                                    value: showSwipeHint
                                )
                        }
                    }
                    .opacity(showContent ? 1 : 0)
                    .animation(.spring(response: 1.0, dampingFraction: 0.7).delay(2.2), value: showContent)
                    .padding(.bottom, 60)
                }
                .offset(dragOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            dragOffset = value.translation
                        }
                        .onEnded { value in
                            handleSwipeGesture(value: value)
                        }
                )
                .animation(.spring(response: 0.6, dampingFraction: 0.8), value: dragOffset)
            }
        }
        .onAppear {
            startAnimations()
        }
    }
    
    private func startAnimations() {
        animateBackground = true
        animateLogo = true
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            showContent = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            showSwipeHint = true
        }
    }
    
    private func handleSwipeGesture(value: DragGesture.Value) {
        let swipeThreshold: CGFloat = 100
        
        withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
            if value.translation.height < -swipeThreshold {
                // Swipe up detected
                onSwipeUp()
            }
            dragOffset = .zero
        }
    }
}

struct FeatureRow: View {
    let icon: String
    let text: String
    let colorScheme: ColorScheme
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(colorScheme == .dark ? .cyan : .blue)
                .frame(width: 24)
            
            Text(text)
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.8) : .gray.opacity(0.8))
            
            Spacer()
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(
                    colorScheme == .dark ?
                    Color.white.opacity(0.05) :
                    Color.white.opacity(0.7)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    colorScheme == .dark ? Color.white.opacity(0.1) : Color.blue.opacity(0.1),
                                    colorScheme == .dark ? Color.blue.opacity(0.2) : Color.purple.opacity(0.1)
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
    }
}

#Preview("Light Mode") {
    WelcomeView(onSwipeUp: {})
        .preferredColorScheme(.light)
}

#Preview("Dark Mode") {
    WelcomeView(onSwipeUp: {})
        .preferredColorScheme(.dark)
}
