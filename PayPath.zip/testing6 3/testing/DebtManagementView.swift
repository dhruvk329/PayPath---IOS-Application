import SwiftUI

struct DebtManagementView: View {
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var totalAmount = ""
    @State private var interestRate = ""
    @State private var loanTerm = ""
    @State private var monthlyPayment = ""
    @State private var showingResults = false
    @State private var animateElements = false
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 25) {
                    // Header Section
                    headerSection
                    
                    // Input Form
                    VStack(spacing: 20) {
                        DebtFormField(
                            title: "Total Loan Amount",
                            text: $totalAmount,
                            placeholder: "25000",
                            currencySymbol: userDataManager.getCurrencySymbol(),
                            icon: "dollarsign.circle",
                            color: Color.green,
                            delay: 0.4
                        )
                        
                        DebtFormField(
                            title: "Interest Rate (%)",
                            text: $interestRate,
                            placeholder: "5.5",
                            currencySymbol: "%",
                            icon: "percent",
                            color: Color.blue,
                            delay: 0.5
                        )
                        
                        DebtFormField(
                            title: "Loan Term (Years)",
                            text: $loanTerm,
                            placeholder: "5",
                            currencySymbol: "yrs",
                            icon: "calendar",
                            color: Color.purple,
                            delay: 0.6
                        )
                        
                        // Calculate Button
                        calculateButton
                        
                        // Results Section
                        if showingResults {
                            resultsSection
                        }
                    }
                    .padding(25)
                    .background(cardBackground)
                    .scaleEffect(animateElements ? 1.0 : 0.9)
                    .opacity(animateElements ? 1.0 : 0.0)
                    .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.2), value: animateElements)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
            }
            .navigationTitle("Debt Management")
            .navigationBarTitleDisplayMode(.large)
        }
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                animateElements = true
            }
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 15) {
            ZStack {
                Circle()
                    .fill(LinearGradient(
                        gradient: Gradient(colors: [Color.red, Color.orange]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                    .frame(width: 80, height: 80)
                    .shadow(color: Color.red.opacity(0.3), radius: 10, x: 0, y: 5)
                
                Image(systemName: "chart.line.downtrend.xyaxis")
                    .font(.system(size: 35, weight: .bold))
                    .foregroundColor(.white)
            }
            .scaleEffect(animateElements ? 1.0 : 0.8)
            .animation(.spring(response: 0.8, dampingFraction: 0.6), value: animateElements)
            
            VStack(spacing: 5) {
                Text("Debt Calculator")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                Text("Calculate your monthly payments and total interest")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .opacity(animateElements ? 1.0 : 0.0)
            .animation(.easeInOut(duration: 0.8).delay(0.3), value: animateElements)
        }
    }
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(.ultraThinMaterial)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(cardGradient)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(borderGradient, lineWidth: 1)
            )
            .shadow(color: shadowColor, radius: 15, x: 0, y: 8)
    }
    
    private var cardGradient: LinearGradient {
        if colorScheme == .dark {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.black.opacity(0.3),
                    Color.gray.opacity(0.1)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.white.opacity(0.8),
                    Color.red.opacity(0.05)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    private var borderGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.red.opacity(0.3),
                Color.orange.opacity(0.2),
                Color.red.opacity(0.1)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var shadowColor: Color {
        colorScheme == .dark ? Color.white.opacity(0.1) : Color.black.opacity(0.1)
    }
    
    private var calculateButton: some View {
        Button(action: calculatePayment) {
            HStack(spacing: 12) {
                Image(systemName: "calculator.fill")
                    .font(.system(size: 18, weight: .semibold))
                
                Text("Calculate Payment")
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 55)
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color.red, Color.orange]),
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .cornerRadius(15)
            .shadow(color: Color.red.opacity(0.3), radius: 10, x: 0, y: 5)
        }
        .disabled(totalAmount.isEmpty || interestRate.isEmpty || loanTerm.isEmpty)
        .opacity(animateElements ? 1.0 : 0.0)
        .offset(y: animateElements ? 0 : 30)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.7), value: animateElements)
    }
    
    private var resultsSection: some View {
        VStack(spacing: 15) {
            Text("Calculation Results")
                .font(.headline)
                .fontWeight(.bold)
                .foregroundColor(.primary)
            
            VStack(spacing: 12) {
                ResultRow(
                    title: "Monthly Payment",
                    value: "\(userDataManager.getCurrencySymbol())\(monthlyPayment)",
                    color: Color.green
                )
                
                if let principal = Double(totalAmount),
                   let rate = Double(interestRate),
                   let term = Double(loanTerm) {
                    let totalPayments = principal * (1 + (rate / 100) * term)
                    let totalInterest = totalPayments - principal
                    
                    ResultRow(
                        title: "Total Interest",
                        value: "\(userDataManager.getCurrencySymbol())\(String(format: "%.2f", totalInterest))",
                        color: Color.orange
                    )
                    
                    ResultRow(
                        title: "Total Amount",
                        value: "\(userDataManager.getCurrencySymbol())\(String(format: "%.2f", totalPayments))",
                        color: Color.red
                    )
                }
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 15)
                .fill(Color(.systemGray6))
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(Color.green.opacity(0.3), lineWidth: 1)
                )
        )
        .transition(.scale.combined(with: .opacity))
    }
    
    private func calculatePayment() {
        guard let principal = Double(totalAmount),
              let rate = Double(interestRate),
              let term = Double(loanTerm) else {
            return
        }
        
        let monthlyRate = rate / 100 / 12
        let numberOfPayments = term * 12
        
        let payment = principal * (monthlyRate * pow(1 + monthlyRate, numberOfPayments)) / (pow(1 + monthlyRate, numberOfPayments) - 1)
        
        monthlyPayment = String(format: "%.2f", payment)
        
        withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
            showingResults = true
        }
    }
}

struct DebtFormField: View {
    let title: String
    @Binding var text: String
    let placeholder: String
    let currencySymbol: String
    let icon: String
    let color: Color
    let delay: Double
    
    @State private var isAnimated = false
    @FocusState private var isFocused: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)
                .foregroundColor(.primary)
            
            HStack(spacing: 15) {
                ZStack {
                    Circle()
                        .fill(LinearGradient(
                            gradient: Gradient(colors: [color, color.opacity(0.7)]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                        .frame(width: 40, height: 40)
                    
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.white)
                }
                
                TextField(placeholder, text: $text)
                    .textFieldStyle(PlainTextFieldStyle())
                    .keyboardType(.decimalPad)
                    .focused($isFocused)
                
                Text(currencySymbol)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .fontWeight(.medium)
            }
            .padding(15)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(isFocused ? color : Color.clear, lineWidth: 2)
                    )
            )
            .scaleEffect(isFocused ? 1.02 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isFocused)
        }
        .opacity(isAnimated ? 1.0 : 0.0)
        .offset(x: isAnimated ? 0 : -30)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(delay), value: isAnimated)
        .onAppear {
            isAnimated = true
        }
    }
}

struct ResultRow: View {
    let title: String
    let value: String
    let color: Color
    
    var body: some View {
        HStack {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
            
            Text(value)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(color)
        }
        .padding(.vertical, 5)
    }
}

#Preview {
    DebtManagementView()
        .environmentObject(UserDataManager())
}
