import SwiftUI

struct AddLoanView: View {
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var loanName = ""
    @State private var totalAmount = ""
    @State private var interestRate = ""
    @State private var monthlyPayment = ""
    @State private var outstandingPrincipal = ""
    @State private var dueDate = 1
    @State private var selectedLoanType = LoanData.LoanType.personal
    @State private var startDate = Date()
    @State private var endDate = Calendar.current.date(byAdding: .year, value: 1, to: Date()) ?? Date()
    @State private var hasDefault = false
    @State private var penaltyAmount = ""
    @State private var showingSuccessAlert = false
    @State private var animateElements = false
    @State private var selectedMode: ViewMode = .add
    @State private var editingLoan: LoanData?
    @State private var showingDeleteAlert = false
    @State private var loanToDelete: LoanData?
    @Environment(\.colorScheme) var colorScheme
    @FocusState private var focusedField: FormField?
    
    enum ViewMode: String, CaseIterable {
        case add = "Add"
        case view = "View"
    }
    
    enum FormField: Hashable {
        case loanName, totalAmount, interestRate, monthlyPayment, outstandingPrincipal, penaltyAmount
    }
    
    // Computed property for currency symbol (system default)
    private var currencySymbol: String {
        userDataManager.getCurrencySymbol()
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundGradient
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    modeSelector
                        .opacity(animateElements ? 1.0 : 0.0)
                        .offset(y: animateElements ? 0 : -20)
                        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.1), value: animateElements)
                    
                    if selectedMode == .add {
                        addLoanContent
                    } else {
                        viewLoansContent
                    }
                }
            }
            .navigationTitle("Loan Manager")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                    animateElements = true
                }
            }
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Done") {
                        focusedField = nil
                    }
                    .foregroundColor(.blue)
                    .fontWeight(.semibold)
                }
            }
            .onTapGesture {
                focusedField = nil
            }
        }
        .alert("Success!", isPresented: $showingSuccessAlert) {
            Button("OK") {
                clearForm()
            }
        } message: {
            Text(editingLoan != nil ? "Your loan has been updated successfully!" : "Your loan has been added successfully!")
        }
        .alert("Delete Loan", isPresented: $showingDeleteAlert) {
            Button("Cancel", role: .cancel) { }
            Button("Delete", role: .destructive) {
                if let loan = loanToDelete {
                    deleteLoan(loan)
                }
            }
        } message: {
            Text("Are you sure you want to delete this loan? This action cannot be undone.")
        }
        .sheet(item: $editingLoan) { loan in
            EditLoanSheet(loan: loan) { updatedLoan in
                userDataManager.updateLoan(updatedLoan)
                editingLoan = nil
            }
        }
    }
    
    private var backgroundGradient: LinearGradient {
        if colorScheme == .dark {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.black,
                    Color(red: 0.05, green: 0.05, blue: 0.1),
                    Color(red: 0.1, green: 0.1, blue: 0.15)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.98, green: 0.99, blue: 1.0),
                    Color(red: 0.95, green: 0.97, blue: 0.99),
                    Color(red: 0.92, green: 0.95, blue: 0.98)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    private var modeSelector: some View {
        VStack(spacing: 16) {
            HStack {
                ForEach(ViewMode.allCases, id: \.self) { mode in
                    modeSelectorButton(for: mode)
                }
            }
            .padding(.horizontal)
            .padding(.top)
            
            Divider()
                .background(Color.blue.opacity(0.2))
        }
        .background(modeSelectorBackground)
        .padding(.horizontal)
    }
    
    private func modeSelectorButton(for mode: ViewMode) -> some View {
        Button(action: {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                selectedMode = mode
                focusedField = nil
            }
        }) {
            HStack(spacing: 8) {
                Image(systemName: mode == .add ? "plus.circle.fill" : "list.bullet.rectangle.fill")
                    .font(.system(size: 16, weight: .medium))
                
                Text(mode.rawValue)
                    .font(.subheadline)
                    .fontWeight(.semibold)
            }
            .foregroundColor(selectedMode == mode ? .white : .primary)
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            .background(modeSelectorButtonBackground(for: mode))
            .overlay(modeSelectorButtonOverlay(for: mode))
            .shadow(color: selectedMode == mode ? Color.blue.opacity(0.3) : Color.clear, radius: 8, x: 0, y: 4)
            .scaleEffect(selectedMode == mode ? 1.05 : 1.0)
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    private func modeSelectorButtonBackground(for mode: ViewMode) -> some View {
        RoundedRectangle(cornerRadius: 25)
            .fill(selectedMode == mode ?
                  LinearGradient(
                    gradient: Gradient(colors: [Color.blue, Color.cyan]),
                    startPoint: .leading,
                    endPoint: .trailing
                  ) :
                  LinearGradient(
                    gradient: Gradient(colors: [Color.clear]),
                    startPoint: .leading,
                    endPoint: .trailing
                  )
            )
    }
    
    private func modeSelectorButtonOverlay(for mode: ViewMode) -> some View {
        RoundedRectangle(cornerRadius: 25)
            .stroke(selectedMode == mode ? Color.clear : Color.blue.opacity(0.3), lineWidth: 1)
    }
    
    private var modeSelectorBackground: some View {
        RoundedRectangle(cornerRadius: 20, style: .continuous)
            .fill(.ultraThinMaterial)
            .shadow(color: colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
    }
    
    private var addLoanContent: some View {
        ScrollView {
            VStack(spacing: 25) {
                headerSection
                    .opacity(animateElements ? 1.0 : 0.0)
                    .offset(y: animateElements ? 0 : -30)
                    .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.2), value: animateElements)
                
                VStack(spacing: 20) {
                    loanNameField
                    loanTypeSection
                    totalAmountField
                    outstandingPrincipalField
                    interestRateField
                    monthlyPaymentField
                    dueDateSection
                    startDateSection
                    endDateSection
                    defaultSection
                }
                
                addButton
                    .opacity(animateElements ? 1.0 : 0.0)
                    .offset(y: animateElements ? 0 : 30)
                    .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(1.3), value: animateElements)
                
                Spacer(minLength: 50)
            }
            .padding()
        }
    }
    
    private var viewLoansContent: some View {
        ScrollView {
            VStack(spacing: 20) {
                if userDataManager.loans.isEmpty {
                    emptyLoansView
                        .opacity(animateElements ? 1.0 : 0.0)
                        .scaleEffect(animateElements ? 1.0 : 0.9)
                        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.3), value: animateElements)
                } else {
                    loansListView
                        .opacity(animateElements ? 1.0 : 0.0)
                        .offset(y: animateElements ? 0 : 30)
                        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.3), value: animateElements)
                }
            }
            .padding()
        }
    }
    
    private var loansListView: some View {
        VStack(spacing: 16) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Your Loans")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("\(userDataManager.loans.count) loan\(userDataManager.loans.count == 1 ? "" : "s")")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                // Total remaining amount
                VStack(alignment: .trailing, spacing: 4) {
                    Text("Total Remaining")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Text(formatCurrency(totalRemainingAmount))
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                }
            }
            .padding(.horizontal, 4)
            
            // Loans List
            LazyVStack(spacing: 12) {
                ForEach(Array(userDataManager.loans.enumerated()), id: \.element.id) { index, loan in
                    LoanListRowView(
                        loan: loan,
                        onEdit: { editingLoan = loan },
                        onDelete: {
                            loanToDelete = loan
                            showingDeleteAlert = true
                        }
                    )
                    .opacity(animateElements ? 1.0 : 0.0)
                    .offset(x: animateElements ? 0 : (index % 2 == 0 ? -100 : 100))
                    .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(Double(index) * 0.1 + 0.4), value: animateElements)
                }
            }
        }
    }
    
    private var totalRemainingAmount: Double {
        userDataManager.loans.reduce(0) { $0 + $1.remainingAmount }
    }
    
    private var emptyLoansView: some View {
        VStack(spacing: 25) {
            emptyStateIcon
            emptyStateText
            switchToAddButton
        }
        .padding(40)
        .background(cardBackground)
    }
    
    private var emptyStateIcon: some View {
        ZStack {
            Circle()
                .fill(Color.gray.opacity(0.1))
                .frame(width: 100, height: 100)
            
            Image(systemName: "list.bullet.rectangle")
                .font(.system(size: 50))
                .foregroundColor(.gray)
        }
    }
    
    private var emptyStateText: some View {
        VStack(spacing: 12) {
            Text("No Loans Added Yet")
                .font(.title2)
                .fontWeight(.bold)
            
            Text("Switch to Add mode to create your first loan")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
    }
    
    private var switchToAddButton: some View {
        Button("Switch to Add Mode") {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                selectedMode = .add
            }
        }
        .font(.subheadline)
        .fontWeight(.medium)
        .foregroundColor(.blue)
        .padding(.horizontal, 20)
        .padding(.vertical, 10)
        .background(Color.blue.opacity(0.1))
        .cornerRadius(20)
    }
    
    // MARK: - Add Loan Form Components
    
    private var loanNameField: some View {
        VStack(alignment: .leading, spacing: 12) {
            fieldTitle("Loan Name")
            loanNameTextField
        }
        .padding(20)
        .background(cardBackground)
        .opacity(animateElements ? 1.0 : 0.0)
        .offset(x: animateElements ? 0 : -50)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.3), value: animateElements)
    }
    
    private var loanNameTextField: some View {
        TextField("e.g., Car Loan, Credit Card", text: $loanName)
            .textFieldStyle(PlainTextFieldStyle())
            .padding(15)
            .background(textFieldBackground(.loanName))
            .focused($focusedField, equals: .loanName)
            .onSubmit { focusedField = nil }
            .scaleEffect(focusedField == .loanName ? 1.02 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: focusedField == .loanName)
    }
    
    private var totalAmountField: some View {
        VStack(alignment: .leading, spacing: 12) {
            fieldTitle("Total Loan Amount")
            totalAmountTextField
        }
        .padding(20)
        .background(currencyFieldBackground)
        .opacity(animateElements ? 1.0 : 0.0)
        .offset(x: animateElements ? 0 : 50)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.5), value: animateElements)
    }
    
    private var totalAmountTextField: some View {
        HStack {
            Text(currencySymbol)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(.primary)
                .frame(width: 20)
            
            TextField("25000", text: $totalAmount)
                .keyboardType(.decimalPad)
                .textFieldStyle(PlainTextFieldStyle())
                .focused($focusedField, equals: .totalAmount)
                .onSubmit { focusedField = nil }
        }
        .padding(15)
        .background(textFieldBackground(.totalAmount))
        .scaleEffect(focusedField == .totalAmount ? 1.02 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: focusedField == .totalAmount)
    }
    
    private var outstandingPrincipalField: some View {
        VStack(alignment: .leading, spacing: 12) {
            fieldTitle("Outstanding Principal")
            outstandingPrincipalTextField
        }
        .padding(20)
        .background(currencyFieldBackground)
        .opacity(animateElements ? 1.0 : 0.0)
        .offset(x: animateElements ? 0 : -50)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.55), value: animateElements)
    }
    
    private var outstandingPrincipalTextField: some View {
        HStack {
            Text(currencySymbol)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(.primary)
                .frame(width: 20)
            
            TextField("20000", text: $outstandingPrincipal)
                .keyboardType(.decimalPad)
                .textFieldStyle(PlainTextFieldStyle())
                .focused($focusedField, equals: .outstandingPrincipal)
                .onSubmit { focusedField = nil }
        }
        .padding(15)
        .background(textFieldBackground(.outstandingPrincipal))
        .scaleEffect(focusedField == .outstandingPrincipal ? 1.02 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: focusedField == .outstandingPrincipal)
    }
    
    private var interestRateField: some View {
        VStack(alignment: .leading, spacing: 12) {
            fieldTitle("Interest Rate (%)")
            interestRateTextField
        }
        .padding(20)
        .background(cardBackground)
        .opacity(animateElements ? 1.0 : 0.0)
        .offset(x: animateElements ? 0 : 50)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.6), value: animateElements)
    }
    
    private var interestRateTextField: some View {
        TextField("5.5", text: $interestRate)
            .textFieldStyle(PlainTextFieldStyle())
            .keyboardType(.decimalPad)
            .padding(15)
            .background(textFieldBackground(.interestRate))
            .focused($focusedField, equals: .interestRate)
            .onSubmit { focusedField = nil }
            .scaleEffect(focusedField == .interestRate ? 1.02 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: focusedField == .interestRate)
    }
    
    private var monthlyPaymentField: some View {
        VStack(alignment: .leading, spacing: 12) {
            fieldTitle("Monthly Payment Amount")
            monthlyPaymentTextField
        }
        .padding(20)
        .background(currencyFieldBackground)
        .opacity(animateElements ? 1.0 : 0.0)
        .offset(x: animateElements ? 0 : -50)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.7), value: animateElements)
    }

    private var monthlyPaymentTextField: some View {
        HStack {
            Text(currencySymbol)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(.primary)
                .frame(width: 20)
            
            TextField("500", text: $monthlyPayment)
                .keyboardType(.decimalPad)
                .textFieldStyle(PlainTextFieldStyle())
                .focused($focusedField, equals: .monthlyPayment)
                .onSubmit { focusedField = nil }
        }
        .padding(15)
        .background(textFieldBackground(.monthlyPayment))
        .scaleEffect(focusedField == .monthlyPayment ? 1.02 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: focusedField == .monthlyPayment)
    }
    
    private var defaultSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            fieldTitle("Default Status")
            
            VStack(spacing: 16) {
                Toggle("Has Default", isOn: $hasDefault)
                    .toggleStyle(SwitchToggleStyle(tint: .red))
                
                if hasDefault {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Penalty Amount")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        HStack {
                            Text(currencySymbol)
                                .font(.system(size: 16, weight: .medium))
                                .foregroundColor(.primary)
                                .frame(width: 20)
                            
                            TextField("100", text: $penaltyAmount)
                                .keyboardType(.decimalPad)
                                .textFieldStyle(PlainTextFieldStyle())
                                .focused($focusedField, equals: .penaltyAmount)
                                .onSubmit { focusedField = nil }
                        }
                        .padding(15)
                        .background(textFieldBackground(.penaltyAmount))
                        .scaleEffect(focusedField == .penaltyAmount ? 1.02 : 1.0)
                        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: focusedField == .penaltyAmount)
                    }
                }
            }
        }
        .padding(20)
        .background(defaultFieldBackground)
        .opacity(animateElements ? 1.0 : 0.0)
        .offset(x: animateElements ? 0 : 50)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(1.1), value: animateElements)
    }
    
    private func fieldTitle(_ title: String) -> some View {
        Text(title)
            .font(.subheadline)
            .fontWeight(.medium)
    }
    
    private func textFieldBackground(_ field: FormField) -> some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(.ultraThinMaterial)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(focusedField == field ? Color.blue : Color.clear, lineWidth: 2)
            )
    }
    
    private var headerSection: some View {
        VStack(spacing: 15) {
            headerIcon
            headerText
        }
    }
    
    private var headerIcon: some View {
        ZStack {
            Circle()
                .fill(LinearGradient(
                    gradient: Gradient(colors: [Color.blue, Color.cyan]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ))
                .frame(width: 80, height: 80)
                .shadow(color: Color.blue.opacity(0.3), radius: 15, x: 0, y: 8)
            
            Image(systemName: "plus.circle.fill")
                .font(.system(size: 35))
                .foregroundColor(.white)
        }
    }
    
    private var headerText: some View {
        VStack(spacing: 8) {
            Text("Add New Loan")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundStyle(LinearGradient(
                    gradient: Gradient(colors: [Color.blue, Color.cyan]),
                    startPoint: .leading,
                    endPoint: .trailing
                ))
            
            Text("Enter your loan details below")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            currencyIndicator
        }
    }
    
    private var currencyIndicator: some View {
        HStack {
            Image(systemName: "banknote")
                .foregroundColor(.blue)
            Text("Currency: \(Locale.current.currencyCode ?? "USD")")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(.top, 4)
    }
    
    private var loanTypeSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            fieldTitle("Loan Type")
            loanTypePicker
        }
        .padding(20)
        .background(cardBackground)
        .opacity(animateElements ? 1.0 : 0.0)
        .offset(x: animateElements ? 0 : -50)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.4), value: animateElements)
    }
    
    private var loanTypePicker: some View {
        Picker("Loan Type", selection: $selectedLoanType) {
            ForEach(LoanData.LoanType.allCases, id: \.self) { type in
                HStack {
                    Image(systemName: type.icon)
                    Text(type.rawValue)
                }
                .tag(type)
            }
        }
        .pickerStyle(MenuPickerStyle())
        .padding(15)
        .background(loanTypePickerBackground)
    }
    
    private var loanTypePickerBackground: some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(.ultraThinMaterial)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.purple.opacity(0.3), lineWidth: 1)
            )
    }
    
    private var dueDateSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            fieldTitle("Monthly Due Date")
            dueDatePicker
        }
        .padding(20)
        .background(cardBackground)
        .opacity(animateElements ? 1.0 : 0.0)
        .offset(x: animateElements ? 0 : 50)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.9), value: animateElements)
    }
    
    private var dueDatePicker: some View {
        Picker("Due Date", selection: $dueDate) {
            ForEach(1...31, id: \.self) { day in
                Text("\(day)\(getOrdinalSuffix(day))").tag(day)
            }
        }
        .pickerStyle(WheelPickerStyle())
        .frame(height: 100)
        .background(dueDatePickerBackground)
    }
    
    private var dueDatePickerBackground: some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(.ultraThinMaterial)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.indigo.opacity(0.3), lineWidth: 1)
            )
    }
    
    private var startDateSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            fieldTitle("Loan Start Date")
            startDatePicker
        }
        .padding(20)
        .background(cardBackground)
        .opacity(animateElements ? 1.0 : 0.0)
        .offset(x: animateElements ? 0 : -50)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(1.0), value: animateElements)
    }
    
    private var startDatePicker: some View {
        DatePicker("Start Date", selection: $startDate, displayedComponents: .date)
            .datePickerStyle(CompactDatePickerStyle())
            .padding(15)
            .background(startDatePickerBackground)
    }
    
    private var startDatePickerBackground: some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(.ultraThinMaterial)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.pink.opacity(0.3), lineWidth: 1)
            )
    }
    
    private var endDateSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            fieldTitle("Loan End Date")
            endDatePicker
        }
        .padding(20)
        .background(cardBackground)
        .opacity(animateElements ? 1.0 : 0.0)
        .offset(x: animateElements ? 0 : 50)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(1.1), value: animateElements)
    }
    
    private var endDatePicker: some View {
        DatePicker("End Date", selection: $endDate, in: startDate..., displayedComponents: .date)
            .datePickerStyle(CompactDatePickerStyle())
            .padding(15)
            .background(endDatePickerBackground)
    }
    
    private var endDatePickerBackground: some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(.ultraThinMaterial)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.teal.opacity(0.3), lineWidth: 1)
            )
    }
    
    private var addButton: some View {
        Button("Add Loan") {
            addLoan()
        }
        .font(.headline)
        .fontWeight(.semibold)
        .foregroundColor(.white)
        .frame(maxWidth: .infinity)
        .frame(height: 55)
        .background(addButtonBackground)
        .cornerRadius(15)
        .shadow(color: isFormValid ? Color.blue.opacity(0.3) : Color.clear, radius: 10, x: 0, y: 5)
        .disabled(!isFormValid)
        .scaleEffect(isFormValid ? 1.0 : 0.95)
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isFormValid)
    }
    
    private var addButtonBackground: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: isFormValid ? [Color.blue, Color.cyan] : [Color.gray, Color.gray]),
            startPoint: .leading,
            endPoint: .trailing
        )
    }
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(.ultraThinMaterial)
            .background(cardBackgroundGradient)
            .overlay(cardBackgroundStroke)
            .shadow(color: colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1), radius: 15, x: 0, y: 8)
    }
    
    private var currencyFieldBackground: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(.ultraThinMaterial)
            .background(currencyBackgroundGradient)
            .overlay(currencyBackgroundStroke)
            .shadow(color: colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1), radius: 15, x: 0, y: 8)
    }
    
    private var defaultFieldBackground: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(.ultraThinMaterial)
            .background(defaultBackgroundGradient)
            .overlay(defaultBackgroundStroke)
            .shadow(color: colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1), radius: 15, x: 0, y: 8)
    }
    
    private var cardBackgroundGradient: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(LinearGradient(
                gradient: Gradient(colors: [
                    Color.blue.opacity(0.05),
                    Color.purple.opacity(0.03)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ))
    }
    
    private var currencyBackgroundGradient: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(LinearGradient(
                gradient: Gradient(colors: [
                    Color.green.opacity(0.05),
                    Color.mint.opacity(0.03)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ))
    }
    
    private var defaultBackgroundGradient: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(LinearGradient(
                gradient: Gradient(colors: [
                    Color.red.opacity(0.05),
                    Color.orange.opacity(0.03)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ))
    }
    
    private var cardBackgroundStroke: some View {
        RoundedRectangle(cornerRadius: 20)
            .stroke(Color.blue.opacity(0.2), lineWidth: 1)
    }
    
    private var currencyBackgroundStroke: some View {
        RoundedRectangle(cornerRadius: 20)
            .stroke(Color.green.opacity(0.2), lineWidth: 1)
    }
    
    private var defaultBackgroundStroke: some View {
        RoundedRectangle(cornerRadius: 20)
            .stroke(Color.red.opacity(0.2), lineWidth: 1)
    }
    
    private var isFormValid: Bool {
        !loanName.isEmpty &&
        !totalAmount.isEmpty &&
        !interestRate.isEmpty &&
        !monthlyPayment.isEmpty &&
        !outstandingPrincipal.isEmpty &&
        Double(totalAmount) != nil &&
        Double(interestRate) != nil &&
        Double(monthlyPayment) != nil &&
        Double(outstandingPrincipal) != nil &&
        (!hasDefault || !penaltyAmount.isEmpty) &&
        (!hasDefault || Double(penaltyAmount) != nil)
    }
    
    private func addLoan() {
        guard let total = Double(totalAmount),
              let interest = Double(interestRate),
              let monthly = Double(monthlyPayment),
              let outstanding = Double(outstandingPrincipal) else {
            return
        }
        
        let penalty = hasDefault ? (Double(penaltyAmount) ?? 0.0) : 0.0
        
        let newLoan = LoanData(
            name: loanName,
            totalAmount: total,
            remainingAmount: outstanding, // Use outstanding principal as remaining amount
            interestRate: interest,
            firstEMI: monthly,
            lastEMI: monthly,
            dueDate: dueDate,
            startDate: startDate,
            endDate: endDate,
            loanType: selectedLoanType,
            hasDefault: hasDefault,
            penaltyAmount: penalty
        )
        
        userDataManager.addLoan(newLoan)
        showingSuccessAlert = true
        focusedField = nil
    }
    
    private func deleteLoan(_ loan: LoanData) {
        withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
            userDataManager.deleteLoan(loan)
        }
        loanToDelete = nil
    }
    
    private func clearForm() {
        loanName = ""
        totalAmount = ""
        interestRate = ""
        monthlyPayment = ""
        outstandingPrincipal = ""
        dueDate = 1
        selectedLoanType = .personal
        startDate = Date()
        endDate = Calendar.current.date(byAdding: .year, value: 1, to: Date()) ?? Date()
        hasDefault = false
        penaltyAmount = ""
        focusedField = nil
    }
    
    private func getOrdinalSuffix(_ number: Int) -> String {
        switch number {
        case 1, 21, 31: return "st"
        case 2, 22: return "nd"
        case 3, 23: return "rd"
        default: return "th"
        }
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
}

// MARK: - Loan List Row View
struct LoanListRowView: View {
    let loan: LoanData
    let onEdit: () -> Void
    let onDelete: () -> Void
    @State private var showingDetail = false
    @State private var isPressed = false
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject var userDataManager: UserDataManager
    
    private var progressPercentage: Double {
        guard loan.totalAmount > 0 else { return 0 }
        return (loan.totalAmount - loan.remainingAmount) / loan.totalAmount
    }
    
    var body: some View {
        Button(action: {
            showingDetail = true
        }) {
            HStack(spacing: 16) {
                // Loan Type Icon
                loanTypeIcon
                
                // Loan Info
                VStack(alignment: .leading, spacing: 8) {
                    loanHeader
                    progressSection
                    amountInfo
                }
                
                Spacer()
                
                // Action Buttons
                actionButtons
            }
            .padding(20)
            .background(rowBackground)
            .scaleEffect(isPressed ? 0.98 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isPressed)
        }
        .buttonStyle(PlainButtonStyle())
        .onLongPressGesture(minimumDuration: 0) {
            // Handle press
        } onPressingChanged: { pressing in
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                isPressed = pressing
            }
        }
        .sheet(isPresented: $showingDetail) {
            LoanDetailView(loan: loan)
        }
    }
    
    private var loanTypeIcon: some View {
        ZStack {
            Circle()
                .fill(LinearGradient(
                    gradient: Gradient(colors: loan.hasDefault ? [Color.red, Color.orange] : [Color.blue, Color.cyan]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ))
                .frame(width: 50, height: 50)
                .shadow(color: (loan.hasDefault ? Color.red : Color.blue).opacity(0.3), radius: 8, x: 0, y: 4)
            
            Image(systemName: loan.hasDefault ? "exclamationmark.triangle.fill" : loan.loanType.icon)
                .font(.system(size: 20, weight: .medium))
                .foregroundColor(.white)
        }
    }
    
    private var loanHeader: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(loan.name)
                    .font(.headline)
                    .fontWeight(.semibold)
                    .lineLimit(1)
                
                HStack {
                    Text(loan.loanType.rawValue)
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    if loan.hasDefault {
                        Text("• DEFAULT")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(.red)
                    }
                }
            }
            
            Spacer()
            
            Text("\(Int(progressPercentage * 100))% paid")
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.green)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(Color.green.opacity(0.1))
                .cornerRadius(8)
        }
    }
    
    private var progressSection: some View {
        VStack(spacing: 4) {
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 4)
                        .fill(Color.gray.opacity(0.2))
                        .frame(height: 6)
                    
                    RoundedRectangle(cornerRadius: 4)
                        .fill(LinearGradient(
                            gradient: Gradient(colors: loan.hasDefault ? [Color.red, Color.orange] : [Color.blue, Color.cyan]),
                            startPoint: .leading,
                            endPoint: .trailing
                        ))
                        .frame(width: geometry.size.width * progressPercentage, height: 6)
                        .animation(.spring(response: 0.8, dampingFraction: 0.7), value: progressPercentage)
                }
            }
            .frame(height: 6)
        }
    }
    
    private var amountInfo: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("Remaining")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                
                Text(formatCurrency(loan.remainingAmount))
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.red)
            }
            
            Spacer()
            
            VStack(alignment: .trailing, spacing: 2) {
                Text("Monthly")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                
                Text(formatCurrency(loan.monthlyPayment))
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.green)
            }
            
            Spacer()
            
            VStack(alignment: .trailing, spacing: 2) {
                Text("Due \(loan.dueDate)\(getOrdinalSuffix(loan.dueDate))")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                
                Text("\(String(format: "%.1f", loan.interestRate))%")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.orange)
            }
        }
    }
    
    private var actionButtons: some View {
        VStack(spacing: 8) {
            Button(action: onEdit) {
                Image(systemName: "pencil")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.blue)
                    .frame(width: 32, height: 32)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(8)
            }
            .buttonStyle(PlainButtonStyle())
            
            Button(action: onDelete) {
                Image(systemName: "trash")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.red)
                    .frame(width: 32, height: 32)
                    .background(Color.red.opacity(0.1))
                    .cornerRadius(8)
            }
            .buttonStyle(PlainButtonStyle())
        }
    }
    
    private var rowBackground: some View {
        RoundedRectangle(cornerRadius: 16)
            .fill(.ultraThinMaterial)
            .background(rowBackgroundGradient)
            .overlay(rowBackgroundStroke)
            .shadow(color: colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
    }
    
    private var rowBackgroundGradient: some View {
        RoundedRectangle(cornerRadius: 16)
            .fill(LinearGradient(
                gradient: Gradient(colors: [
                    Color.blue.opacity(0.03),
                    Color.purple.opacity(0.02)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ))
    }
    
    private var rowBackgroundStroke: some View {
        RoundedRectangle(cornerRadius: 16)
            .stroke(Color.blue.opacity(0.15), lineWidth: 1)
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
    
    private func getOrdinalSuffix(_ number: Int) -> String {
        switch number {
        case 1, 21, 31: return "st"
        case 2, 22: return "nd"
        case 3, 23: return "rd"
        default: return "th"
        }
    }
}

// MARK: - Edit Loan Sheet
struct EditLoanSheet: View {
    let loan: LoanData
    let onSave: (LoanData) -> Void
    
    @State private var loanName: String
    @State private var totalAmount: String
    @State private var remainingAmount: String
    @State private var interestRate: String
    @State private var monthlyPayment: String
    @State private var dueDate: Int
    @State private var selectedLoanType: LoanData.LoanType
    @State private var startDate: Date
    @State private var endDate: Date
    @State private var hasDefault: Bool
    @State private var penaltyAmount: String
    
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject var userDataManager: UserDataManager
    
    init(loan: LoanData, onSave: @escaping (LoanData) -> Void) {
        self.loan = loan
        self.onSave = onSave
        
        _loanName = State(initialValue: loan.name)
        _totalAmount = State(initialValue: String(loan.totalAmount))
        _remainingAmount = State(initialValue: String(loan.remainingAmount))
        _interestRate = State(initialValue: String(loan.interestRate))
        _monthlyPayment = State(initialValue: String(loan.firstEMI))
        _dueDate = State(initialValue: loan.dueDate)
        _selectedLoanType = State(initialValue: loan.loanType)
        _startDate = State(initialValue: loan.startDate)
        _endDate = State(initialValue: loan.endDate)
        _hasDefault = State(initialValue: loan.hasDefault)
        _penaltyAmount = State(initialValue: String(loan.penaltyAmount))
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // Form fields similar to AddLoanView but pre-populated
                    Group {
                        editField("Loan Name", text: $loanName)
                        editField("Total Amount", text: $totalAmount, keyboardType: .decimalPad)
                        editField("Outstanding Principal", text: $remainingAmount, keyboardType: .decimalPad)
                        editField("Interest Rate (%)", text: $interestRate, keyboardType: .decimalPad)
                        editField("Monthly Payment", text: $monthlyPayment, keyboardType: .decimalPad)
                    }
                    
                    // Loan Type Picker
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Loan Type")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        
                        Picker("Loan Type", selection: $selectedLoanType) {
                            ForEach(LoanData.LoanType.allCases, id: \.self) { type in
                                HStack {
                                    Image(systemName: type.icon)
                                    Text(type.rawValue)
                                }
                                .tag(type)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .padding(15)
                        .background(fieldBackground)
                    }
                    .padding(20)
                    .background(cardBackground)
                    
                    // Due Date Picker
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Monthly Due Date")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        
                        Picker("Due Date", selection: $dueDate) {
                            ForEach(1...31, id: \.self) { day in
                                Text("\(day)\(getOrdinalSuffix(day))").tag(day)
                            }
                        }
                        .pickerStyle(WheelPickerStyle())
                        .frame(height: 100)
                        .background(fieldBackground)
                    }
                    .padding(20)
                    .background(cardBackground)
                    
                    // Start Date Picker
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Loan Start Date")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        
                        DatePicker("Start Date", selection: $startDate, displayedComponents: .date)
                            .datePickerStyle(CompactDatePickerStyle())
                            .padding(15)
                            .background(fieldBackground)
                    }
                    .padding(20)
                    .background(cardBackground)
                    
                    // End Date Picker
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Loan End Date")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        
                        DatePicker("End Date", selection: $endDate, in: startDate..., displayedComponents: .date)
                            .datePickerStyle(CompactDatePickerStyle())
                            .padding(15)
                            .background(fieldBackground)
                    }
                    .padding(20)
                    .background(cardBackground)
                    
                    // Default Section
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Default Status")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        
                        VStack(spacing: 16) {
                            Toggle("Has Default", isOn: $hasDefault)
                                .toggleStyle(SwitchToggleStyle(tint: .red))
                            
                            if hasDefault {
                                editField("Penalty Amount", text: $penaltyAmount, keyboardType: .decimalPad)
                            }
                        }
                    }
                    .padding(20)
                    .background(cardBackground)
                }
                .padding()
            }
            .navigationTitle("Edit Loan")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        saveLoan()
                    }
                    .disabled(!isFormValid)
                }
            }
        }
    }
    
    private func editField(_ title: String, text: Binding<String>, keyboardType: UIKeyboardType = .default) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.subheadline)
                .fontWeight(.medium)
            
            TextField(title, text: text)
                .textFieldStyle(PlainTextFieldStyle())
                .keyboardType(keyboardType)
                .padding(15)
                .background(fieldBackground)
        }
        .padding(20)
        .background(cardBackground)
    }
    
    private var fieldBackground: some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(.ultraThinMaterial)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.blue.opacity(0.3), lineWidth: 1)
            )
    }
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(.ultraThinMaterial)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(LinearGradient(
                        gradient: Gradient(colors: [
                            Color.blue.opacity(0.05),
                            Color.purple.opacity(0.03)
                        ]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.blue.opacity(0.2), lineWidth: 1)
            )
            .shadow(color: colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1), radius: 15, x: 0, y: 8)
    }
    
    private var isFormValid: Bool {
        !loanName.isEmpty &&
        !totalAmount.isEmpty &&
        !remainingAmount.isEmpty &&
        !interestRate.isEmpty &&
        !monthlyPayment.isEmpty &&
        Double(totalAmount) != nil &&
        Double(remainingAmount) != nil &&
        Double(interestRate) != nil &&
        Double(monthlyPayment) != nil &&
        (!hasDefault || !penaltyAmount.isEmpty) &&
        (!hasDefault || Double(penaltyAmount) != nil)
    }
    
    private func saveLoan() {
        guard let total = Double(totalAmount),
              let remaining = Double(remainingAmount),
              let interest = Double(interestRate),
              let monthly = Double(monthlyPayment) else {
            return
        }
        
        let penalty = hasDefault ? (Double(penaltyAmount) ?? 0.0) : 0.0
        
        let updatedLoan = LoanData(
            id: loan.id,
            name: loanName,
            totalAmount: total,
            remainingAmount: remaining,
            interestRate: interest,
            firstEMI: monthly,
            lastEMI: monthly,
            dueDate: dueDate,
            startDate: startDate,
            endDate: endDate,
            loanType: selectedLoanType,
            lastPaymentProcessed: loan.lastPaymentProcessed,
            totalInterestPaid: loan.totalInterestPaid,
            paymentHistory: loan.paymentHistory,
            hasDefault: hasDefault,
            penaltyAmount: penalty,
            defaultCount: loan.defaultCount
        )
        
        onSave(updatedLoan)
        dismiss()
    }
    
    private func getOrdinalSuffix(_ number: Int) -> String {
        switch number {
        case 1, 21, 31: return "st"
        case 2, 22: return "nd"
        case 3, 23: return "rd"
        default: return "th"
        }
    }
}

#Preview {
    AddLoanView()
        .environmentObject(UserDataManager())
}
