//
//  PayPathTests.swift
//  PayPathTests
//
//  Created by Vansh Chawla on 19/07/2025.
//

import Testing
@testable import PayPath

struct PayPathTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
