import SwiftUI
import PDFKit

struct ReportsListView: View {
    @EnvironmentObject var userDataManager: UserDataManager
    @Environment(\.dismiss) private var dismiss
    @State private var reports: [ReportFile] = []
    @State private var selectedReport: ReportFile?
    @State private var showingPDFViewer = false
    @State private var showingDeleteAlert = false
    @State private var reportToDelete: ReportFile?
    
    var body: some View {
        NavigationView {
            VStack {
                if reports.isEmpty {
                    EmptyReportsView()
                } else {
                    List {
                        ForEach(reports) { report in
                            ReportRowView(report: report) {
                                selectedReport = report
                                showingPDFViewer = true
                            } onDelete: {
                                reportToDelete = report
                                showingDeleteAlert = true
                            }
                        }
                    }
                    .listStyle(PlainListStyle())
                }
            }
            .navigationTitle("My Reports")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Done") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Generate New") {
                        generateNewReport()
                    }
                    .foregroundColor(.blue)
                }
            }
            .onAppear {
                loadReports()
            }
            .sheet(isPresented: $showingPDFViewer) {
                if let report = selectedReport {
                    PDFViewerView(report: report)
                }
            }
            .alert("Delete Report", isPresented: $showingDeleteAlert) {
                Button("Cancel", role: .cancel) {
                    reportToDelete = nil
                }
                Button("Delete", role: .destructive) {
                    if let report = reportToDelete {
                        deleteReport(report)
                        reportToDelete = nil
                    }
                }
            } message: {
                if let report = reportToDelete {
                    Text("Are you sure you want to delete '\(report.name)'? This action cannot be undone.")
                }
            }
        }
    }
    
    private func loadReports() {
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            return
        }
        
        do {
            let fileURLs = try FileManager.default.contentsOfDirectory(at: documentsDirectory, includingPropertiesForKeys: [.creationDateKey], options: [])
            
            reports = fileURLs
                .filter { $0.pathExtension == "pdf" && $0.lastPathComponent.contains("LoanReport") }
                .compactMap { url in
                    guard let resourceValues = try? url.resourceValues(forKeys: [.creationDateKey]),
                          let creationDate = resourceValues.creationDate else {
                        return nil
                    }
                    
                    return ReportFile(
                        id: url.lastPathComponent,
                        name: formatReportName(from: url.lastPathComponent),
                        url: url,
                        creationDate: creationDate,
                        fileSize: getFileSize(url: url)
                    )
                }
                .sorted { $0.creationDate > $1.creationDate }
        } catch {
            print("Error loading reports: \(error)")
        }
    }
    
    private func generateNewReport() {
        guard !userDataManager.loans.isEmpty else {
            return
        }
        
        let reportGenerator = LoanReportGenerator()
        reportGenerator.generateComprehensiveReport(loans: userDataManager.loans, userProfile: userDataManager.userProfile) { success, message in
            DispatchQueue.main.async {
                if success {
                    loadReports() // Refresh the list
                }
            }
        }
    }
    
    private func deleteReport(_ report: ReportFile) {
        do {
            try FileManager.default.removeItem(at: report.url)
            loadReports() // Refresh the list
        } catch {
            print("Error deleting report: \(error)")
        }
    }
    
    private func formatReportName(from fileName: String) -> String {
        // Convert "LoanReport_2024-01-15.pdf" to "Loan Report - Jan 15, 2024"
        let components = fileName.replacingOccurrences(of: "LoanReport_", with: "").replacingOccurrences(of: ".pdf", with: "").split(separator: "-")
        
        if components.count == 3,
           let year = Int(components[0]),
           let month = Int(components[1]),
           let day = Int(components[2]) {
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMM d, yyyy"
            
            let calendar = Calendar.current
            let dateComponents = DateComponents(year: year, month: month, day: day)
            if let date = calendar.date(from: dateComponents) {
                return "Loan Report - \(dateFormatter.string(from: date))"
            }
        }
        
        return fileName.replacingOccurrences(of: ".pdf", with: "")
    }
    
    private func getFileSize(url: URL) -> String {
        do {
            let resourceValues = try url.resourceValues(forKeys: [.fileSizeKey])
            if let fileSize = resourceValues.fileSize {
                return ByteCountFormatter.string(fromByteCount: Int64(fileSize), countStyle: .file)
            }
        } catch {
            print("Error getting file size: \(error)")
        }
        return "Unknown"
    }
}

struct ReportFile: Identifiable {
    let id: String
    let name: String
    let url: URL
    let creationDate: Date
    let fileSize: String
}

struct EmptyReportsView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "doc.text")
                .font(.system(size: 60))
                .foregroundColor(.gray.opacity(0.6))
            
            VStack(spacing: 8) {
                Text("No Reports Generated")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Generate your first comprehensive loan report to track your financial progress")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            
            Text("Tap 'Generate New' to create your first report")
                .font(.caption)
                .foregroundColor(.blue)
                .padding(.top, 8)
        }
        .padding()
    }
}

struct ReportRowView: View {
    let report: ReportFile
    let onTap: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            HStack {
                Image(systemName: "doc.text.fill")
                    .font(.title2)
                    .foregroundColor(.red)
                    .frame(width: 40)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(report.name)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                    
                    HStack {
                        Text(formatDate(report.creationDate))
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Text("•")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Text(report.fileSize)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Spacer()
                
                Button(action: onDelete) {
                    Image(systemName: "trash")
                        .font(.caption)
                        .foregroundColor(.red)
                }
                .buttonStyle(PlainButtonStyle())
                
                Image(systemName: "chevron.right")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding(.vertical, 8)
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

struct PDFViewerView: View {
    let report: ReportFile
    @Environment(\.dismiss) private var dismiss
    @State private var showingShareSheet = false
    
    var body: some View {
        NavigationView {
            PDFKitView(url: report.url)
                .navigationTitle(report.name)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("Done") {
                            dismiss()
                        }
                    }
                    
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button(action: {
                            showingShareSheet = true
                        }) {
                            Image(systemName: "square.and.arrow.up")
                        }
                    }
                }
                .sheet(isPresented: $showingShareSheet) {
                    ShareSheet(items: [report.url])
                }
        }
    }
}

struct PDFKitView: UIViewRepresentable {
    let url: URL
    
    func makeUIView(context: Context) -> PDFView {
        let pdfView = PDFView()
        pdfView.autoScales = true
        pdfView.displayMode = .singlePageContinuous
        pdfView.displayDirection = .vertical
        
        if let document = PDFDocument(url: url) {
            pdfView.document = document
        }
        
        return pdfView
    }
    
    func updateUIView(_ uiView: PDFView, context: Context) {
        // No updates needed
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: items, applicationActivities: nil)
        return controller
    }
    
    func updateUIViewController(_ uiView: UIActivityViewController, context: Context) {
        // No updates needed
    }
}

#Preview {
    ReportsListView()
        .environmentObject(UserDataManager())
}
