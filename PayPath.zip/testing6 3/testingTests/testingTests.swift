//
//  testingTests.swift
//  testingTests
//
//  Created by Vansh Chawla on 18/06/2025.
//

import Testing

struct testingTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
