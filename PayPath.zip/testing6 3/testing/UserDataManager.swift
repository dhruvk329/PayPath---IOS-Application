import SwiftUI
import Foundation
import FirebaseFirestore

// MARK: - Data Models
struct LoanData: Codable, Identifiable {
    var id: UUID
    var name: String
    var totalAmount: Double
    var remainingAmount: Double
    var interestRate: Double
    var firstEMI: Double
    var lastEMI: Double
    var dueDate: Int // Day of month (1-31)
    var startDate: Date
    var endDate: Date
    var loanType: LoanType
    var lastPaymentProcessed: Date? // Track when last payment was processed
    var totalInterestPaid: Double // Track total interest paid over time
    var paymentHistory: [PaymentRecord] // Track payment history
    var hasDefault: Bool // Whether loan has defaults
    var penaltyAmount: Double // Penalty amount if default
    var defaultCount: Int // Number of defaults
    
    // Computed property for outstanding principal
    var outstandingPrincipal: Double {
        return remainingAmount
    }
    
    // Computed property for monthly payment (average of first and last EMI)
    var monthlyPayment: Double {
        return (firstEMI + lastEMI) / 2
    }
    
    // Custom initializer for new loans (generates new ID)
    init(name: String, totalAmount: Double, remainingAmount: Double, interestRate: Double, firstEMI: Double, lastEMI: Double, dueDate: Int, startDate: Date, endDate: Date, loanType: LoanType, hasDefault: Bool = false, penaltyAmount: Double = 0.0) {
        self.id = UUID()
        self.name = name
        self.totalAmount = totalAmount
        self.remainingAmount = remainingAmount
        self.interestRate = interestRate
        self.firstEMI = firstEMI
        self.lastEMI = lastEMI
        self.dueDate = dueDate
        self.startDate = startDate
        self.endDate = endDate
        self.loanType = loanType
        self.lastPaymentProcessed = nil
        self.totalInterestPaid = 0.0
        self.paymentHistory = []
        self.hasDefault = hasDefault
        self.penaltyAmount = penaltyAmount
        self.defaultCount = 0
    }
    
    // Custom initializer for Firebase data (uses existing ID)
    init(id: UUID, name: String, totalAmount: Double, remainingAmount: Double, interestRate: Double, firstEMI: Double, lastEMI: Double, dueDate: Int, startDate: Date, endDate: Date, loanType: LoanType, lastPaymentProcessed: Date? = nil, totalInterestPaid: Double = 0.0, paymentHistory: [PaymentRecord] = [], hasDefault: Bool = false, penaltyAmount: Double = 0.0, defaultCount: Int = 0) {
        self.id = id
        self.name = name
        self.totalAmount = totalAmount
        self.remainingAmount = remainingAmount
        self.interestRate = interestRate
        self.firstEMI = firstEMI
        self.lastEMI = lastEMI
        self.dueDate = dueDate
        self.startDate = startDate
        self.endDate = endDate
        self.loanType = loanType
        self.lastPaymentProcessed = lastPaymentProcessed
        self.totalInterestPaid = totalInterestPaid
        self.paymentHistory = paymentHistory
        self.hasDefault = hasDefault
        self.penaltyAmount = penaltyAmount
        self.defaultCount = defaultCount
    }
    
    enum LoanType: String, CaseIterable, Codable {
        case personal = "Personal Loan"
        case car = "Car Loan"
        case student = "Student Loan"
        case mortgage = "Mortgage"
        case credit = "Credit Card"
        case other = "Other"
        
        var icon: String {
            switch self {
            case .personal: return "person.circle"
            case .car: return "car"
            case .student: return "graduationcap"
            case .mortgage: return "house"
            case .credit: return "creditcard"
            case .other: return "dollarsign.circle"
            }
        }
    }
}

struct PaymentRecord: Codable, Identifiable {
    let id: UUID
    let date: Date
    let paymentAmount: Double
    let principalAmount: Double
    let interestAmount: Double
    let remainingBalance: Double
    
    init(date: Date, paymentAmount: Double, principalAmount: Double, interestAmount: Double, remainingBalance: Double) {
        self.id = UUID()
        self.date = date
        self.paymentAmount = paymentAmount
        self.principalAmount = principalAmount
        self.interestAmount = interestAmount
        self.remainingBalance = remainingBalance
    }
}

struct UserProfile: Codable {
    var fullName: String
    var email: String
    var joinDate: Date
    var totalLoansCount: Int
    var totalAmount: Double
    var totalMonthlyPayment: Double
    var totalOutstandingPrincipal: Double
    var totalDefaults: Int
    var totalPenalties: Double
}

// MARK: - User Data Manager
class UserDataManager: ObservableObject {
    @Published var userProfile: UserProfile?
    @Published var loans: [LoanData] = []
    @Published var isDataLoaded = false
    @Published var isLoadingLoans = false
    
    private let userDefaults = UserDefaults.standard
    private var currentUserEmail: String = ""
    private var firebaseUserId: String = ""
    
    private let db = Firestore.firestore()
    
    // MARK: - Firebase User Management
    func setFirebaseUserId(_ userId: String) {
        print("Setting Firebase User ID: \(userId)")
        firebaseUserId = userId
    }
    
    // MARK: - User Session Management
    func loadUserData(for email: String, fullName: String) {
        print("Loading data for user: \(email) with name: \(fullName)")
        currentUserEmail = email
        
        // Load user profile
        if let profileData = userDefaults.data(forKey: "userProfile_\(email)"),
           var profile = try? JSONDecoder().decode(UserProfile.self, from: profileData) {
            // Update the full name in case it changed
            profile.fullName = fullName
            userProfile = profile
            saveUserProfile() // Save the updated profile
            print("Loaded existing user profile and updated name to: \(fullName)")
        } else {
            // Create new user profile
            userProfile = UserProfile(
                fullName: fullName,
                email: email,
                joinDate: Date(),
                totalLoansCount: 0,
                totalAmount: 0,
                totalMonthlyPayment: 0,
                totalOutstandingPrincipal: 0,
                totalDefaults: 0,
                totalPenalties: 0.0
            )
            saveUserProfile()
            print("Created new user profile with name: \(fullName)")
        }
        
        // Load loans from local storage first
        loadLoansFromLocal()
        
        // Process any overdue payments before updating stats
        processOverduePayments()
        updateUserStats()
        isDataLoaded = true
    }
    
    private func loadLoansFromLocal() {
        if let loansData = userDefaults.data(forKey: "loans_\(currentUserEmail)"),
           let loadedLoans = try? JSONDecoder().decode([LoanData].self, from: loansData) {
            loans = loadedLoans
            print("✅ Loaded \(loans.count) loans from local storage")
        }
    }
    
    func clearUserData() {
        print("Clearing user data")
        userProfile = nil
        loans = []
        currentUserEmail = ""
        firebaseUserId = ""
        isDataLoaded = false
        isLoadingLoans = false
    }
    
    // MARK: - Payment Processing Logic
    func processOverduePayments() {
        print("\n🔄 === STARTING PAYMENT PROCESSING ===")
        print("📅 Current date: \(Date())")
        print("📊 Total loans to process: \(loans.count)")
        
        var loansUpdated = false
        
        for i in 0..<loans.count {
            print("\n--- Processing loan \(i + 1): \(loans[i].name) ---")
            if processLoanPayments(&loans[i]) {
                loansUpdated = true
                print("✅ Loan \(loans[i].name) was updated")
            } else {
                print("ℹ️ No updates needed for loan \(loans[i].name)")
            }
        }
        
        if loansUpdated {
            print("\n🔄 Saving updated loan data...")
            updateUserStats()
            saveLoans()
            saveUserProfile()
            
            // Update Firebase for all modified loans
            for loan in loans {
                updateLoanInFirebase(loan)
            }
            print("✅ All loan data saved successfully")
        } else {
            print("\nℹ️ No loans required updates")
        }
        
        print("🔄 === PAYMENT PROCESSING COMPLETE ===\n")
    }
    
    private func processLoanPayments(_ loan: inout LoanData) -> Bool {
        let calendar = Calendar.current
        let today = Date()
        var loanModified = false
        
        print("📋 Loan Details:")
        print("   Name: \(loan.name)")
        print("   Due Date: \(loan.dueDate)")
        print("   Start Date: \(loan.startDate)")
        print("   End Date: \(loan.endDate)")
        print("   Last Payment Processed: \(loan.lastPaymentProcessed?.description ?? "Never")")
        print("   Current Remaining: \(formatCurrency(loan.remainingAmount))")
        print("   Monthly Payment: \(formatCurrency(loan.monthlyPayment))")
        
        // Skip if loan is already paid off
        if loan.remainingAmount <= 0.01 {
            print("   ✅ Loan is already paid off")
            return false
        }
        
        // Skip if loan has ended
        if today > loan.endDate {
            print("   ⚠️ Loan has ended, marking as default if not paid off")
            if loan.remainingAmount > 0.01 && !loan.hasDefault {
                loan.hasDefault = true
                loan.defaultCount += 1
                loanModified = true
            }
            return loanModified
        }
        
        // Get the reference date (last payment or start date)
        let referenceDate = loan.lastPaymentProcessed ?? loan.startDate
        print("   📅 Reference date: \(referenceDate)")
        
        // Find all due dates between reference date and today
        let dueDates = getDueDatesBetween(startDate: referenceDate, endDate: min(today, loan.endDate), dueDay: loan.dueDate)
        print("   📅 Due dates found: \(dueDates.count)")
        
        for (index, dueDate) in dueDates.enumerated() {
            print("   \n   💰 Processing payment \(index + 1) for date: \(dueDate)")
            
            // Skip if this payment was already processed
            if let lastProcessed = loan.lastPaymentProcessed,
               dueDate <= lastProcessed {
                print("      ⏭️ Payment already processed, skipping")
                continue
            }
            
            // Skip if loan is already paid off
            if loan.remainingAmount <= 0.01 {
                print("      ✅ Loan paid off, stopping processing")
                break
            }
            
            // Process the payment
            let paymentResult = calculatePayment(
                remainingBalance: loan.remainingAmount,
                monthlyPayment: loan.monthlyPayment,
                annualInterestRate: loan.interestRate
            )
            
            print("      📊 Payment calculation:")
            print("         Total Payment: \(formatCurrency(paymentResult.totalPayment))")
            print("         Interest: \(formatCurrency(paymentResult.interestAmount))")
            print("         Principal: \(formatCurrency(paymentResult.principalAmount))")
            print("         Old Balance: \(formatCurrency(loan.remainingAmount))")
            
            // Update loan data
            let newBalance = max(0, loan.remainingAmount - paymentResult.principalAmount)
            loan.remainingAmount = newBalance
            loan.totalInterestPaid += paymentResult.interestAmount
            loan.lastPaymentProcessed = dueDate
            
            print("         New Balance: \(formatCurrency(loan.remainingAmount))")
            
            // Add to payment history
            let paymentRecord = PaymentRecord(
                date: dueDate,
                paymentAmount: paymentResult.totalPayment,
                principalAmount: paymentResult.principalAmount,
                interestAmount: paymentResult.interestAmount,
                remainingBalance: loan.remainingAmount
            )
            loan.paymentHistory.append(paymentRecord)
            
            loanModified = true
            print("      ✅ Payment processed successfully")
        }
        
        return loanModified
    }
    
    private func getDueDatesBetween(startDate: Date, endDate: Date, dueDay: Int) -> [Date] {
        let calendar = Calendar.current
        var dueDates: [Date] = []
        
        print("      🔍 Finding due dates between \(startDate) and \(endDate) for day \(dueDay)")
        
        // Start from the month of the start date
        var currentDate = startDate
        
        // Check if we need to include the current month
        let startComponents = calendar.dateComponents([.year, .month, .day], from: startDate)
        let endComponents = calendar.dateComponents([.year, .month, .day], from: endDate)
        
        // Create a date for the due day in the start month
        var checkComponents = DateComponents()
        checkComponents.year = startComponents.year
        checkComponents.month = startComponents.month
        checkComponents.day = min(dueDay, calendar.range(of: .day, in: .month, for: startDate)?.upperBound ?? 31)
        
        if let firstPossibleDue = calendar.date(from: checkComponents) {
            // If the due date in the start month is after the start date and before/on end date
            if firstPossibleDue > startDate && firstPossibleDue <= endDate {
                dueDates.append(firstPossibleDue)
                print("         📅 Added due date: \(firstPossibleDue)")
            }
        }
        
        // Move to next month and continue
        currentDate = calendar.date(byAdding: .month, value: 1, to: startDate) ?? startDate
        
        while currentDate <= endDate {
            var components = calendar.dateComponents([.year, .month], from: currentDate)
            components.day = min(dueDay, calendar.range(of: .day, in: .month, for: currentDate)?.upperBound ?? 31)
            
            if let dueDate = calendar.date(from: components),
               dueDate <= endDate {
                dueDates.append(dueDate)
                print("         📅 Added due date: \(dueDate)")
            }
            
            // Move to next month
            currentDate = calendar.date(byAdding: .month, value: 1, to: currentDate) ?? currentDate
        }
        
        let sortedDates = dueDates.sorted()
        print("      📅 Total due dates found: \(sortedDates.count)")
        return sortedDates
    }
    
    private func calculatePayment(remainingBalance: Double, monthlyPayment: Double, annualInterestRate: Double) -> (totalPayment: Double, principalAmount: Double, interestAmount: Double) {
        
        // Calculate monthly interest rate
        let monthlyInterestRate = annualInterestRate / 12.0 / 100.0
        
        // Calculate interest portion
        let interestAmount = remainingBalance * monthlyInterestRate
        
        // Calculate principal portion
        let principalAmount = min(monthlyPayment - interestAmount, remainingBalance)
        
        // Ensure we don't have negative principal
        let actualPrincipal = max(0, principalAmount)
        let actualPayment = interestAmount + actualPrincipal
        
        return (
            totalPayment: actualPayment,
            principalAmount: actualPrincipal,
            interestAmount: interestAmount
        )
    }
    
    // MARK: - Manual Payment Processing
    func makeManualPayment(for loanId: UUID, amount: Double) {
        guard let index = loans.firstIndex(where: { $0.id == loanId }) else { return }
        
        let paymentResult = calculatePayment(
            remainingBalance: loans[index].remainingAmount,
            monthlyPayment: amount,
            annualInterestRate: loans[index].interestRate
        )
        
        // Update loan
        loans[index].remainingAmount = max(0, loans[index].remainingAmount - paymentResult.principalAmount)
        loans[index].totalInterestPaid += paymentResult.interestAmount
        
        // Add to payment history
        let paymentRecord = PaymentRecord(
            date: Date(),
            paymentAmount: paymentResult.totalPayment,
            principalAmount: paymentResult.principalAmount,
            interestAmount: paymentResult.interestAmount,
            remainingBalance: loans[index].remainingAmount
        )
        loans[index].paymentHistory.append(paymentRecord)
        
        // Save changes
        updateUserStats()
        saveLoans()
        saveUserProfile()
        updateLoanInFirebase(loans[index])
        
        print("✅ Manual payment processed for \(loans[index].name): \(formatCurrency(amount))")
    }
    
    // MARK: - Force Payment Processing (for testing)
    func forceProcessPayment(for loanId: UUID) {
        guard let index = loans.firstIndex(where: { $0.id == loanId }) else {
            print("❌ Loan not found with ID: \(loanId)")
            return
        }
        
        print("🔧 FORCE PROCESSING payment for loan: \(loans[index].name)")
        
        // Skip if loan is already paid off
        if loans[index].remainingAmount <= 0.01 {
            print("✅ Loan is already paid off")
            return
        }
        
        // Process the payment for today
        let paymentResult = calculatePayment(
            remainingBalance: loans[index].remainingAmount,
            monthlyPayment: loans[index].monthlyPayment,
            annualInterestRate: loans[index].interestRate
        )
        
        print("💰 Payment Details:")
        print("   Total Payment: \(formatCurrency(paymentResult.totalPayment))")
        print("   Interest: \(formatCurrency(paymentResult.interestAmount))")
        print("   Principal: \(formatCurrency(paymentResult.principalAmount))")
        print("   Old Balance: \(formatCurrency(loans[index].remainingAmount))")
        
        // Update loan data
        loans[index].remainingAmount = max(0, loans[index].remainingAmount - paymentResult.principalAmount)
        loans[index].totalInterestPaid += paymentResult.interestAmount
        loans[index].lastPaymentProcessed = Date()
        
        print("   New Balance: \(formatCurrency(loans[index].remainingAmount))")
        
        // Add to payment history
        let paymentRecord = PaymentRecord(
            date: Date(),
            paymentAmount: paymentResult.totalPayment,
            principalAmount: paymentResult.principalAmount,
            interestAmount: paymentResult.interestAmount,
            remainingBalance: loans[index].remainingAmount
        )
        loans[index].paymentHistory.append(paymentRecord)
        
        // Save changes
        updateUserStats()
        saveLoans()
        saveUserProfile()
        updateLoanInFirebase(loans[index])
        
        print("✅ Force payment processing completed!")
    }
    
    // MARK: - Currency Management (System Default)
    func formatCurrency(_ amount: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current // Always use system locale
        
        return formatter.string(from: NSNumber(value: amount)) ?? "\(getCurrencySymbol())\(amount)"
    }
    
    func getCurrencySymbol() -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        return formatter.currencySymbol ?? "$"
    }
    
    // MARK: - Firebase Loan Management
    func loadLoansFromFirebase() {
        guard !firebaseUserId.isEmpty else {
            print("❌ No Firebase User ID set")
            return
        }
        
        print("🔥 Loading loans from Firebase for user: \(firebaseUserId)")
        isLoadingLoans = true
        
        db.collection("users").document(firebaseUserId).collection("loans")
            .addSnapshotListener { [weak self] querySnapshot, error in
                DispatchQueue.main.async {
                    self?.isLoadingLoans = false
                    
                    if let error = error {
                        print("❌ Error loading loans: \(error.localizedDescription)")
                        return
                    }
                    
                    guard let documents = querySnapshot?.documents else {
                        print("📭 No loans found")
                        self?.loans = []
                        self?.processOverduePayments()
                        self?.updateUserStats()
                        return
                    }
                    
                    var loadedLoans: [LoanData] = []
                    
                    for document in documents {
                        do {
                            let data = document.data()
                            let loan = try self?.decodeLoanFromFirestore(data: data)
                            if let loan = loan {
                                loadedLoans.append(loan)
                            }
                        } catch {
                            print("❌ Error decoding loan: \(error.localizedDescription)")
                        }
                    }
                    
                    print("✅ Loaded \(loadedLoans.count) loans from Firebase")
                    self?.loans = loadedLoans
                    self?.processOverduePayments() // Process payments after loading
                    self?.updateUserStats()
                    self?.saveLoans() // Cache locally
                }
            }
    }
    
    private func saveLoanToFirebase(_ loan: LoanData) {
        guard !firebaseUserId.isEmpty else {
            print("❌ No Firebase User ID set")
            return
        }
        
        print("🔥 Saving loan to Firebase: \(loan.name)")
        
        let loanData = encodeLoanForFirestore(loan)
        
        db.collection("users").document(firebaseUserId).collection("loans")
            .document(loan.id.uuidString).setData(loanData) { error in
                if let error = error {
                    print("❌ Error saving loan: \(error.localizedDescription)")
                } else {
                    print("✅ Loan saved to Firebase: \(loan.name)")
                }
            }
    }
    
    private func updateLoanInFirebase(_ loan: LoanData) {
        guard !firebaseUserId.isEmpty else {
            print("❌ No Firebase User ID set")
            return
        }
        
        print("🔥 Updating loan in Firebase: \(loan.name)")
        
        let loanData = encodeLoanForFirestore(loan)
        
        db.collection("users").document(firebaseUserId).collection("loans")
            .document(loan.id.uuidString).updateData(loanData) { error in
                if let error = error {
                    print("❌ Error updating loan: \(error.localizedDescription)")
                } else {
                    print("✅ Loan updated in Firebase: \(loan.name)")
                }
            }
    }
    
    private func deleteLoanFromFirebase(_ loan: LoanData) {
        guard !firebaseUserId.isEmpty else {
            print("❌ No Firebase User ID set")
            return
        }
        
        print("🔥 Deleting loan from Firebase: \(loan.name)")
        
        db.collection("users").document(firebaseUserId).collection("loans")
            .document(loan.id.uuidString).delete { error in
                if let error = error {
                    print("❌ Error deleting loan: \(error.localizedDescription)")
                } else {
                    print("✅ Loan deleted from Firebase: \(loan.name)")
                }
            }
    }
    
    // MARK: - Firestore Encoding/Decoding
    private func encodeLoanForFirestore(_ loan: LoanData) -> [String: Any] {
        var data: [String: Any] = [
            "id": loan.id.uuidString,
            "name": loan.name,
            "totalAmount": loan.totalAmount,
            "remainingAmount": loan.remainingAmount,
            "interestRate": loan.interestRate,
            "firstEMI": loan.firstEMI,
            "lastEMI": loan.lastEMI,
            "dueDate": loan.dueDate,
            "startDate": Timestamp(date: loan.startDate),
            "endDate": Timestamp(date: loan.endDate),
            "loanType": loan.loanType.rawValue,
            "totalInterestPaid": loan.totalInterestPaid,
            "hasDefault": loan.hasDefault,
            "penaltyAmount": loan.penaltyAmount,
            "defaultCount": loan.defaultCount,
            "createdAt": Timestamp(),
            "updatedAt": Timestamp()
        ]
        
        if let lastPaymentProcessed = loan.lastPaymentProcessed {
            data["lastPaymentProcessed"] = Timestamp(date: lastPaymentProcessed)
        }
        
        // Encode payment history
        let paymentHistoryData = loan.paymentHistory.map { payment in
            return [
                "id": payment.id.uuidString,
                "date": Timestamp(date: payment.date),
                "paymentAmount": payment.paymentAmount,
                "principalAmount": payment.principalAmount,
                "interestAmount": payment.interestAmount,
                "remainingBalance": payment.remainingBalance
            ]
        }
        data["paymentHistory"] = paymentHistoryData
        
        return data
    }
    
    private func decodeLoanFromFirestore(data: [String: Any]) throws -> LoanData {
        guard let idString = data["id"] as? String,
              let id = UUID(uuidString: idString),
              let name = data["name"] as? String,
              let totalAmount = data["totalAmount"] as? Double,
              let remainingAmount = data["remainingAmount"] as? Double,
              let interestRate = data["interestRate"] as? Double,
              let dueDate = data["dueDate"] as? Int,
              let startDateTimestamp = data["startDate"] as? Timestamp,
              let loanTypeString = data["loanType"] as? String,
              let loanType = LoanData.LoanType(rawValue: loanTypeString) else {
            throw NSError(domain: "DecodingError", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to decode loan data"])
        }
        
        // Handle backward compatibility for new fields
        let firstEMI = data["firstEMI"] as? Double ?? data["monthlyPayment"] as? Double ?? 0.0
        let lastEMI = data["lastEMI"] as? Double ?? data["monthlyPayment"] as? Double ?? 0.0
        let endDateTimestamp = data["endDate"] as? Timestamp ?? Timestamp(date: Calendar.current.date(byAdding: .year, value: 1, to: startDateTimestamp.dateValue()) ?? Date())
        let hasDefault = data["hasDefault"] as? Bool ?? false
        let penaltyAmount = data["penaltyAmount"] as? Double ?? 0.0
        let defaultCount = data["defaultCount"] as? Int ?? 0
        
        let lastPaymentProcessed = (data["lastPaymentProcessed"] as? Timestamp)?.dateValue()
        let totalInterestPaid = data["totalInterestPaid"] as? Double ?? 0.0
        
        // Decode payment history
        var paymentHistory: [PaymentRecord] = []
        if let paymentHistoryData = data["paymentHistory"] as? [[String: Any]] {
            for paymentData in paymentHistoryData {
                if let idString = paymentData["id"] as? String,
                   let paymentId = UUID(uuidString: idString),
                   let dateTimestamp = paymentData["date"] as? Timestamp,
                   let paymentAmount = paymentData["paymentAmount"] as? Double,
                   let principalAmount = paymentData["principalAmount"] as? Double,
                   let interestAmount = paymentData["interestAmount"] as? Double,
                   let remainingBalance = paymentData["remainingBalance"] as? Double {
                    
                    let payment = PaymentRecord(
                        date: dateTimestamp.dateValue(),
                        paymentAmount: paymentAmount,
                        principalAmount: principalAmount,
                        interestAmount: interestAmount,
                        remainingBalance: remainingBalance
                    )
                    paymentHistory.append(payment)
                }
            }
        }
        
        return LoanData(
            id: id,
            name: name,
            totalAmount: totalAmount,
            remainingAmount: remainingAmount,
            interestRate: interestRate,
            firstEMI: firstEMI,
            lastEMI: lastEMI,
            dueDate: dueDate,
            startDate: startDateTimestamp.dateValue(),
            endDate: endDateTimestamp.dateValue(),
            loanType: loanType,
            lastPaymentProcessed: lastPaymentProcessed,
            totalInterestPaid: totalInterestPaid,
            paymentHistory: paymentHistory,
            hasDefault: hasDefault,
            penaltyAmount: penaltyAmount,
            defaultCount: defaultCount
        )
    }
    
    // MARK: - Profile Management
    func updateUserProfile(fullName: String, email: String, completion: @escaping (Bool, String?) -> Void) {
        guard var profile = userProfile else {
            completion(false, "No user profile found")
            return
        }
        
        let oldEmail = profile.email
        
        // Update profile data
        profile.fullName = fullName
        profile.email = email
        
        // Update the published property
        self.userProfile = profile
        
        // If email changed, we need to migrate the data
        if oldEmail != email {
            // Save data with new email key
            currentUserEmail = email
            saveUserProfile()
            saveLoans()
            
            // Remove old data
            userDefaults.removeObject(forKey: "userProfile_\(oldEmail)")
            userDefaults.removeObject(forKey: "loans_\(oldEmail)")
            
            print("Migrated user data from \(oldEmail) to \(email)")
        } else {
            // Just save with current email
            saveUserProfile()
        }
        
        completion(true, nil)
    }
    
    // MARK: - Data Persistence
    private func saveUserProfile() {
        guard let profile = userProfile,
              let data = try? JSONEncoder().encode(profile) else { return }
        userDefaults.set(data, forKey: "userProfile_\(currentUserEmail)")
        print("Saved user profile for \(profile.fullName)")
    }
    
    private func saveLoans() {
        guard let data = try? JSONEncoder().encode(loans) else { return }
        userDefaults.set(data, forKey: "loans_\(currentUserEmail)")
        print("Saved \(loans.count) loans locally")
    }
    
    // MARK: - Loan Management
    func addLoan(_ loan: LoanData) {
        loans.append(loan)
        updateUserStats()
        saveLoans()
        saveUserProfile()
        
        // Save to Firebase
        saveLoanToFirebase(loan)
        
        print("Added new loan: \(loan.name)")
    }
    
    func updateLoan(_ loan: LoanData) {
        if let index = loans.firstIndex(where: { $0.id == loan.id }) {
            loans[index] = loan
            updateUserStats()
            saveLoans()
            saveUserProfile()
            
            // Update in Firebase
            updateLoanInFirebase(loan)
            
            print("Updated loan: \(loan.name)")
        }
    }
    
    func deleteLoan(_ loan: LoanData) {
        print("🗑️ Starting deletion process for loan: \(loan.name)")
        print("🗑️ Current loans count: \(loans.count)")
        print("🗑️ Loan ID to delete: \(loan.id)")
        
        // Find and remove the loan
        if let index = loans.firstIndex(where: { $0.id == loan.id }) {
            let removedLoan = loans.remove(at: index)
            print("🗑️ Successfully removed loan: \(removedLoan.name)")
            print("🗑️ New loans count: \(loans.count)")
            
            // Update stats and save
            updateUserStats()
            saveLoans()
            saveUserProfile()
            
            // Delete from Firebase
            deleteLoanFromFirebase(removedLoan)
            
            print("🗑️ Deletion completed and data saved")
        } else {
            print("❌ Could not find loan with ID: \(loan.id)")
            print("❌ Available loan IDs: \(loans.map { $0.id })")
        }
    }
    
    // MARK: - Statistics Calculation
    private func updateUserStats() {
        guard var profile = userProfile else { return }
        
        print("🔄 Updating user stats...")
        print("   Current loans count: \(loans.count)")
        
        profile.totalLoansCount = loans.count
        profile.totalAmount = loans.reduce(0) { $0 + $1.totalAmount }
        profile.totalMonthlyPayment = loans.reduce(0) { $0 + $1.monthlyPayment }
        
        // Calculate total outstanding principal from all loans
        profile.totalOutstandingPrincipal = loans.reduce(0) { $0 + $1.outstandingPrincipal }
        
        // Calculate total defaults - sum up all defaultCount from all loans
        let totalDefaults = loans.reduce(0) { $0 + $1.defaultCount }
        profile.totalDefaults = totalDefaults
        
        // Calculate total penalty amounts from all loans with defaults
        let totalPenalties = loans.reduce(0) { total, loan in
            return total + (loan.hasDefault ? loan.penaltyAmount : 0)
        }
        profile.totalPenalties = totalPenalties
        
        print("   Total defaults calculated: \(totalDefaults)")
        print("   Total penalties calculated: \(formatCurrency(totalPenalties))")
        print("   Loan defaults breakdown:")
        for loan in loans {
            if loan.defaultCount > 0 || loan.hasDefault {
                print("     - \(loan.name): \(loan.defaultCount) defaults, hasDefault: \(loan.hasDefault), penalty: \(formatCurrency(loan.penaltyAmount))")
            }
        }
        
        userProfile = profile
        print("✅ User stats updated successfully")
    }
    
    // MARK: - Helper Methods
    func getUpcomingPayments() -> [LoanData] {
        let today = Calendar.current.component(.day, from: Date())
        return loans.filter { loan in
            let daysUntilDue = loan.dueDate - today
            return daysUntilDue >= 0 && daysUntilDue <= 7
        }.sorted { $0.dueDate < $1.dueDate }
    }
    
    func getTotalRemainingAmount() -> Double {
        return loans.reduce(0) { $0 + $1.remainingAmount }
    }
    
    // MARK: - Next Payment Date Calculation
    func getNextPaymentDate() -> Date? {
        let calendar = Calendar.current
        let today = Date()
        var nextPaymentDates: [Date] = []
        
        // Get next payment date for each active loan
        for loan in loans {
            // Skip paid off loans
            if loan.remainingAmount <= 0.01 {
                continue
            }
            
            // Skip loans that have ended
            if today > loan.endDate {
                continue
            }
            
            // Calculate next payment date for this loan
            if let nextDate = getNextPaymentDate(for: loan) {
                nextPaymentDates.append(nextDate)
            }
        }
        
        // Return the earliest next payment date
        return nextPaymentDates.min()
    }
    
    private func getNextPaymentDate(for loan: LoanData) -> Date? {
        let calendar = Calendar.current
        let today = Date()
        
        // If loan has ended or is paid off, no next payment
        if today > loan.endDate || loan.remainingAmount <= 0.01 {
            return nil
        }
        
        // Get current month and year
        let currentComponents = calendar.dateComponents([.year, .month], from: today)
        
        // Try current month first
        var nextPaymentComponents = DateComponents()
        nextPaymentComponents.year = currentComponents.year
        nextPaymentComponents.month = currentComponents.month
        nextPaymentComponents.day = min(loan.dueDate, calendar.range(of: .day, in: .month, for: today)?.upperBound ?? 31)
        
        if let currentMonthDue = calendar.date(from: nextPaymentComponents) {
            // If the due date this month is in the future, return it
            if currentMonthDue > today {
                return min(currentMonthDue, loan.endDate)
            }
        }
        
        // Otherwise, try next month
        if let nextMonth = calendar.date(byAdding: .month, value: 1, to: today) {
            let nextMonthComponents = calendar.dateComponents([.year, .month], from: nextMonth)
            
            var nextPaymentComponents = DateComponents()
            nextPaymentComponents.year = nextMonthComponents.year
            nextPaymentComponents.month = nextMonthComponents.month
            nextPaymentComponents.day = min(loan.dueDate, calendar.range(of: .day, in: .month, for: nextMonth)?.upperBound ?? 31)
            
            if let nextMonthDue = calendar.date(from: nextPaymentComponents) {
                return min(nextMonthDue, loan.endDate)
            }
        }
        
        return nil
    }
    
    func formatNextPaymentDate() -> String {
        guard let nextDate = getNextPaymentDate() else {
            return "No payments due"
        }
        
        let formatter = DateFormatter()
        let calendar = Calendar.current
        
        if calendar.isDateInToday(nextDate) {
            return "Today"
        } else if calendar.isDateInTomorrow(nextDate) {
            return "Tomorrow"
        } else if calendar.dateComponents([.day], from: Date(), to: nextDate).day! <= 7 {
            formatter.dateFormat = "EEEE" // Day of week
            return formatter.string(from: nextDate)
        } else {
            formatter.dateStyle = .medium
            return formatter.string(from: nextDate)
        }
    }
    
    // MARK: - Payment History
    func getPaymentHistory(for loanId: UUID) -> [PaymentRecord] {
        guard let loan = loans.first(where: { $0.id == loanId }) else { return [] }
        return loan.paymentHistory.sorted { $0.date > $1.date }
    }
    
    func getTotalInterestPaid(for loanId: UUID) -> Double {
        guard let loan = loans.first(where: { $0.id == loanId }) else { return 0 }
        return loan.totalInterestPaid
    }
}
