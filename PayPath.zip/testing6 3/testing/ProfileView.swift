import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var showingReports = false
    @State private var showingNotifications = false
    @State private var showingPrivacySecurity = false
    @State private var showingHelpSupport = false
    @State private var animateElements = false
    @Environment(\.colorScheme) var colorScheme
    
    private var backgroundGradient: LinearGradient {
        if colorScheme == .dark {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.black,
                    Color(red: 0.05, green: 0.05, blue: 0.1),
                    Color(red: 0.1, green: 0.1, blue: 0.15)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.98, green: 0.99, blue: 1.0),
                    Color(red: 0.95, green: 0.97, blue: 0.99),
                    Color(red: 0.92, green: 0.95, blue: 0.98)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundGradient
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 30) {
                        // Profile Header
                        profileHeader
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : -30)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.1), value: animateElements)
                        
                        // Profile Options
                        VStack(spacing: 16) {
                            ProfileOptionRow(
                                icon: "doc.text.fill",
                                title: "My Reports",
                                color: .blue,
                                delay: 0.2
                            ) {
                                showingReports = true
                            }
                            
                            ProfileOptionRow(
                                icon: "bell.fill",
                                title: "Notifications",
                                color: .orange,
                                delay: 0.3
                            ) {
                                showingNotifications = true
                            }
                            
                            ProfileOptionRow(
                                icon: "lock.fill",
                                title: "Privacy & Security",
                                color: .purple,
                                delay: 0.4
                            ) {
                                showingPrivacySecurity = true
                            }
                            
                            ProfileOptionRow(
                                icon: "questionmark.circle.fill",
                                title: "Help & Support",
                                color: .green,
                                delay: 0.5
                            ) {
                                showingHelpSupport = true
                            }
                        }
                        .padding(.horizontal)
                        
                        // Sign Out Button
                        signOutButton
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : 30)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.6), value: animateElements)
                        
                        Spacer(minLength: 50)
                    }
                    .padding(.top, 20)
                }
            }
            .navigationTitle("Profile")
            .navigationBarTitleDisplayMode(.large)
            .onAppear {
                withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                    animateElements = true
                }
            }
        }
        .sheet(isPresented: $showingReports) {
            ReportsListView()
                .environmentObject(userDataManager)
        }
        .sheet(isPresented: $showingNotifications) {
            NotificationSettingsView()
                .environmentObject(userDataManager)
        }
        .sheet(isPresented: $showingPrivacySecurity) {
            PrivacySecurityView()
                .environmentObject(authViewModel)
                .environmentObject(userDataManager)
        }
        .sheet(isPresented: $showingHelpSupport) {
            HelpSupportView()
        }
    }
    
    private var profileHeader: some View {
        VStack(spacing: 20) {
            // Profile Avatar
            ZStack {
                Circle()
                    .fill(LinearGradient(
                        gradient: Gradient(colors: [Color.blue, Color.purple]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                    .frame(width: 120, height: 120)
                    .shadow(color: Color.blue.opacity(0.3), radius: 15, x: 0, y: 8)
                
                Circle()
                    .stroke(Color.white.opacity(0.3), lineWidth: 3)
                    .frame(width: 140, height: 140)
                
                Image(systemName: "person.circle.fill")
                    .font(.system(size: 80))
                    .foregroundColor(.white)
            }
            
            // User Info
            VStack(spacing: 8) {
                Text(userDataManager.userProfile?.fullName ?? "User")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(LinearGradient(
                        gradient: Gradient(colors: [Color.blue, Color.purple]),
                        startPoint: .leading,
                        endPoint: .trailing
                    ))
                
                Text(userDataManager.userProfile?.email ?? "")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                if let joinDate = userDataManager.userProfile?.joinDate {
                    HStack(spacing: 8) {
                        Image(systemName: "calendar")
                            .font(.caption)
                            .foregroundColor(.blue)
                        
                        Text("Member since \(joinDate, style: .date)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(8)
                }
            }
        }
        .padding(25)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.ultraThinMaterial)
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .fill(LinearGradient(
                            gradient: Gradient(colors: [
                                Color.blue.opacity(0.1),
                                Color.purple.opacity(0.05)
                            ]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(LinearGradient(
                            gradient: Gradient(colors: [
                                Color.blue.opacity(0.3),
                                Color.purple.opacity(0.2)
                            ]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ), lineWidth: 1)
                )
                .shadow(color: colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1), radius: 15, x: 0, y: 8)
        )
        .padding(.horizontal)
    }
    
    private var signOutButton: some View {
        Button(action: {
            authViewModel.signOut()
        }) {
            HStack(spacing: 12) {
                Image(systemName: "rectangle.portrait.and.arrow.right")
                    .font(.system(size: 18, weight: .semibold))
                
                Text("Sign Out")
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 55)
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color.red, Color.pink]),
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .cornerRadius(15)
            .shadow(color: Color.red.opacity(0.3), radius: 10, x: 0, y: 5)
        }
        .padding(.horizontal)
    }
}

struct ProfileOptionRow: View {
    let icon: String
    let title: String
    let color: Color
    let delay: Double
    let action: () -> Void
    @Environment(\.colorScheme) var colorScheme
    @State private var animateRow = false
    @State private var isPressed = false
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 15)
            .fill(.ultraThinMaterial)
            .background(
                RoundedRectangle(cornerRadius: 15)
                    .fill(gradientBackground)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(borderGradient, lineWidth: 1)
            )
            .shadow(color: shadowColor, radius: 10, x: 0, y: 5)
    }
    
    private var gradientBackground: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                color.opacity(0.1),
                color.opacity(0.05)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var borderGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                color.opacity(0.3),
                color.opacity(0.1)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var shadowColor: Color {
        colorScheme == .dark ? Color.white.opacity(0.05) : color.opacity(0.1)
    }
    
    var body: some View {
        Button(action: {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                isPressed = true
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                    isPressed = false
                }
                action()
            }
        }) {
            HStack(spacing: 16) {
                ZStack {
                    Circle()
                        .fill(LinearGradient(
                            gradient: Gradient(colors: [color, color.opacity(0.7)]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                        .frame(width: 45, height: 45)
                        .shadow(color: color.opacity(0.3), radius: 5, x: 0, y: 2)
                    
                    Image(systemName: icon)
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor(.white)
                }
                
                Text(title)
                    .font(.headline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.secondary)
            }
            .padding(20)
            .background(cardBackground)
            .scaleEffect(isPressed ? 0.96 : (animateRow ? 1.0 : 0.9))
            .opacity(animateRow ? 1.0 : 0.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isPressed)
            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(delay), value: animateRow)
        }
        .buttonStyle(PlainButtonStyle())
        .onAppear {
            animateRow = true
        }
    }
}

#Preview {
    ProfileView()
        .environmentObject(AuthViewModel())
        .environmentObject(UserDataManager())
}
