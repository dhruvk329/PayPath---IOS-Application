import SwiftUI

struct LoanTrackerDashboard: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var selectedTab = 0
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // Dashboard Tab
            DashboardView(selectedTab: $selectedTab)
                .tabItem {
                    Image(systemName: "chart.pie.fill")
                    Text("Dashboard")
                }
                .tag(0)
            
            // Loans Tab
            LoansListView()
                .tabItem {
                    Image(systemName: "list.bullet.rectangle")
                    Text("Loans")
                }
                .tag(1)
            
            // Add Loan Tab - Simple add loan form
            AddLoanView()
                .tabItem {
                    Image(systemName: "plus.circle.fill")
                    Text("Add Loan")
                }
                .tag(2)
            
            // EMI Calculator Tab
            EMICalculatorView()
                .tabItem {
                    Image(systemName: "function")
                    Text("EMI Calculator")
                }
                .tag(3)
            
            // Profile Tab
            ProfileView()
                .tabItem {
                    Image(systemName: "person.circle.fill")
                    Text("Profile")
                }
                .tag(4)
        }
        .accentColor(.blue)
        .environmentObject(authViewModel.userDataManager)
    }
}

struct DashboardView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @EnvironmentObject var userDataManager: UserDataManager
    @Binding var selectedTab: Int
    @Environment(\.colorScheme) var colorScheme
    @State private var animateElements = false
    
    private var backgroundGradient: LinearGradient {
        if colorScheme == .dark {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.black,
                    Color(red: 0.05, green: 0.05, blue: 0.1),
                    Color(red: 0.1, green: 0.1, blue: 0.15)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.98, green: 0.99, blue: 1.0),
                    Color(red: 0.95, green: 0.97, blue: 0.99),
                    Color(red: 0.92, green: 0.95, blue: 0.98)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundGradient
                    .ignoresSafeArea()
                
                Group {
                    if userDataManager.isDataLoaded {
                        ScrollView {
                            LazyVStack(spacing: 25) {
                                // Welcome Header
                                WelcomeHeaderView()
                                    .opacity(animateElements ? 1.0 : 0.0)
                                    .offset(y: animateElements ? 0 : -30)
                                    .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.1), value: animateElements)
                                
                                // Summary Cards
                                SummaryCardsView()
                                    .opacity(animateElements ? 1.0 : 0.0)
                                    .offset(y: animateElements ? 0 : -10)
                                    .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.2), value: animateElements)
                                
                                // Recent Loans or Empty State
                                if userDataManager.loans.isEmpty {
                                    EmptyLoansView(selectedTab: $selectedTab)
                                        .opacity(animateElements ? 1.0 : 0.0)
                                        .offset(y: animateElements ? 0 : 10)
                                        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.3), value: animateElements)
                                } else {
                                    RecentLoansView(selectedTab: $selectedTab)
                                        .opacity(animateElements ? 1.0 : 0.0)
                                        .offset(y: animateElements ? 0 : 10)
                                        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.3), value: animateElements)
                                }
                            }
                            .padding()
                        }
                    } else {
                        // Loading state
                        VStack(spacing: 20) {
                            ProgressView()
                                .scaleEffect(1.5)
                                .progressViewStyle(CircularProgressViewStyle(tint: .blue))
                            
                            Text("Loading your data...")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("Dashboard")
            .navigationBarTitleDisplayMode(.large)
            .onAppear {
                // Process overdue payments when dashboard appears
                userDataManager.processOverduePayments()
                
                withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                    animateElements = true
                }
            }
            .refreshable {
                // Process payments on pull to refresh
                userDataManager.processOverduePayments()
            }
        }
    }
}

struct EmptyLoansView: View {
    @Binding var selectedTab: Int
    @Environment(\.colorScheme) var colorScheme
    @State private var animatePulse = false
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(.ultraThinMaterial)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(gradientBackground)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(borderGradient, lineWidth: 1)
            )
            .shadow(color: shadowColor, radius: 15, x: 0, y: 8)
    }
    
    private var gradientBackground: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.blue.opacity(0.05),
                Color.green.opacity(0.05)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var borderGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.blue.opacity(0.2),
                Color.green.opacity(0.2)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var shadowColor: Color {
        colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1)
    }
    
    var body: some View {
        VStack(spacing: 25) {
            ZStack {
                Circle()
                    .fill(Color.blue.opacity(0.1))
                    .frame(width: 100, height: 100)
                    .scaleEffect(animatePulse ? 1.1 : 1.0)
                    .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: animatePulse)
                
                Image(systemName: "plus.circle.dashed")
                    .font(.system(size: 50))
                    .foregroundColor(.blue)
            }
            
            VStack(spacing: 12) {
                Text("No Loans Yet")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text("Start by adding your first loan to begin tracking your financial journey")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .lineLimit(3)
            }
            
            Button("Add Your First Loan") {
                selectedTab = 2
            }
            .font(.headline)
            .fontWeight(.semibold)
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 50)
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue, Color.cyan]),
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .cornerRadius(15)
            .shadow(color: Color.blue.opacity(0.3), radius: 10, x: 0, y: 5)
        }
        .padding(30)
        .background(cardBackground)
        .onAppear {
            animatePulse = true
        }
    }
}

struct WelcomeHeaderView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @EnvironmentObject var userDataManager: UserDataManager
    @Environment(\.colorScheme) var colorScheme
    @State private var animateWave = false
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(.ultraThinMaterial)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(gradientBackground)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(borderGradient, lineWidth: 1)
            )
            .shadow(color: shadowColor, radius: 15, x: 0, y: 8)
    }
    
    private var gradientBackground: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.purple.opacity(0.1),
                Color.blue.opacity(0.05)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var borderGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.purple.opacity(0.3),
                Color.blue.opacity(0.2)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var shadowColor: Color {
        colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 8) {
                        Text(userDataManager.loans.isEmpty ? "Welcome to PayPath," : "Welcome back,")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        Text("👋")
                            .font(.subheadline)
                            .rotationEffect(.degrees(animateWave ? 20 : 0))
                            .animation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true), value: animateWave)
                    }
                    
                    Text(userDataManager.userProfile?.fullName ?? authViewModel.currentUser?.displayName ?? "User")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundStyle(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.purple, Color.blue]),
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                }
                
                Spacer()
                
                Button(action: {
                    authViewModel.signOut()
                }) {
                    ZStack {
                        Circle()
                            .fill(Color.red.opacity(0.1))
                            .frame(width: 40, height: 40)
                        
                        Image(systemName: "rectangle.portrait.and.arrow.right")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.red)
                    }
                }
            }
            
            if let joinDate = userDataManager.userProfile?.joinDate,
               userDataManager.loans.isEmpty {
                Text("Joined \(joinDate, style: .date)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .padding(.top, 4)
            }
        }
        .padding(20)
        .background(cardBackground)
        .onAppear {
            animateWave = true
        }
    }
}

struct SummaryCardsView: View {
    @EnvironmentObject var userDataManager: UserDataManager
    @Environment(\.colorScheme) var colorScheme
    @State private var animateCards = false
    
    var body: some View {
        LazyVGrid(columns: [
            GridItem(.flexible()),
            GridItem(.flexible())
        ], spacing: 16) {
            SummaryCard(
                title: "Total Loans",
                value: "\(userDataManager.userProfile?.totalLoansCount ?? 0)",
                icon: "list.number",
                color: .blue,
                delay: 0.1
            )
            
            SummaryCard(
                title: "Total Amount",
                value: formatCurrency(userDataManager.userProfile?.totalAmount ?? 0),
                icon: "dollarsign.circle",
                color: .green,
                delay: 0.2
            )
            
            SummaryCard(
                title: "Monthly Payment",
                value: formatCurrency(userDataManager.userProfile?.totalMonthlyPayment ?? 0),
                icon: "calendar",
                color: .orange,
                delay: 0.3
            )
            
            SummaryCard(
                title: "Outstanding Principal",
                value: formatCurrency(userDataManager.userProfile?.totalOutstandingPrincipal ?? 0),
                icon: "banknote",
                color: .purple,
                delay: 0.4
            )
            
            SummaryCard(
                title: "Total Penalties",
                value: formatCurrency(userDataManager.userProfile?.totalPenalties ?? 0),
                icon: "exclamationmark.circle.fill",
                color: .red,
                delay: 0.5
            )
            
            SummaryCard(
                title: "Next Payment",
                value: userDataManager.formatNextPaymentDate(),
                icon: "clock.arrow.circlepath",
                color: .mint,
                delay: 0.6
            )
        }
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
}

struct RecentLoansView: View {
    @EnvironmentObject var userDataManager: UserDataManager
    @Binding var selectedTab: Int
    @Environment(\.colorScheme) var colorScheme
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(.ultraThinMaterial)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(gradientBackground)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(borderGradient, lineWidth: 1)
            )
            .shadow(color: shadowColor, radius: 15, x: 0, y: 8)
    }
    
    private var gradientBackground: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.green.opacity(0.05),
                Color.blue.opacity(0.05)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var borderGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.green.opacity(0.2),
                Color.blue.opacity(0.2)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var shadowColor: Color {
        colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.08)
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Your Loans")
                .font(.headline)
                .fontWeight(.semibold)
            
            VStack(spacing: 12) {
                ForEach(Array(userDataManager.loans.prefix(3))) { loan in
                    LoanRowView(loan: loan)
                }
                
                if userDataManager.loans.count > 3 {
                    Button("View All Loans (\(userDataManager.loans.count))") {
                        selectedTab = 1
                    }
                    .font(.subheadline)
                    .foregroundColor(.blue)
                    .padding(.top, 8)
                }
            }
            
            Button("Add Another Loan") {
                selectedTab = 2
            }
            .font(.subheadline)
            .fontWeight(.medium)
            .foregroundColor(.blue)
            .frame(maxWidth: .infinity)
            .frame(height: 45)
            .background(Color.blue.opacity(0.1))
            .cornerRadius(12)
        }
        .padding(20)
        .background(cardBackground)
    }
}

struct SummaryCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    let delay: Double
    @Environment(\.colorScheme) var colorScheme
    @State private var animateCard = false
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 15)
            .fill(.ultraThinMaterial)
            .background(
                RoundedRectangle(cornerRadius: 15)
                    .fill(gradientBackground)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(borderGradient, lineWidth: 1)
            )
            .shadow(color: shadowColor, radius: 10, x: 0, y: 5)
    }
    
    private var gradientBackground: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                color.opacity(0.1),
                color.opacity(0.05)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var borderGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                color.opacity(0.3),
                color.opacity(0.1)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var shadowColor: Color {
        colorScheme == .dark ? Color.white.opacity(0.05) : color.opacity(0.1)
    }
    
    var body: some View {
        VStack(spacing: 12) {
            HStack {
                ZStack {
                    Circle()
                        .fill(color.opacity(0.2))
                        .frame(width: 35, height: 35)
                    
                    Image(systemName: icon)
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(color)
                }
                
                Spacer()
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(value)
                    .font(.title3)
                    .fontWeight(.bold)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                
                Text(title)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(height: 90)
        .padding(16)
        .background(cardBackground)
        .scaleEffect(animateCard ? 1.0 : 0.9)
        .opacity(animateCard ? 1.0 : 0.0)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(delay), value: animateCard)
        .onAppear {
            animateCard = true
        }
    }
}

struct LoanRowView: View {
    let loan: LoanData
    @State private var showingDetail = false
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject var userDataManager: UserDataManager
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(.ultraThinMaterial)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(gradientBackground)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(borderGradient, lineWidth: 1)
            )
            .shadow(color: shadowColor, radius: 8, x: 0, y: 4)
    }
    
    private var gradientBackground: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.blue.opacity(0.05),
                Color.purple.opacity(0.03)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var borderGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.blue.opacity(0.2),
                Color.purple.opacity(0.1)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var shadowColor: Color {
        colorScheme == .dark ? Color.white.opacity(0.03) : Color.black.opacity(0.08)
    }
    
    var body: some View {
        Button(action: {
            showingDetail = true
        }) {
            HStack(spacing: 15) {
                // Loan type icon
                ZStack {
                    Circle()
                        .fill(LinearGradient(
                            gradient: Gradient(colors: [Color.blue, Color.cyan]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                        .frame(width: 40, height: 40)
                    
                    Image(systemName: loan.loanType.icon)
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(loan.name)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                    
                    Text("Remaining: \(formatCurrency(loan.remainingAmount))")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 4) {
                    Text(formatCurrency(loan.monthlyPayment))
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    Text("per month")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
                
                Image(systemName: "chevron.right")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding(16)
            .background(cardBackground)
        }
        .buttonStyle(PlainButtonStyle())
        .sheet(isPresented: $showingDetail) {
            LoanDetailView(loan: loan)
        }
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
}

#Preview {
    LoanTrackerDashboard()
        .environmentObject(AuthViewModel())
}
