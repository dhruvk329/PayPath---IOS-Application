import SwiftUI

struct AuthenticationView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var isSignUpMode = false
    @Environment(\.colorScheme) var colorScheme
    @State private var animateBackground = false
    @State private var animateLogo = false
    
    // Computed properties to break down complex expressions
    private var backgroundGradient: LinearGradient {
        if colorScheme == .dark {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.05, green: 0.05, blue: 0.15),
                    Color(red: 0.1, green: 0.1, blue: 0.25),
                    Color(red: 0.15, green: 0.2, blue: 0.35)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.95, green: 0.97, blue: 1.0),
                    Color(red: 0.9, green: 0.95, blue: 1.0),
                    Color(red: 0.85, green: 0.9, blue: 0.98)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    private var logoGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.blue,
                Color.purple,
                Color.blue.opacity(0.8)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var titleGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.blue,
                Color.purple,
                Color.blue.opacity(0.8)
            ]),
            startPoint: .leading,
            endPoint: .trailing
        )
    }
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 28)
            .fill(
                colorScheme == .dark ?
                Color.black.opacity(0.3) :
                Color.white.opacity(0.9)
            )
            .background(cardBorder)
            .shadow(
                color: colorScheme == .dark ?
                Color.white.opacity(0.05) :
                Color.black.opacity(0.08),
                radius: 25,
                x: 0,
                y: 15
            )
    }
    
    private var cardBorder: some View {
        RoundedRectangle(cornerRadius: 28)
            .stroke(
                LinearGradient(
                    gradient: Gradient(colors: [
                        colorScheme == .dark ? Color.white.opacity(0.1) : Color.blue.opacity(0.1),
                        colorScheme == .dark ? Color.blue.opacity(0.2) : Color.purple.opacity(0.1)
                    ]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                lineWidth: 1
            )
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background
                backgroundGradient
                    .ignoresSafeArea()
                    .scaleEffect(animateBackground ? 1.1 : 1.0)
                    .animation(.easeInOut(duration: 8).repeatForever(autoreverses: true), value: animateBackground)
                
                // Floating elements
                floatingElementsView
                
                ScrollView {
                    VStack(spacing: 0) {
                        headerSection
                        formSection
                        Spacer(minLength: 30)
                    }
                }
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            animateBackground = true
            animateLogo = true
        }
    }
    
    private var floatingElementsView: some View {
        GeometryReader { geometry in
            ForEach(0..<8, id: \.self) { index in
                let colors: [Color] = colorScheme == .dark ?
                    [Color.blue.opacity(0.1), Color.purple.opacity(0.1), Color.cyan.opacity(0.08)] :
                    [Color.blue.opacity(0.05), Color.purple.opacity(0.05), Color.pink.opacity(0.03)]
                
                Circle()
                    .fill(
                        RadialGradient(
                            gradient: Gradient(colors: [colors[index % 3], Color.clear]),
                            center: .center,
                            startRadius: 10,
                            endRadius: 60
                        )
                    )
                    .frame(width: CGFloat.random(in: 80...150))
                    .position(
                        x: CGFloat.random(in: 0...geometry.size.width),
                        y: CGFloat.random(in: 0...geometry.size.height)
                    )
                    .blur(radius: 2)
                    .scaleEffect(animateBackground ? 1.2 : 0.8)
                    .animation(
                        .easeInOut(duration: Double.random(in: 3...6))
                        .repeatForever(autoreverses: true)
                        .delay(Double(index) * 0.5),
                        value: animateBackground
                    )
            }
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 25) {
            logoView
            titleView
        }
        .padding(.top, 60)
        .padding(.bottom, 40)
    }
    
    private var logoView: some View {
        ZStack {
            // Outer glow ring
            Circle()
                .stroke(
                    LinearGradient(
                        gradient: Gradient(colors: [
                            Color.blue.opacity(0.3),
                            Color.purple.opacity(0.3),
                            Color.cyan.opacity(0.2)
                        ]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 3
                )
                .frame(width: 140, height: 140)
                .scaleEffect(animateLogo ? 1.1 : 1.0)
                .opacity(animateLogo ? 0.8 : 0.4)
                .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: animateLogo)
            
            // Main logo background
            Circle()
                .fill(logoGradient)
                .frame(width: 120, height: 120)
                .shadow(
                    color: colorScheme == .dark ? Color.blue.opacity(0.4) : Color.blue.opacity(0.3),
                    radius: 20,
                    x: 0,
                    y: 10
                )
                .scaleEffect(animateLogo ? 1.05 : 1.0)
                .animation(.easeInOut(duration: 3).repeatForever(autoreverses: true), value: animateLogo)
            
            // Logo icon
            Image(systemName: "dollarsign.circle.fill")
                .font(.system(size: 60, weight: .medium))
                .foregroundColor(.white)
                .rotationEffect(.degrees(animateLogo ? 5 : -5))
                .animation(.easeInOut(duration: 4).repeatForever(autoreverses: true), value: animateLogo)
        }
        .scaleEffect(isSignUpMode ? 0.9 : 1.0)
        .animation(.spring(response: 0.8, dampingFraction: 0.6), value: isSignUpMode)
    }
    
    private var titleView: some View {
        VStack(spacing: 12) {
            Text("PayPath")
                .font(.system(size: 42, weight: .bold, design: .rounded))
                .foregroundStyle(titleGradient)
                .scaleEffect(animateLogo ? 1.02 : 1.0)
                .animation(.easeInOut(duration: 3).repeatForever(autoreverses: true), value: animateLogo)
            
            Text(isSignUpMode ? "Create your account to start tracking loans" : "Welcome back! Sign in to continue")
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.8) : .gray)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 20)
                .opacity(animateLogo ? 0.9 : 0.7)
                .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: animateLogo)
        }
    }
    
    private var formSection: some View {
        VStack(spacing: 0) {
            // Auth form card
            VStack(spacing: 28) {
                if isSignUpMode {
                    SignUpForm()
                        .transition(.asymmetric(
                            insertion: .move(edge: .trailing).combined(with: .opacity).combined(with: .scale(scale: 0.9)),
                            removal: .move(edge: .leading).combined(with: .opacity).combined(with: .scale(scale: 0.9))
                        ))
                } else {
                    SignInForm()
                        .transition(.asymmetric(
                            insertion: .move(edge: .leading).combined(with: .opacity).combined(with: .scale(scale: 0.9)),
                            removal: .move(edge: .trailing).combined(with: .opacity).combined(with: .scale(scale: 0.9))
                        ))
                }
            }
            .padding(.horizontal, 32)
            .padding(.vertical, 40)
            .background(cardBackground)
            .padding(.horizontal, 20)
            
            toggleSection
        }
    }
    
    private var toggleSection: some View {
        VStack(spacing: 24) {
            dividerView
            toggleButton
        }
        .padding(.horizontal, 30)
        .padding(.top, 35)
        .padding(.bottom, 50)
    }
    
    private var dividerView: some View {
        HStack {
            Rectangle()
                .frame(height: 1)
                .foregroundStyle(
                    LinearGradient(
                        gradient: Gradient(colors: [
                            Color.clear,
                            colorScheme == .dark ? Color.white.opacity(0.3) : Color.gray.opacity(0.3),
                            Color.clear
                        ]),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
            
            Text("OR")
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.6) : .gray)
                .padding(.horizontal, 20)
                .background(
                    colorScheme == .dark ?
                    Color.black.opacity(0.8) :
                    Color.white.opacity(0.9)
                )
            
            Rectangle()
                .frame(height: 1)
                .foregroundStyle(
                    LinearGradient(
                        gradient: Gradient(colors: [
                            Color.clear,
                            colorScheme == .dark ? Color.white.opacity(0.3) : Color.gray.opacity(0.3),
                            Color.clear
                        ]),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
        }
    }
    
    private var toggleButton: some View {
        Button(action: {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                isSignUpMode.toggle()
            }
        }) {
            HStack(spacing: 12) {
                Image(systemName: isSignUpMode ? "person.fill.checkmark" : "person.badge.plus.fill")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.white)
                
                Text(isSignUpMode ? "Already have an account? Sign In" : "Don't have an account? Sign Up")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
            }
            .padding(.vertical, 16)
            .padding(.horizontal, 24)
            .background(toggleButtonBackground)
        }
        .scaleEffect(isSignUpMode ? 1.05 : 1.0)
        .animation(.spring(response: 0.4, dampingFraction: 0.6), value: isSignUpMode)
    }
    
    private var toggleButtonBackground: some View {
        RoundedRectangle(cornerRadius: 25)
            .fill(
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color.blue.opacity(0.8),
                        Color.purple.opacity(0.8)
                    ]),
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .shadow(
                color: Color.blue.opacity(0.3),
                radius: 10,
                x: 0,
                y: 5
            )
    }
}

#Preview("Light Mode") {
    AuthenticationView()
        .environmentObject(AuthViewModel())
        .preferredColorScheme(.light)
}

#Preview("Dark Mode") {
    AuthenticationView()
        .environmentObject(AuthViewModel())
        .preferredColorScheme(.dark)
}
