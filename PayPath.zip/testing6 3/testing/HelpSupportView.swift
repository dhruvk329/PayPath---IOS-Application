import SwiftUI
import Foundation

struct HelpSupportView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var animateElements = false
    @Environment(\.colorScheme) var colorScheme
    
    private var backgroundGradient: LinearGradient {
        if colorScheme == .dark {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.black,
                    Color(red: 0.05, green: 0.05, blue: 0.1),
                    Color(red: 0.1, green: 0.1, blue: 0.15)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.98, green: 0.99, blue: 1.0),
                    Color(red: 0.95, green: 0.97, blue: 0.99),
                    Color(red: 0.92, green: 0.95, blue: 0.98)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundGradient
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Contact Support Section
                        contactSupportSection
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : -30)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.1), value: animateElements)
                        
                        // Phone Support Section
                        phoneSupportSection
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : -20)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.2), value: animateElements)
                        
                        // Report Issues Section
                        reportIssuesSection
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : -10)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.3), value: animateElements)
                        
                        // FAQ Section
                        faqSection
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : 10)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.4), value: animateElements)
                    }
                    .padding()
                }
            }
            .navigationTitle("Help & Support")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                    .foregroundColor(.blue)
                }
            }
            .onAppear {
                withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                    animateElements = true
                }
            }
        }
    }
    
    private var contactSupportSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeader(title: "Contact Support", icon: "envelope.fill", color: .blue)
            
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 16) {
                    ZStack {
                        Circle()
                            .fill(LinearGradient(
                                gradient: Gradient(colors: [Color.blue, Color.blue.opacity(0.7)]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ))
                            .frame(width: 45, height: 45)
                            .shadow(color: Color.blue.opacity(0.3), radius: 5, x: 0, y: 2)
                        
                        Image(systemName: "envelope")
                            .font(.system(size: 20, weight: .medium))
                            .foregroundColor(.white)
                    }
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Email Support")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        
                        Button("vansh@chawlas.co.in") {
                            openEmail("vansh@chawlas.co.in")
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                    }
                    
                    Spacer()
                }
            }
            .padding(20)
            .background(cardBackground)
        }
    }
    
    private var phoneSupportSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeader(title: "Phone Support", icon: "phone.fill", color: .green)
            
            VStack(spacing: 12) {
                SupportPhoneRow(country: "India", number: "+91 7303714953", delay: 0.1)
                SupportPhoneRow(country: "USA", number: "+1 540 9348484", delay: 0.2)
                SupportPhoneRow(country: "UK", number: "+44 7493873079", delay: 0.3)
                SupportPhoneRow(country: "UAE", number: "+971 58 288 0817", delay: 0.4)
            }
            .padding(20)
            .background(cardBackground)
        }
    }
    
    private var reportIssuesSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeader(title: "Report Issues", icon: "exclamationmark.bubble.fill", color: .red)
            
            VStack(spacing: 12) {
                Button(action: reportBugs) {
                    HStack(spacing: 16) {
                        ZStack {
                            Circle()
                                .fill(LinearGradient(
                                    gradient: Gradient(colors: [Color.red, Color.red.opacity(0.7)]),
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ))
                                .frame(width: 45, height: 45)
                                .shadow(color: Color.red.opacity(0.3), radius: 5, x: 0, y: 2)
                            
                            Image(systemName: "exclamationmark.bubble")
                                .font(.system(size: 20, weight: .medium))
                                .foregroundColor(.white)
                        }
                        
                        Text("Report Bugs")
                            .font(.headline)
                            .fontWeight(.medium)
                            .foregroundColor(.primary)
                        
                        Spacer()
                        
                        Image(systemName: "chevron.right")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.secondary)
                    }
                }
                .buttonStyle(PlainButtonStyle())
                
                Text("Opens your email app to send bug reports directly to our support team.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .padding(.top, 4)
            }
            .padding(20)
            .background(cardBackground)
        }
    }
    
    private var faqSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeader(title: "FAQ", icon: "questionmark.circle.fill", color: .purple)
            
            VStack(alignment: .leading, spacing: 16) {
                FAQItem(
                    question: "How do I add a new loan?",
                    answer: "Tap the 'Add Loan' tab and fill in your loan details.",
                    delay: 0.1
                )
                
                FAQItem(
                    question: "Can I edit my loan information?",
                    answer: "Yes, go to the 'All Debts' section and tap 'Edit' on any loan.",
                    delay: 0.2
                )
                
                FAQItem(
                    question: "How do payment reminders work?",
                    answer: "Enable notifications in your profile to get reminders before due dates.",
                    delay: 0.3
                )
            }
            .padding(20)
            .background(cardBackground)
        }
    }
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 15)
            .fill(.ultraThinMaterial)
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
            )
            .shadow(color: colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
    }
    
    private func sectionHeader(title: String, icon: String, color: Color) -> some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(LinearGradient(
                        gradient: Gradient(colors: [color, color.opacity(0.7)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                    .frame(width: 35, height: 35)
                    .shadow(color: color.opacity(0.3), radius: 3, x: 0, y: 2)
                
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.white)
            }
            
            Text(title)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Spacer()
        }
    }
    
    private func openEmail(_ email: String) {
        if let url = URL(string: "mailto:\(email)") {
            UIApplication.shared.open(url)
        }
    }
    
    private func reportBugs() {
        let userEmail = userDataManager.userProfile?.email ?? "your-email@example.com"
        let userName = userDataManager.userProfile?.fullName ?? "User"
        
        let subject = "Bug Report - PayPath App".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let body = """
        Hi Vansh,
        
        I would like to report a bug in the PayPath app.
        
        User Details:
        Name: \(userName)
        Email: \(userEmail)
        Device: \(UIDevice.current.model)
        iOS Version: \(UIDevice.current.systemVersion)
        App Version: 1.0
        
        Bug Description:
        [Please describe the bug you encountered here]
        
        Steps to Reproduce:
        1. [Step 1]
        2. [Step 2]
        3. [Step 3]
        
        Expected Behavior:
        [What you expected to happen]
        
        Actual Behavior:
        [What actually happened]
        
        Additional Information:
        [Any other relevant information]
        
        Best regards,
        \(userName)
        """.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        
        if let url = URL(string: "mailto:vansh@chawlas.co.in?subject=\(subject)&body=\(body)") {
            UIApplication.shared.open(url)
        }
    }
}

struct SupportPhoneRow: View {
    let country: String
    let number: String
    let delay: Double
    @State private var animateRow = false
    
    var body: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(LinearGradient(
                        gradient: Gradient(colors: [Color.green, Color.green.opacity(0.7)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                    .frame(width: 35, height: 35)
                    .shadow(color: Color.green.opacity(0.3), radius: 3, x: 0, y: 2)
                
                Image(systemName: "phone")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.white)
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(country)
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Button(number) {
                    callPhone(number)
                }
                .font(.caption)
                .foregroundColor(.blue)
            }
            
            Spacer()
        }
        .opacity(animateRow ? 1.0 : 0.0)
        .offset(x: animateRow ? 0 : -30)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(delay), value: animateRow)
        .onAppear {
            animateRow = true
        }
    }
    
    private func callPhone(_ number: String) {
        let cleanNumber = number.replacingOccurrences(of: " ", with: "")
        if let url = URL(string: "tel:\(cleanNumber)") {
            UIApplication.shared.open(url)
        }
    }
}

struct FAQItem: View {
    let question: String
    let answer: String
    let delay: Double
    @State private var isExpanded = false
    @State private var animateItem = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button(action: {
                withAnimation(.easeInOut(duration: 0.3)) {
                    isExpanded.toggle()
                }
            }) {
                HStack {
                    Text(question)
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.leading)
                    
                    Spacer()
                    
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .rotationEffect(.degrees(isExpanded ? 180 : 0))
                        .animation(.easeInOut(duration: 0.3), value: isExpanded)
                }
            }
            .buttonStyle(PlainButtonStyle())
            
            if isExpanded {
                Text(answer)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .padding(.leading, 8)
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .opacity(animateItem ? 1.0 : 0.0)
        .offset(y: animateItem ? 0 : 20)
        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(delay), value: animateItem)
        .onAppear {
            animateItem = true
        }
    }
}

#Preview {
    HelpSupportView()
        .environmentObject(UserDataManager())
}
