import SwiftUI
import FirebaseAuth

struct PrivacySecurityView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @EnvironmentObject var userDataManager: UserDataManager
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) var colorScheme
    
    @State private var fullName = ""
    @State private var currentPassword = ""
    @State private var newPassword = ""
    @State private var confirmPassword = ""
    @State private var isLoading = false
    @State private var showingAlert = false
    @State private var alertMessage = ""
    @State private var alertTitle = "Update"
    @State private var animateElements = false
    
    @State private var biometricAuthEnabled = false
    @State private var isTestingBiometrics = false
    
    @State private var showingPrivacyPolicy = false
    
    private var backgroundGradient: LinearGradient {
        if colorScheme == .dark {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.black,
                    Color(red: 0.05, green: 0.05, blue: 0.1),
                    Color(red: 0.1, green: 0.1, blue: 0.15)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.98, green: 0.99, blue: 1.0),
                    Color(red: 0.95, green: 0.97, blue: 0.99),
                    Color(red: 0.92, green: 0.95, blue: 0.98)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundGradient
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        profileSection
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : -30)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.1), value: animateElements)
                        
                        passwordSection
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : -20)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.2), value: animateElements)
                        
                        biometricAuthSection
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : -10)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.3), value: animateElements)
                        
                        dataProtectionSection
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : 10)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.4), value: animateElements)
                        
                        privacyPolicySection
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : 20)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.5), value: animateElements)
                    }
                    .padding()
                }
            }
            .navigationTitle("Privacy & Security")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                    .foregroundColor(.blue)
                }
            }
            .onAppear {
                loadCurrentProfile()
                withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                    animateElements = true
                }
            }
            .alert(alertTitle, isPresented: $showingAlert) {
                Button("OK") {
                    if alertMessage.contains("successfully") {
                        if alertTitle == "Name Updated" {
                            // Clear only name field on successful name update
                        } else {
                            // Clear password fields on successful password update
                            currentPassword = ""
                            newPassword = ""
                            confirmPassword = ""
                        }
                    }
                }
            } message: {
                Text(alertMessage)
            }
        }
    }
    
    private var profileSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeader(title: "Profile Information", icon: "person.fill", color: .blue)
            
            VStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Full Name")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    
                    TextField("Enter your full name", text: $fullName)
                        .textFieldStyle(CustomTextFieldStyle())
                }
                
                Button(action: updateName) {
                    HStack {
                        if isLoading {
                            ProgressView()
                                .scaleEffect(0.8)
                            Text("Updating...")
                        } else {
                            Text("Update Name")
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 45)
                    .background(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.blue, Color.blue.opacity(0.8)]),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .disabled(isLoading || fullName.isEmpty || fullName == (userDataManager.userProfile?.fullName ?? ""))
                }
            }
            .padding(20)
            .background(cardBackground)
        }
    }
    
    private var passwordSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeader(title: "Change Password", icon: "lock.fill", color: .purple)
            
            VStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Current Password")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    
                    SecureField("Enter current password", text: $currentPassword)
                        .textFieldStyle(CustomTextFieldStyle())
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("New Password")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    
                    SecureField("Enter new password", text: $newPassword)
                        .textFieldStyle(CustomTextFieldStyle())
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Confirm New Password")
                        .font(.subheadline)
                        .fontWeight(.medium)
                    
                    SecureField("Confirm new password", text: $confirmPassword)
                        .textFieldStyle(CustomTextFieldStyle())
                }
                
                Button(action: changePassword) {
                    HStack {
                        if isLoading {
                            ProgressView()
                                .scaleEffect(0.8)
                            Text("Updating...")
                        } else {
                            Text("Change Password")
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 45)
                    .background(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.purple, Color.purple.opacity(0.8)]),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .disabled(isLoading || currentPassword.isEmpty || newPassword.isEmpty || confirmPassword.isEmpty)
                }
            }
            .padding(20)
            .background(cardBackground)
        }
    }
    
    private var biometricAuthSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeader(title: "Biometric Authentication", icon: "faceid", color: .green)
            
            VStack(spacing: 16) {
                HStack {
                    Text("Enable \(authViewModel.biometricAuthManager.biometricTypeString)")
                        .font(.headline)
                        .fontWeight(.medium)
                    
                    Spacer()
                    
                    Toggle("", isOn: $biometricAuthEnabled)
                        .disabled(isTestingBiometrics || !authViewModel.biometricAuthManager.canUseBiometrics)
                        .onChange(of: biometricAuthEnabled) { enabled in
                            handleBiometricToggle(enabled: enabled)
                        }
                }
                
                if isTestingBiometrics {
                    HStack {
                        ProgressView()
                            .scaleEffect(0.8)
                        Text("Testing biometric authentication...")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                }
                
                if authViewModel.biometricAuthManager.canUseBiometrics {
                    HStack {
                        Image(systemName: authViewModel.biometricAuthManager.biometricIcon)
                            .foregroundColor(.blue)
                        Text("Secure your app with \(authViewModel.biometricAuthManager.biometricTypeString)")
                            .font(.subheadline)
                    }
                    .padding(.vertical, 4)
                } else {
                    HStack {
                        Image(systemName: "exclamationmark.triangle")
                            .foregroundColor(.orange)
                        Text("Biometric authentication not available on this device")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                }
                
                if let error = authViewModel.biometricAuthManager.authenticationError {
                    HStack {
                        Image(systemName: "exclamationmark.circle")
                            .foregroundColor(.red)
                        Text(error)
                            .font(.caption)
                            .foregroundColor(.red)
                    }
                    .padding(.vertical, 4)
                }
            }
            .padding(20)
            .background(cardBackground)
        }
    }
    
    private var dataProtectionSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeader(title: "Data Protection", icon: "shield.fill", color: .orange)
            
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Image(systemName: "lock.shield")
                        .foregroundColor(.green)
                    Text("Your data is encrypted and secure")
                        .font(.subheadline)
                }
                
                HStack {
                    Image(systemName: "icloud")
                        .foregroundColor(.blue)
                    Text("Backed up to your iCloud account")
                        .font(.subheadline)
                }
                
                HStack {
                    Image(systemName: "eye.slash")
                        .foregroundColor(.orange)
                    Text("We never share your personal information")
                        .font(.subheadline)
                }
            }
            .padding(20)
            .background(cardBackground)
        }
    }
    
    private var privacyPolicySection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeader(title: "Privacy Policy", icon: "doc.text.fill", color: .red)
            
            VStack(alignment: .leading, spacing: 16) {
                Button("View Privacy Policy") {
                    showingPrivacyPolicy = true
                }
                .foregroundColor(.blue)
                .font(.headline)
                
                Text("Last updated: January 2025")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding(20)
            .background(cardBackground)
        }
        .sheet(isPresented: $showingPrivacyPolicy) {
            PrivacyPolicyDetailView()
        }
    }
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 15)
            .fill(.ultraThinMaterial)
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
            )
            .shadow(color: colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
    }
    
    private func sectionHeader(title: String, icon: String, color: Color) -> some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(LinearGradient(
                        gradient: Gradient(colors: [color, color.opacity(0.7)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                    .frame(width: 35, height: 35)
                    .shadow(color: color.opacity(0.3), radius: 3, x: 0, y: 2)
                
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.white)
            }
            
            Text(title)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Spacer()
        }
    }
    
    private func loadCurrentProfile() {
        fullName = userDataManager.userProfile?.fullName ?? ""
        biometricAuthEnabled = UserDefaults.standard.bool(forKey: "biometricAuthEnabled")
    }
    
    private func handleBiometricToggle(enabled: Bool) {
        guard !isTestingBiometrics else { return }
        
        if enabled {
            // Test biometric authentication before enabling
            isTestingBiometrics = true
            
            Task {
                print("🔐 Testing biometric authentication from settings...")
                let success = await authViewModel.biometricAuthManager.authenticateWithBiometrics()
                
                await MainActor.run {
                    isTestingBiometrics = false
                    
                    if success {
                        print("✅ Biometric test successful - enabling")
                        authViewModel.enableBiometricAuth()
                        UserDefaults.standard.set(true, forKey: "biometricAuthEnabled")
                        
                        alertTitle = "Face ID Enabled"
                        alertMessage = "Face ID has been successfully enabled for your app."
                        showingAlert = true
                    } else {
                        print("❌ Biometric test failed - not enabling")
                        // Reset toggle if authentication failed
                        biometricAuthEnabled = false
                        
                        alertTitle = "Face ID Setup Failed"
                        alertMessage = authViewModel.biometricAuthManager.authenticationError ?? "Unable to enable Face ID"
                        showingAlert = true
                    }
                }
            }
        } else {
            print("🔐 Disabling biometric authentication")
            authViewModel.disableBiometricAuth()
            UserDefaults.standard.set(false, forKey: "biometricAuthEnabled")
            
            alertTitle = "Face ID Disabled"
            alertMessage = "Face ID has been disabled for your app."
            showingAlert = true
        }
    }
    
    private func updateName() {
        guard !fullName.isEmpty else {
            alertTitle = "Error"
            alertMessage = "Please enter your full name"
            showingAlert = true
            return
        }
        
        isLoading = true
        
        // Update the user profile with new name
        userDataManager.updateUserProfile(fullName: fullName, email: userDataManager.userProfile?.email ?? "") { success, error in
            DispatchQueue.main.async {
                isLoading = false
                if success {
                    alertTitle = "Name Updated"
                    alertMessage = "Your name has been updated successfully!"
                } else {
                    alertTitle = "Error"
                    alertMessage = error ?? "Failed to update name"
                }
                showingAlert = true
            }
        }
    }
    
    private func changePassword() {
        guard newPassword == confirmPassword else {
            alertTitle = "Error"
            alertMessage = "New passwords don't match"
            showingAlert = true
            return
        }
        
        guard newPassword.count >= 6 else {
            alertTitle = "Error"
            alertMessage = "Password must be at least 6 characters long"
            showingAlert = true
            return
        }
        
        guard let user = Auth.auth().currentUser,
              let email = user.email else {
            alertTitle = "Error"
            alertMessage = "Unable to verify current user"
            showingAlert = true
            return
        }
        
        isLoading = true
        
        Task {
            do {
                // Re-authenticate user with current password
                let credential = EmailAuthProvider.credential(withEmail: email, password: currentPassword)
                try await user.reauthenticate(with: credential)
                
                // Update password
                try await user.updatePassword(to: newPassword)
                
                await MainActor.run {
                    isLoading = false
                    alertTitle = "Password Changed"
                    alertMessage = "Password changed successfully!"
                    showingAlert = true
                }
            } catch {
                await MainActor.run {
                    isLoading = false
                    alertTitle = "Error"
                    alertMessage = "Failed to change password: \(error.localizedDescription)"
                    showingAlert = true
                }
            }
        }
    }
}

struct CustomTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding(12)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.blue.opacity(0.3), lineWidth: 1)
            )
    }
}

struct PrivacyPolicyDetailView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Privacy Policy")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.bottom, 10)
                    
                    Text("Effective Date: January 1, 2025")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .padding(.bottom, 20)
                    
                    privacySection(
                        title: "1. Information We Collect",
                        content: """
                        We collect information you provide directly to us, such as:
                        • Personal information (name, email address)
                        • Financial information (loan details, payment amounts, interest rates)
                        • Device information and usage data
                        • Biometric data (if you enable Face ID/Touch ID)
                        """
                    )
                    
                    privacySection(
                        title: "2. How We Use Your Information",
                        content: """
                        We use your information to:
                        • Provide and maintain our loan tracking services
                        • Calculate loan payments and generate reports
                        • Send you notifications about your loans
                        • Improve our app and user experience
                        • Ensure the security of your account
                        """
                    )
                    
                    privacySection(
                        title: "3. Information Sharing",
                        content: """
                        We do not sell, trade, or rent your personal information to third parties. We may share your information only in the following circumstances:
                        • With your explicit consent
                        • To comply with legal obligations
                        • To protect our rights and safety
                        • With service providers who assist in app functionality
                        """
                    )
                    
                    privacySection(
                        title: "4. Data Security",
                        content: """
                        We implement appropriate security measures to protect your information:
                        • End-to-end encryption for sensitive data
                        • Secure cloud storage with industry-standard protocols
                        • Biometric authentication options
                        • Regular security audits and updates
                        """
                    )
                    
                    privacySection(
                        title: "5. Your Rights",
                        content: """
                        You have the right to:
                        • Access your personal information
                        • Correct inaccurate information
                        • Delete your account and data
                        • Export your data
                        • Opt-out of certain communications
                        """
                    )
                    
                    privacySection(
                        title: "6. Data Retention",
                        content: """
                        We retain your information for as long as your account is active or as needed to provide services. You may delete your account at any time, and we will remove your data within 30 days.
                        """
                    )
                    
                    privacySection(
                        title: "7. Children's Privacy",
                        content: """
                        Our service is not intended for children under 13. We do not knowingly collect personal information from children under 13.
                        """
                    )
                    
                    privacySection(
                        title: "8. Changes to This Policy",
                        content: """
                        We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy in the app and updating the effective date.
                        """
                    )
                    
                    privacySection(
                        title: "9. Contact Us",
                        content: """
                        If you have questions about this privacy policy, please contact us at:
                        Email: privacy@paypath.app
                        Address: PayPath Privacy Team, 123 Finance St, Tech City, TC 12345
                        """
                    )
                }
                .padding()
            }
            .navigationTitle("Privacy Policy")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func privacySection(title: String, content: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Text(content)
                .font(.body)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 8)
    }
}

#Preview {
    PrivacySecurityView()
        .environmentObject(AuthViewModel())
        .environmentObject(UserDataManager())
}
