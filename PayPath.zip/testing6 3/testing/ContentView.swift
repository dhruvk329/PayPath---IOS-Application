import SwiftUI

struct ContentView: View {
    @StateObject private var authViewModel = AuthViewModel()
    @Environment(\.scenePhase) private var scenePhase
    @State private var showWelcome = true
    
    var body: some View {
        Group {
            if showWelcome && !authViewModel.isAuthenticated {
                WelcomeView(onSwipeUp: {
                    withAnimation(.spring(response: 0.8, dampingFraction: 0.7)) {
                        showWelcome = false
                    }
                })
                .transition(.asymmetric(
                    insertion: .identity,
                    removal: .move(edge: .top).combined(with: .opacity)
                ))
            } else if authViewModel.isAuthenticated {
                if authViewModel.requiresBiometricAuth && !authViewModel.biometricAuthManager.isAuthenticated {
                    BiometricAuthView()
                        .environmentObject(authViewModel)
                } else {
                    LoanTrackerDashboard()
                        .environmentObject(authViewModel)
                        .environmentObject(authViewModel.userDataManager)
                }
            } else {
                AuthenticationView()
                    .environmentObject(authViewModel)
                    .transition(.asymmetric(
                        insertion: .move(edge: .bottom).combined(with: .opacity),
                        removal: .move(edge: .bottom).combined(with: .opacity)
                    ))
            }
        }
        .onAppear {
            authViewModel.checkAuthenticationState()
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active && authViewModel.isAuthenticated && authViewModel.requiresBiometricAuth {
                // Reset biometric auth when app becomes active
                authViewModel.biometricAuthManager.isAuthenticated = false
            }
        }
        .onChange(of: authViewModel.isAuthenticated) { isAuthenticated in
            // Show welcome screen when user logs out
            if !isAuthenticated {
                withAnimation(.spring(response: 0.8, dampingFraction: 0.7)) {
                    showWelcome = true
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
