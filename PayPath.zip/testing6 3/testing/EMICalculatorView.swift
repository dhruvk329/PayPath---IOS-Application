import SwiftUI
import Charts

struct EMICalculatorView: View {
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var loanAmount = ""
    @State private var interestRate = ""
    @State private var loanTenure = ""
    @State private var tenureType = TenureType.years
    @State private var emi: Double = 0
    @State private var totalInterest: Double = 0
    @State private var totalAmount: Double = 0
    @State private var showingResults = false
    @State private var showingBreakdown = false
    @State private var showingSimulation = false
    @State private var animateHeader = false
    @State private var animateForm = false
    @State private var animateButton = false
    @State private var animateResults = false
    @Environment(\.colorScheme) var colorScheme
    @FocusState private var focusedField: FormField?
    
    enum FormField {
        case loanAmount, interestRate, loanTenure
    }
    
    enum TenureType: String, CaseIterable {
        case years = "Years"
        case months = "Months"
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Animated Header
                    EMICalculatorHeader()
                        .scaleEffect(animateHeader ? 1.0 : 0.8)
                        .opacity(animateHeader ? 1.0 : 0.0)
                        .animation(.spring(response: 0.8, dampingFraction: 0.8, blendDuration: 0).delay(0.1), value: animateHeader)
                    
                    // Animated Input Form
                    EMIInputForm(
                        loanAmount: $loanAmount,
                        interestRate: $interestRate,
                        loanTenure: $loanTenure,
                        tenureType: $tenureType,
                        focusedField: $focusedField
                    )
                    .scaleEffect(animateForm ? 1.0 : 0.9)
                    .opacity(animateForm ? 1.0 : 0.0)
                    .animation(.spring(response: 0.8, dampingFraction: 0.8, blendDuration: 0).delay(0.3), value: animateForm)
                    
                    // Animated Calculate Button
                    calculateButton
                        .scaleEffect(animateButton ? 1.0 : 0.9)
                        .opacity(animateButton ? 1.0 : 0.0)
                        .animation(.spring(response: 0.8, dampingFraction: 0.8, blendDuration: 0).delay(0.5), value: animateButton)
                    
                    // Animated Results Section
                    if showingResults {
                        EMIResultsView(
                            emi: emi,
                            totalInterest: totalInterest,
                            totalAmount: totalAmount,
                            showingBreakdown: $showingBreakdown,
                            showingSimulation: $showingSimulation
                        )
                        .scaleEffect(animateResults ? 1.0 : 0.8)
                        .opacity(animateResults ? 1.0 : 0.0)
                        .animation(.spring(response: 0.8, dampingFraction: 0.8, blendDuration: 0).delay(0.2), value: animateResults)
                        
                        // What If Simulation
                        if showingSimulation {
                            WhatIfSimulationView(
                                originalLoanAmount: Double(loanAmount) ?? 0,
                                originalEMI: emi,
                                originalInterestRate: Double(interestRate) ?? 0,
                                originalTenure: getTenureInMonths()
                            )
                            .transition(.asymmetric(
                                insertion: .scale.combined(with: .opacity),
                                removal: .scale.combined(with: .opacity)
                            ))
                        }
                        
                        // Detailed Breakdown
                        if showingBreakdown {
                            EMIBreakdownView(
                                loanAmount: Double(loanAmount) ?? 0,
                                emi: emi,
                                interestRate: Double(interestRate) ?? 0,
                                tenure: getTenureInMonths()
                            )
                            .transition(.asymmetric(
                                insertion: .scale.combined(with: .opacity),
                                removal: .scale.combined(with: .opacity)
                            ))
                        }
                    }
                    
                    Spacer(minLength: 50)
                }
                .padding()
            }
            .background(backgroundGradient)
            .navigationTitle("EMI Calculator")
            .navigationBarTitleDisplayMode(.inline)
            .onTapGesture {
                dismissKeyboard()
            }
            .onAppear {
                startAnimations()
            }
        }
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Done") {
                    dismissKeyboard()
                }
                .foregroundColor(.blue)
                .fontWeight(.semibold)
            }
        }
    }
    
    private func dismissKeyboard() {
        focusedField = nil
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    private var backgroundGradient: some View {
        LinearGradient(
            gradient: Gradient(colors: [
                colorScheme == .dark ? Color.black : Color(UIColor.systemGroupedBackground),
                colorScheme == .dark ? Color.gray.opacity(0.1) : Color.blue.opacity(0.05)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
    }
    
    private var calculateButton: some View {
        Button(action: {
            dismissKeyboard()
            withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                calculateEMI()
            }
        }) {
            HStack {
                Image(systemName: "function")
                    .font(.headline)
                
                Text("Calculate EMI")
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .background(
                Group {
                    if isFormValid {
                        LinearGradient(
                            gradient: Gradient(colors: [Color.blue, Color.purple]),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    } else {
                        Color.gray.opacity(0.3)
                    }
                }
            )
            .foregroundColor(isFormValid ? .white : .secondary)
            .cornerRadius(16)
            .shadow(
                color: isFormValid ? Color.blue.opacity(0.3) : Color.clear,
                radius: isFormValid ? 8 : 0,
                x: 0,
                y: 4
            )
            .scaleEffect(isFormValid ? 1.0 : 0.98)
            .animation(.easeInOut(duration: 0.2), value: isFormValid)
        }
        .disabled(!isFormValid)
        .buttonStyle(InteractiveButtonStyle())
    }
    
    private var isFormValid: Bool {
        !loanAmount.isEmpty &&
        !interestRate.isEmpty &&
        !loanTenure.isEmpty &&
        Double(loanAmount) != nil &&
        Double(interestRate) != nil &&
        Double(loanTenure) != nil &&
        (Double(loanAmount) ?? 0) > 0 &&
        (Double(interestRate) ?? 0) > 0 &&
        (Double(loanTenure) ?? 0) > 0
    }
    
    private func startAnimations() {
        withAnimation {
            animateHeader = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            withAnimation {
                animateForm = true
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            withAnimation {
                animateButton = true
            }
        }
    }
    
    private func getTenureInMonths() -> Int {
        let tenure = Double(loanTenure) ?? 0
        return tenureType == .years ? Int(tenure * 12) : Int(tenure)
    }
    
    private func calculateEMI() {
        guard let principal = Double(loanAmount),
              let rate = Double(interestRate),
              let tenure = Double(loanTenure) else { return }
        
        let tenureInMonths = tenureType == .years ? tenure * 12 : tenure
        let monthlyRate = rate / (12 * 100)
        
        if monthlyRate == 0 {
            emi = principal / tenureInMonths
        } else {
            let numerator = principal * monthlyRate * pow(1 + monthlyRate, tenureInMonths)
            let denominator = pow(1 + monthlyRate, tenureInMonths) - 1
            emi = numerator / denominator
        }
        
        totalAmount = emi * tenureInMonths
        totalInterest = totalAmount - principal
        
        withAnimation(.easeInOut(duration: 0.5)) {
            showingResults = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            withAnimation {
                animateResults = true
            }
        }
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
}

struct InteractiveButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .animation(.easeInOut(duration: 0.1), value: configuration.isPressed)
    }
}

struct EMICalculatorHeader: View {
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(spacing: 16) {
            // Animated Icon
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.blue.opacity(0.2), Color.purple.opacity(0.2)]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 80, height: 80)
                
                Image(systemName: "function")
                    .font(.system(size: 36, weight: .medium))
                    .foregroundStyle(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.blue, Color.purple]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
            }
            
            VStack(spacing: 8) {
                Text("EMI Calculator")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.primary, Color.blue]),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                
                Text("Calculate your Equated Monthly Installment")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(24)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.blue.opacity(0.3),
                                    Color.purple.opacity(0.3),
                                    Color.clear
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .shadow(
            color: Color.blue.opacity(0.1),
            radius: 20,
            x: 0,
            y: 10
        )
    }
}

struct EMIInputForm: View {
    @Binding var loanAmount: String
    @Binding var interestRate: String
    @Binding var loanTenure: String
    @Binding var tenureType: EMICalculatorView.TenureType
    @FocusState.Binding var focusedField: EMICalculatorView.FormField?
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        VStack(spacing: 20) {
            // Loan Amount Field
            loanAmountField
            
            // Interest Rate Field
            interestRateField
            
            // Loan Tenure Field
            loanTenureField
        }
        .padding(24)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.green.opacity(0.3),
                                    Color.blue.opacity(0.3),
                                    Color.clear
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .shadow(
            color: Color.green.opacity(0.1),
            radius: 15,
            x: 0,
            y: 8
        )
    }
    
    private var loanAmountField: some View {
        EMIInputField(
            title: "Loan Amount",
            text: $loanAmount,
            placeholder: "100000",
            prefix: userDataManager.getCurrencySymbol(),
            keyboardType: .decimalPad,
            isFocused: focusedField == .loanAmount,
            gradientColors: [Color.blue, Color.cyan],
            focusedField: $focusedField,
            fieldType: .loanAmount
        )
    }
    
    private var interestRateField: some View {
        EMIInputField(
            title: "Annual Interest Rate",
            text: $interestRate,
            placeholder: "8.5",
            suffix: "%",
            keyboardType: .decimalPad,
            isFocused: focusedField == .interestRate,
            gradientColors: [Color.orange, Color.red],
            focusedField: $focusedField,
            fieldType: .interestRate
        )
    }
    
    private var loanTenureField: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "calendar")
                    .font(.headline)
                    .foregroundStyle(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.purple, Color.pink]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                
                Text("Loan Tenure")
                    .font(.subheadline)
                    .fontWeight(.semibold)
            }
            
            HStack(spacing: 16) {
                TextField("24", text: $loanTenure)
                    .keyboardType(.numberPad)
                    .focused($focusedField, equals: .loanTenure)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(colorScheme == .dark ? .white : .primary)
                    .padding(16)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color(UIColor.tertiarySystemGroupedBackground))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(
                                        focusedField == .loanTenure ?
                                        LinearGradient(
                                            gradient: Gradient(colors: [Color.purple, Color.pink]),
                                            startPoint: .leading,
                                            endPoint: .trailing
                                        ) :
                                        LinearGradient(
                                            gradient: Gradient(colors: [Color.clear]),
                                            startPoint: .leading,
                                            endPoint: .trailing
                                        ),
                                        lineWidth: 2
                                    )
                            )
                    )
                    .scaleEffect(focusedField == .loanTenure ? 1.02 : 1.0)
                    .animation(.easeInOut(duration: 0.2), value: focusedField == .loanTenure)
                
                Picker("Tenure Type", selection: $tenureType) {
                    ForEach(EMICalculatorView.TenureType.allCases, id: \.self) { type in
                        Text(type.rawValue).tag(type)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .frame(width: 140)
            }
        }
    }
}

struct EMIInputField: View {
    let title: String
    @Binding var text: String
    let placeholder: String
    var prefix: String = ""
    var suffix: String = ""
    var keyboardType: UIKeyboardType = .default
    let isFocused: Bool
    let gradientColors: [Color]
    @FocusState.Binding var focusedField: EMICalculatorView.FormField?
    let fieldType: EMICalculatorView.FormField
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: iconName)
                    .font(.headline)
                    .foregroundStyle(
                        LinearGradient(
                            gradient: Gradient(colors: gradientColors),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                
                Text(title)
                    .font(.subheadline)
                    .fontWeight(.semibold)
            }
            
            HStack(spacing: 8) {
                if !prefix.isEmpty {
                    Text(prefix)
                        .font(.body)
                        .fontWeight(.medium)
                        .foregroundColor(.secondary)
                }
                
                TextField(placeholder, text: $text)
                    .keyboardType(keyboardType)
                    .focused($focusedField, equals: fieldType)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(colorScheme == .dark ? .white : .primary)
                    .submitLabel(.done)
                    .onSubmit {
                        focusedField = nil
                    }
                
                if !suffix.isEmpty {
                    Text(suffix)
                        .font(.body)
                        .fontWeight(.medium)
                        .foregroundColor(.secondary)
                }
            }
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(UIColor.tertiarySystemGroupedBackground))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(
                                isFocused ?
                                LinearGradient(
                                    gradient: Gradient(colors: gradientColors),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                ) :
                                LinearGradient(
                                    gradient: Gradient(colors: [Color.clear]),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                ),
                                lineWidth: 2
                            )
                    )
            )
            .scaleEffect(isFocused ? 1.02 : 1.0)
            .animation(.easeInOut(duration: 0.2), value: isFocused)
        }
    }
    
    private var iconName: String {
        if title.contains("Amount") {
            return "dollarsign.circle"
        } else if title.contains("Rate") {
            return "percent"
        } else {
            return "calendar"
        }
    }
}

struct EMIResultsView: View {
    let emi: Double
    let totalInterest: Double
    let totalAmount: Double
    @Binding var showingBreakdown: Bool
    @Binding var showingSimulation: Bool
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var animateCards = false
    @State private var animateChart = false
    @State private var animateButtons = false
    
    var body: some View {
        VStack(spacing: 24) {
            // Header
            headerSection
            
            // Main EMI Display
            mainEMICard
            
            // Summary Cards
            summaryCards
            
            // Pie Chart
            pieChartSection
            
            // Action Buttons
            actionButtons
        }
        .padding(24)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.blue.opacity(0.3),
                                    Color.green.opacity(0.3),
                                    Color.clear
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .shadow(
            color: Color.blue.opacity(0.1),
            radius: 20,
            x: 0,
            y: 10
        )
        .onAppear {
            startResultAnimations()
        }
    }
    
    private var headerSection: some View {
        HStack {
            Image(systemName: "chart.bar.fill")
                .font(.title2)
                .foregroundStyle(
                    LinearGradient(
                        gradient: Gradient(colors: [Color.blue, Color.green]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            
            Text("EMI Calculation Results")
                .font(.headline)
                .fontWeight(.semibold)
            
            Spacer()
        }
    }
    
    private var mainEMICard: some View {
        VStack(spacing: 12) {
            Text("Monthly EMI")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .fontWeight(.medium)
            
            Text(formatCurrency(emi))
                .font(.system(size: 36, weight: .bold, design: .rounded))
                .foregroundStyle(
                    LinearGradient(
                        gradient: Gradient(colors: [Color.blue, Color.purple]),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
        }
        .padding(24)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(
                    LinearGradient(
                        gradient: Gradient(colors: [
                            Color.blue.opacity(0.1),
                            Color.purple.opacity(0.05)
                        ]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.blue.opacity(0.3),
                                    Color.purple.opacity(0.3)
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .scaleEffect(animateCards ? 1.0 : 0.8)
        .opacity(animateCards ? 1.0 : 0.0)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.1), value: animateCards)
    }
    
    private var summaryCards: some View {
        HStack(spacing: 16) {
            EMIResultCard(
                title: "Total Interest",
                value: formatCurrency(totalInterest),
                color: .orange,
                icon: "percent"
            )
            .scaleEffect(animateCards ? 1.0 : 0.8)
            .opacity(animateCards ? 1.0 : 0.0)
            .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.2), value: animateCards)
            
            EMIResultCard(
                title: "Total Amount",
                value: formatCurrency(totalAmount),
                color: .green,
                icon: "sum"
            )
            .scaleEffect(animateCards ? 1.0 : 0.8)
            .opacity(animateCards ? 1.0 : 0.0)
            .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.3), value: animateCards)
        }
    }
    
    private var pieChartSection: some View {
        EMIPieChart(
            principal: totalAmount - totalInterest,
            interest: totalInterest
        )
        .scaleEffect(animateChart ? 1.0 : 0.8)
        .opacity(animateChart ? 1.0 : 0.0)
        .animation(.spring(response: 0.8, dampingFraction: 0.8).delay(0.4), value: animateChart)
    }
    
    private var actionButtons: some View {
        VStack(spacing: 16) {
            actionButton(
                title: "What If Scenarios",
                icon: "wand.and.stars",
                colors: [Color.purple, Color.pink],
                action: {
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                        showingSimulation.toggle()
                    }
                }
            )
            
            actionButton(
                title: "View Detailed Breakdown",
                icon: "chart.line.uptrend.xyaxis",
                colors: [Color.blue, Color.cyan],
                action: {
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                        showingBreakdown.toggle()
                    }
                }
            )
        }
        .scaleEffect(animateButtons ? 1.0 : 0.9)
        .opacity(animateButtons ? 1.0 : 0.0)
        .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.5), value: animateButtons)
    }
    
    private func actionButton(title: String, icon: String, colors: [Color], action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                    .font(.headline)
                
                Text(title)
                    .font(.headline)
                    .fontWeight(.medium)
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.subheadline)
                    .opacity(0.7)
            }
            .padding(20)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: colors.map { $0.opacity(0.1) }),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(
                                LinearGradient(
                                    gradient: Gradient(colors: colors.map { $0.opacity(0.3) }),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                ),
                                lineWidth: 1
                            )
                    )
            )
            .foregroundStyle(
                LinearGradient(
                    gradient: Gradient(colors: colors),
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
        }
        .buttonStyle(InteractiveButtonStyle())
    }
    
    private func startResultAnimations() {
        withAnimation {
            animateCards = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            withAnimation {
                animateChart = true
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            withAnimation {
                animateButtons = true
            }
        }
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
}

struct WhatIfSimulationView: View {
    let originalLoanAmount: Double
    let originalEMI: Double
    let originalInterestRate: Double
    let originalTenure: Int
    
    @State private var selectedScenario = SimulationScenario.increaseEMI
    @State private var emiIncrease = "2000"
    @State private var oneTimePayment = "10000"
    @State private var paymentFrequency = PaymentFrequency.quarterly
    @State private var prepaymentAmount = "50000"
    @State private var prepaymentMonth = 12
    @State private var animateContent = false
    @Environment(\.colorScheme) var colorScheme
    @FocusState private var isInputActive: Bool
    
    enum SimulationScenario: String, CaseIterable {
        case increaseEMI = "Increase EMI"
        case oneTimePayments = "Regular Extra Payments"
        case prepayment = "One-time Prepayment"
    }
    
    enum PaymentFrequency: String, CaseIterable {
        case monthly = "Monthly"
        case quarterly = "Quarterly"
        case halfYearly = "Half-Yearly"
        case yearly = "Yearly"
        
        var months: Int {
            switch self {
            case .monthly: return 1
            case .quarterly: return 3
            case .halfYearly: return 6
            case .yearly: return 12
            }
        }
    }
    
    var body: some View {
        VStack(spacing: 24) {
            // Animated Header
            headerSection
            
            // Animated Scenario Picker
            scenarioPicker
            
            // Animated Scenario Inputs
            scenarioInputs
            
            // Animated Results
            resultsSection
        }
        .padding(24)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.purple.opacity(0.3),
                                    Color.pink.opacity(0.3),
                                    Color.clear
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .shadow(
            color: Color.purple.opacity(0.1),
            radius: 20,
            x: 0,
            y: 10
        )
        .scaleEffect(animateContent ? 1.0 : 0.9)
        .opacity(animateContent ? 1.0 : 0.0)
        .animation(.spring(response: 0.8, dampingFraction: 0.8), value: animateContent)
        .onTapGesture {
            isInputActive = false
        }
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.1)) {
                animateContent = true
            }
        }
    }
    
    private var headerSection: some View {
        HStack {
            Image(systemName: "wand.and.stars")
                .font(.title2)
                .foregroundStyle(
                    LinearGradient(
                        gradient: Gradient(colors: [Color.purple, Color.pink]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            
            Text("What If Scenarios")
                .font(.headline)
                .fontWeight(.semibold)
            
            Spacer()
        }
    }
    
    private var scenarioPicker: some View {
        Picker("Scenario", selection: $selectedScenario) {
            ForEach(SimulationScenario.allCases, id: \.self) { scenario in
                Text(scenario.rawValue).tag(scenario)
            }
        }
        .pickerStyle(SegmentedPickerStyle())
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(Color(UIColor.tertiarySystemGroupedBackground))
        )
    }
    
    private var scenarioInputs: some View {
        Group {
            switch selectedScenario {
            case .increaseEMI:
                EMIIncreaseScenario(emiIncrease: $emiIncrease, isInputActive: _isInputActive)
            case .oneTimePayments:
                ExtraPaymentsScenario(
                    oneTimePayment: $oneTimePayment,
                    paymentFrequency: $paymentFrequency,
                    isInputActive: _isInputActive
                )
            case .prepayment:
                PrepaymentScenario(
                    prepaymentAmount: $prepaymentAmount,
                    prepaymentMonth: $prepaymentMonth,
                    isInputActive: _isInputActive
                )
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(UIColor.tertiarySystemGroupedBackground))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.purple.opacity(0.2),
                                    Color.pink.opacity(0.2)
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .transition(.asymmetric(
            insertion: .scale.combined(with: .opacity),
            removal: .scale.combined(with: .opacity)
        ))
        .animation(.spring(response: 0.5, dampingFraction: 0.8), value: selectedScenario)
    }
    
    private var resultsSection: some View {
        SimulationResultsView(
            originalData: getOriginalData(),
            simulatedData: getSimulatedData()
        )
    }
    
    private func getOriginalData() -> LoanScenarioData {
        let monthlyRate = originalInterestRate / (12 * 100)
        let totalPayment = originalEMI * Double(originalTenure)
        let totalInterest = totalPayment - originalLoanAmount
        
        return LoanScenarioData(
            emi: originalEMI,
            tenure: originalTenure,
            totalInterest: totalInterest,
            totalPayment: totalPayment
        )
    }
    
    private func getSimulatedData() -> LoanScenarioData {
        switch selectedScenario {
        case .increaseEMI:
            return calculateIncreasedEMIScenario()
        case .oneTimePayments:
            return calculateExtraPaymentsScenario()
        case .prepayment:
            return calculatePrepaymentScenario()
        }
    }
    
    private func calculateIncreasedEMIScenario() -> LoanScenarioData {
        let increase = Double(emiIncrease) ?? 0
        let newEMI = originalEMI + increase
        let monthlyRate = originalInterestRate / (12 * 100)
        
        var remainingBalance = originalLoanAmount
        var months = 0
        var totalPayment = 0.0
        
        while remainingBalance > 0.01 && months < 600 {
            let interestPayment = remainingBalance * monthlyRate
            let principalPayment = min(newEMI - interestPayment, remainingBalance)
            
            remainingBalance -= principalPayment
            totalPayment += (interestPayment + principalPayment)
            months += 1
        }
        
        return LoanScenarioData(
            emi: newEMI,
            tenure: months,
            totalInterest: totalPayment - originalLoanAmount,
            totalPayment: totalPayment
        )
    }
    
    private func calculateExtraPaymentsScenario() -> LoanScenarioData {
        let extraPayment = Double(oneTimePayment) ?? 0
        let monthlyRate = originalInterestRate / (12 * 100)
        let frequencyMonths = paymentFrequency.months
        
        var remainingBalance = originalLoanAmount
        var months = 0
        var totalPayment = 0.0
        
        while remainingBalance > 0.01 && months < 600 {
            let interestPayment = remainingBalance * monthlyRate
            let principalPayment = min(originalEMI - interestPayment, remainingBalance)
            
            var monthlyTotal = originalEMI
            
            if months % frequencyMonths == 0 && months > 0 {
                let extraPrincipal = min(extraPayment, remainingBalance - principalPayment)
                monthlyTotal += extraPrincipal
                remainingBalance -= (principalPayment + extraPrincipal)
            } else {
                remainingBalance -= principalPayment
            }
            
            totalPayment += monthlyTotal
            months += 1
        }
        
        return LoanScenarioData(
            emi: originalEMI,
            tenure: months,
            totalInterest: totalPayment - originalLoanAmount,
            totalPayment: totalPayment
        )
    }
    
    private func calculatePrepaymentScenario() -> LoanScenarioData {
        let prepayment = Double(prepaymentAmount) ?? 0
        let monthlyRate = originalInterestRate / (12 * 100)
        
        var remainingBalance = originalLoanAmount
        var months = 0
        var totalPayment = 0.0
        
        while remainingBalance > 0.01 && months < 600 {
            let interestPayment = remainingBalance * monthlyRate
            let principalPayment = min(originalEMI - interestPayment, remainingBalance)
            
            remainingBalance -= principalPayment
            totalPayment += originalEMI
            months += 1
            
            if months == prepaymentMonth {
                let actualPrepayment = min(prepayment, remainingBalance)
                remainingBalance -= actualPrepayment
                totalPayment += actualPrepayment
            }
        }
        
        return LoanScenarioData(
            emi: originalEMI,
            tenure: months,
            totalInterest: totalPayment - originalLoanAmount,
            totalPayment: totalPayment
        )
    }
}

struct LoanScenarioData {
    let emi: Double
    let tenure: Int
    let totalInterest: Double
    let totalPayment: Double
}

struct EMIIncreaseScenario: View {
    @Binding var emiIncrease: String
    @FocusState var isInputActive: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Increase Monthly EMI")
                .font(.subheadline)
                .fontWeight(.semibold)
            
            HStack {
                Text("Additional Amount:")
                    .font(.body)
                
                Spacer()
                
                HStack {
                    Text("$")
                        .foregroundColor(.secondary)
                        .fontWeight(.medium)
                    
                    TextField("2000", text: $emiIncrease)
                        .keyboardType(.numberPad)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .frame(width: 100)
                        .focused($isInputActive)
                        .submitLabel(.done)
                        .onSubmit {
                            isInputActive = false
                        }
                }
            }
            
            Text("See how increasing your EMI reduces loan tenure and saves interest")
                .font(.caption)
                .foregroundColor(.secondary)
                .padding(.top, 4)
        }
    }
}

struct ExtraPaymentsScenario: View {
    @Binding var oneTimePayment: String
    @Binding var paymentFrequency: WhatIfSimulationView.PaymentFrequency
    @FocusState var isInputActive: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Regular Extra Payments")
                .font(.subheadline)
                .fontWeight(.semibold)
            
            HStack {
                Text("Extra Amount:")
                    .font(.body)
                
                Spacer()
                
                HStack {
                    Text("$")
                        .foregroundColor(.secondary)
                        .fontWeight(.medium)
                    
                    TextField("10000", text: $oneTimePayment)
                        .keyboardType(.numberPad)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .frame(width: 100)
                        .focused($isInputActive)
                        .submitLabel(.done)
                        .onSubmit {
                            isInputActive = false
                        }
                }
            }
            
            VStack(alignment: .leading, spacing: 12) {
                Text("Payment Frequency:")
                    .font(.body)
                
                Picker("Frequency", selection: $paymentFrequency) {
                    ForEach(WhatIfSimulationView.PaymentFrequency.allCases, id: \.self) { frequency in
                        Text(frequency.rawValue).tag(frequency)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
            
            Text("Make regular extra payments to reduce your loan faster")
                .font(.caption)
                .foregroundColor(.secondary)
                .padding(.top, 4)
        }
    }
}

struct PrepaymentScenario: View {
    @Binding var prepaymentAmount: String
    @Binding var prepaymentMonth: Int
    @FocusState var isInputActive: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("One-time Prepayment")
                .font(.subheadline)
                .fontWeight(.semibold)
            
            HStack {
                Text("Prepayment Amount:")
                    .font(.body)
                
                Spacer()
                
                HStack {
                    Text("$")
                        .foregroundColor(.secondary)
                        .fontWeight(.medium)
                    
                    TextField("50000", text: $prepaymentAmount)
                        .keyboardType(.numberPad)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .frame(width: 100)
                        .focused($isInputActive)
                        .submitLabel(.done)
                        .onSubmit {
                            isInputActive = false
                        }
                }
            }
            
            VStack(alignment: .leading, spacing: 12) {
                Text("After Month:")
                    .font(.body)
                
                Picker("Month", selection: $prepaymentMonth) {
                    ForEach(1...60, id: \.self) { month in
                        Text("\(month)").tag(month)
                    }
                }
                .pickerStyle(WheelPickerStyle())
                .frame(height: 80)
            }
            
            Text("Make a lump sum payment to significantly reduce interest")
                .font(.caption)
                .foregroundColor(.secondary)
                .padding(.top, 4)
        }
    }
}

struct SimulationResultsView: View {
    let originalData: LoanScenarioData
    let simulatedData: LoanScenarioData
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var animateComparison = false
    @State private var animateSavings = false
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Comparison Results")
                .font(.headline)
                .fontWeight(.semibold)
            
            // Comparison Cards
            comparisonSection
            
            // Savings Summary
            if simulatedData.totalInterest < originalData.totalInterest {
                savingsSection
            }
        }
        .onAppear {
            startComparisonAnimations()
        }
    }
    
    private var comparisonSection: some View {
        HStack(spacing: 16) {
            // Original Scenario
            comparisonCard(
                title: "Current Plan",
                data: originalData,
                colors: [Color.gray.opacity(0.3), Color.gray.opacity(0.1)],
                textColor: .secondary
            )
            .scaleEffect(animateComparison ? 1.0 : 0.8)
            .opacity(animateComparison ? 1.0 : 0.0)
            .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.1), value: animateComparison)
            
            // Simulated Scenario
            comparisonCard(
                title: "With Changes",
                data: simulatedData,
                colors: [Color.blue.opacity(0.2), Color.green.opacity(0.1)],
                textColor: .blue
            )
            .scaleEffect(animateComparison ? 1.0 : 0.8)
            .opacity(animateComparison ? 1.0 : 0.0)
            .animation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.2), value: animateComparison)
        }
    }
    
    private func comparisonCard(title: String, data: LoanScenarioData, colors: [Color], textColor: Color) -> some View {
        VStack(spacing: 12) {
            Text(title)
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(textColor)
            
            VStack(spacing: 8) {
                ComparisonRow(
                    title: "Tenure",
                    value: "\(data.tenure) months"
                )
                
                ComparisonRow(
                    title: "Total Interest",
                    value: formatCurrency(data.totalInterest)
                )
                
                ComparisonRow(
                    title: "Total Payment",
                    value: formatCurrency(data.totalPayment)
                )
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(
                    LinearGradient(
                        gradient: Gradient(colors: colors),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [textColor.opacity(0.3)]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
    }
    
    private var savingsSection: some View {
        VStack(spacing: 12) {
            HStack {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundColor(.green)
                    .font(.title2)
                
                Text("You could save:")
                    .font(.headline)
                    .fontWeight(.semibold)
            }
            
            VStack(spacing: 8) {
                Text(formatCurrency(originalData.totalInterest - simulatedData.totalInterest))
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.green, Color.mint]),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                
                Text("in interest payments")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                if originalData.tenure > simulatedData.tenure {
                    Text("and finish \(originalData.tenure - simulatedData.tenure) months earlier")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(
                    LinearGradient(
                        gradient: Gradient(colors: [
                            Color.green.opacity(0.1),
                            Color.mint.opacity(0.05)
                        ]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.green.opacity(0.3),
                                    Color.mint.opacity(0.3)
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .scaleEffect(animateSavings ? 1.0 : 0.8)
        .opacity(animateSavings ? 1.0 : 0.0)
        .animation(.spring(response: 0.8, dampingFraction: 0.8).delay(0.4), value: animateSavings)
    }
    
    private func startComparisonAnimations() {
        withAnimation {
            animateComparison = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            withAnimation {
                animateSavings = true
            }
        }
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
}

struct ComparisonRow: View {
    let title: String
    let value: String
    var change: Int = 0
    var isMonths: Bool = false
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        HStack {
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
            
            Spacer()
            
            VStack(alignment: .trailing, spacing: 2) {
                Text(value)
                    .font(.caption)
                    .fontWeight(.medium)
                
                if change != 0 {
                    HStack(spacing: 2) {
                        Image(systemName: change > 0 ? "arrow.down" : "arrow.up")
                            .font(.caption2)
                            .foregroundColor(change > 0 ? .green : .red)
                        
                        Text(isMonths ? "\(abs(change))" : formatCurrency(Double(abs(change))))
                            .font(.caption2)
                            .foregroundColor(change > 0 ? .green : .red)
                    }
                }
            }
        }
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
}

struct EMIResultCard: View {
    let title: String
    let value: String
    let color: Color
    let icon: String
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(
                    LinearGradient(
                        gradient: Gradient(colors: [color, color.opacity(0.7)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .fontWeight(.medium)
            
            Text(value)
                .font(.headline)
                .fontWeight(.bold)
                .foregroundStyle(
                    LinearGradient(
                        gradient: Gradient(colors: [color, color.opacity(0.8)]),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(UIColor.tertiarySystemGroupedBackground))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [color.opacity(0.3)]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
    }
}

struct EMIPieChart: View {
    let principal: Double
    let interest: Double
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var animateChart = false
    
    private struct ChartDataPoint {
        let category: String
        let amount: Double
        let color: Color
    }
    
    var body: some View {
        VStack(spacing: 16) {
            Text("Payment Breakdown")
                .font(.subheadline)
                .fontWeight(.semibold)
            
            Chart(chartData, id: \.category) { item in
                SectorMark(
                    angle: .value("Amount", item.amount),
                    innerRadius: .ratio(0.4),
                    angularInset: 2
                )
                .foregroundStyle(
                    LinearGradient(
                        gradient: Gradient(colors: [item.color, item.color.opacity(0.7)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .opacity(animateChart ? 0.8 : 0.0)
            }
            .frame(height: 150)
            .animation(.easeInOut(duration: 1.0).delay(0.2), value: animateChart)
            
            // Legend
            HStack(spacing: 24) {
                ForEach(chartData, id: \.category) { item in
                    HStack(spacing: 8) {
                        Circle()
                            .fill(
                                LinearGradient(
                                    gradient: Gradient(colors: [item.color, item.color.opacity(0.7)]),
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 12, height: 12)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text(item.category)
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .fontWeight(.medium)
                            
                            Text(formatCurrency(item.amount))
                                .font(.caption)
                                .fontWeight(.semibold)
                        }
                    }
                }
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(UIColor.tertiarySystemGroupedBackground))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.blue.opacity(0.2),
                                    Color.orange.opacity(0.2)
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .onAppear {
            withAnimation(.easeInOut(duration: 0.8).delay(0.1)) {
                animateChart = true
            }
        }
    }
    
    private var chartData: [ChartDataPoint] {
        [
            ChartDataPoint(category: "Principal", amount: principal, color: .blue),
            ChartDataPoint(category: "Interest", amount: interest, color: .orange)
        ]
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
}

struct EMIBreakdownView: View {
    let loanAmount: Double
    let emi: Double
    let interestRate: Double
    let tenure: Int
    @Environment(\.colorScheme) var colorScheme
    @State private var animateContent = false
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Payment Schedule")
                .font(.headline)
                .fontWeight(.semibold)
            
            // Amortization Chart
            AmortizationChart(
                loanAmount: loanAmount,
                emi: emi,
                interestRate: interestRate,
                tenure: tenure
            )
            .scaleEffect(animateContent ? 1.0 : 0.9)
            .opacity(animateContent ? 1.0 : 0.0)
            .animation(.spring(response: 0.8, dampingFraction: 0.8).delay(0.1), value: animateContent)
            
            // Payment Schedule Table
            PaymentScheduleTable(
                loanAmount: loanAmount,
                emi: emi,
                interestRate: interestRate,
                tenure: tenure
            )
            .scaleEffect(animateContent ? 1.0 : 0.9)
            .opacity(animateContent ? 1.0 : 0.0)
            .animation(.spring(response: 0.8, dampingFraction: 0.8).delay(0.3), value: animateContent)
        }
        .padding(24)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.blue.opacity(0.3),
                                    Color.cyan.opacity(0.3),
                                    Color.clear
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .shadow(
            color: Color.blue.opacity(0.1),
            radius: 20,
            x: 0,
            y: 10
        )
        .onAppear {
            withAnimation {
                animateContent = true
            }
        }
    }
}

struct AmortizationChart: View {
    let loanAmount: Double
    let emi: Double
    let interestRate: Double
    let tenure: Int
    @Environment(\.colorScheme) var colorScheme
    @State private var animateChart = false
    
    var body: some View {
        VStack(spacing: 12) {
            Text("Principal vs Interest Over Time")
                .font(.subheadline)
                .fontWeight(.semibold)
            
            Chart {
                ForEach(Array(amortizationData.enumerated()), id: \.offset) { index, data in
                    AreaMark(
                        x: .value("Month", index + 1),
                        y: .value("Principal", data.principalPayment)
                    )
                    .foregroundStyle(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.blue.opacity(0.3)]),
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .opacity(animateChart ? 1.0 : 0.0)
                    
                    AreaMark(
                        x: .value("Month", index + 1),
                        y: .value("Interest", data.interestPayment),
                        stacking: .standard
                    )
                    .foregroundStyle(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.orange.opacity(0.6), Color.orange.opacity(0.3)]),
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .opacity(animateChart ? 1.0 : 0.0)
                }
            }
            .frame(height: 200)
            .chartYAxis {
                AxisMarks(position: .leading)
            }
            .chartXAxis {
                AxisMarks(values: .automatic(desiredCount: 10)) { value in
                    AxisGridLine()
                    AxisTick()
                    AxisValueLabel {
                        if let month = value.as(Int.self) {
                            Text("\(month)")
                        }
                    }
                }
            }
            .animation(.easeInOut(duration: 1.5).delay(0.2), value: animateChart)
            
            // Legend
            HStack(spacing: 20) {
                HStack(spacing: 8) {
                    Rectangle()
                        .fill(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.blue.opacity(0.3)]),
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                        .frame(width: 12, height: 12)
                        .cornerRadius(2)
                    Text("Principal")
                        .font(.caption)
                        .fontWeight(.medium)
                }
                
                HStack(spacing: 8) {
                    Rectangle()
                        .fill(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.orange.opacity(0.6), Color.orange.opacity(0.3)]),
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                        .frame(width: 12, height: 12)
                        .cornerRadius(2)
                    Text("Interest")
                        .font(.caption)
                        .fontWeight(.medium)
                }
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(UIColor.tertiarySystemGroupedBackground))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.blue.opacity(0.2),
                                    Color.orange.opacity(0.2)
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .onAppear {
            withAnimation(.easeInOut(duration: 0.8).delay(0.1)) {
                animateChart = true
            }
        }
    }
    
    private var amortizationData: [AmortizationData] {
        var data: [AmortizationData] = []
        var remainingBalance = loanAmount
        let monthlyRate = interestRate / (12 * 100)
        
        for _ in 1...min(tenure, 60) {
            let interestPayment = remainingBalance * monthlyRate
            let principalPayment = emi - interestPayment
            
            data.append(AmortizationData(
                principalPayment: principalPayment,
                interestPayment: interestPayment,
                remainingBalance: remainingBalance - principalPayment
            ))
            
            remainingBalance -= principalPayment
            
            if remainingBalance <= 0 { break }
        }
        
        return data
    }
}

struct AmortizationData {
    let principalPayment: Double
    let interestPayment: Double
    let remainingBalance: Double
}

struct PaymentScheduleTable: View {
    let loanAmount: Double
    let emi: Double
    let interestRate: Double
    let tenure: Int
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var animateRows = false
    
    var body: some View {
        VStack(spacing: 16) {
            Text("First 12 Months Schedule")
                .font(.subheadline)
                .fontWeight(.semibold)
            
            ScrollView {
                LazyVStack(spacing: 8) {
                    // Header
                    headerRow
                    
                    ForEach(Array(scheduleData.prefix(12).enumerated()), id: \.offset) { index, payment in
                        paymentRow(index: index, payment: payment)
                            .scaleEffect(animateRows ? 1.0 : 0.9)
                            .opacity(animateRows ? 1.0 : 0.0)
                            .animation(.spring(response: 0.5, dampingFraction: 0.8).delay(Double(index) * 0.05), value: animateRows)
                    }
                }
            }
            .frame(maxHeight: 300)
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(UIColor.tertiarySystemGroupedBackground))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color.green.opacity(0.2),
                                    Color.blue.opacity(0.2)
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1
                        )
                )
        )
        .onAppear {
            withAnimation {
                animateRows = true
            }
        }
    }
    
    private var headerRow: some View {
        HStack {
            Text("Month")
                .font(.caption)
                .fontWeight(.bold)
                .frame(width: 50, alignment: .leading)
            
            Text("EMI")
                .font(.caption)
                .fontWeight(.bold)
                .frame(maxWidth: .infinity, alignment: .trailing)
            
            Text("Principal")
                .font(.caption)
                .fontWeight(.bold)
                .frame(maxWidth: .infinity, alignment: .trailing)
            
            Text("Interest")
                .font(.caption)
                .fontWeight(.bold)
                .frame(maxWidth: .infinity, alignment: .trailing)
            
            Text("Balance")
                .font(.caption)
                .fontWeight(.bold)
                .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(Color(UIColor.quaternarySystemFill))
        )
    }
    
    private func paymentRow(index: Int, payment: PaymentData) -> some View {
        VStack {
            HStack {
                Text("\(index + 1)")
                    .font(.caption)
                    .fontWeight(.medium)
                    .frame(width: 50, alignment: .leading)
                
                Text(formatCurrency(payment.emi))
                    .font(.caption)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                
                Text(formatCurrency(payment.principal))
                    .font(.caption)
                    .foregroundColor(.blue)
                    .fontWeight(.medium)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                
                Text(formatCurrency(payment.interest))
                    .font(.caption)
                    .foregroundColor(.orange)
                    .fontWeight(.medium)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                
                Text(formatCurrency(payment.balance))
                    .font(.caption)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            
            if index < 11 {
                Divider()
                    .opacity(0.5)
            }
        }
    }
    
    private var scheduleData: [PaymentData] {
        var data: [PaymentData] = []
        var remainingBalance = loanAmount
        let monthlyRate = interestRate / (12 * 100)
        
        for _ in 1...tenure {
            let interestPayment = remainingBalance * monthlyRate
            let principalPayment = emi - interestPayment
            remainingBalance -= principalPayment
            
            data.append(PaymentData(
                emi: emi,
                principal: principalPayment,
                interest: interestPayment,
                balance: max(0, remainingBalance)
            ))
            
            if remainingBalance <= 0 { break }
        }
        
        return data
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
}

struct PaymentData {
    let emi: Double
    let principal: Double
    let interest: Double
    let balance: Double
}

#Preview {
    EMICalculatorView()
        .environmentObject(UserDataManager())
}
