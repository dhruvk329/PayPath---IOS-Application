import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore

class AuthViewModel: ObservableObject {
    @Published var isAuthenticated = false
    @Published var isLoading = false
    @Published var errorMessage = ""
    @Published var emailError = ""
    @Published var passwordError = ""
    @Published var currentUser: FirebaseAuth.User?
    @Published var requiresBiometricAuth = false
    @Published var biometricAuthManager = BiometricAuthManager()
    
    // Add UserDataManager only (remove CurrencyManager)
    @Published var userDataManager = UserDataManager()

    private var authStateListener: AuthStateDidChangeListenerHandle?
    private let db = Firestore.firestore()

    init() {
        print("AuthViewModel initializing...")
        setupAuthStateListener()
        loadBiometricPreference()
    }

    deinit {
        if let listener = authStateListener {
            Auth.auth().removeStateDidChangeListener(listener)
        }
    }

    private func setupAuthStateListener() {
        print("Setting up auth state listener...")
        authStateListener = Auth.auth().addStateDidChangeListener { [weak self] _, user in
            DispatchQueue.main.async {
                print("Auth state changed. User: \(user?.email ?? "nil")")
                self?.isAuthenticated = user != nil
                self?.currentUser = user
                
                if let user = user {
                    // Load user-specific data and set Firebase user ID
                    self?.userDataManager.setFirebaseUserId(user.uid)
                    
                    // Get the full name from Firebase user profile or Firestore
                    self?.loadUserFullName(for: user) { fullName in
                        self?.userDataManager.loadUserData(
                            for: user.email ?? "",
                            fullName: fullName
                        )
                        
                        // Load loans from Firebase
                        self?.userDataManager.loadLoansFromFirebase()
                    }
                } else {
                    // Clear data when user signs out
                    self?.userDataManager.clearUserData()
                    self?.biometricAuthManager.isAuthenticated = false
                }
            }
        }
    }
    
    private func loadUserFullName(for user: FirebaseAuth.User, completion: @escaping (String) -> Void) {
        // First try to get from Firebase Auth display name
        if let displayName = user.displayName, !displayName.isEmpty {
            print("Using display name from Firebase Auth: \(displayName)")
            completion(displayName)
            return
        }
        
        // If not available, try to get from Firestore
        db.collection("users").document(user.uid).getDocument { document, error in
            DispatchQueue.main.async {
                if let document = document, document.exists,
                   let data = document.data(),
                   let fullName = data["fullName"] as? String, !fullName.isEmpty {
                    print("Using full name from Firestore: \(fullName)")
                    completion(fullName)
                } else {
                    print("No full name found, using email prefix")
                    // Fallback to email prefix
                    let emailPrefix = user.email?.components(separatedBy: "@").first ?? "User"
                    completion(emailPrefix.capitalized)
                }
            }
        }
    }

    func checkAuthenticationState() {
        print("Checking authentication state...")
        let currentUser = Auth.auth().currentUser
        print("Current user: \(currentUser?.email ?? "nil")")
        isAuthenticated = currentUser != nil
        self.currentUser = currentUser
        
        if let user = currentUser {
            userDataManager.setFirebaseUserId(user.uid)
            loadUserFullName(for: user) { fullName in
                self.userDataManager.loadUserData(
                    for: user.email ?? "",
                    fullName: fullName
                )
                self.userDataManager.loadLoansFromFirebase()
            }
        }
    }

    func signIn(email: String, password: String) {
        print("Attempting to sign in with email: \(email)")
        clearErrors()
        
        guard validateSignInInput(email: email, password: password) else {
            print("Sign in validation failed")
            return
        }
        
        isLoading = true
        
        Auth.auth().signIn(withEmail: email, password: password) { [weak self] result, error in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                if let error = error {
                    print("Sign in error: \(error.localizedDescription)")
                    self?.handleAuthError(error)
                } else if let user = result?.user {
                    print("Sign in successful")
                    self?.errorMessage = ""
                    // Data will be loaded automatically by auth state listener
                }
            }
        }
    }

    func signUp(fullName: String, email: String, password: String, confirmPassword: String) {
        print("Attempting to sign up with email: \(email) and name: \(fullName)")
        clearErrors()
        
        guard validateSignUpInput(fullName: fullName, email: email, password: password, confirmPassword: confirmPassword) else {
            print("Sign up validation failed")
            return
        }
        
        isLoading = true
        
        Auth.auth().createUser(withEmail: email, password: password) { [weak self] result, error in
            if let error = error {
                DispatchQueue.main.async {
                    print("Sign up error: \(error.localizedDescription)")
                    self?.isLoading = false
                    self?.handleAuthError(error)
                }
            } else if let user = result?.user {
                print("Sign up successful for user: \(user.email ?? "")")
                
                // Update Firebase Auth profile with display name
                let changeRequest = user.createProfileChangeRequest()
                changeRequest.displayName = fullName
                changeRequest.commitChanges { [weak self] profileError in
                    if let profileError = profileError {
                        print("Error updating Firebase Auth profile: \(profileError.localizedDescription)")
                    } else {
                        print("Successfully updated Firebase Auth display name to: \(fullName)")
                    }
                    
                    // Save additional user data to Firestore
                    self?.saveUserToFirestore(user: user, fullName: fullName)
                }
            }
        }
    }

    private func saveUserToFirestore(user: FirebaseAuth.User, fullName: String) {
        print("Saving user to Firestore with name: \(fullName)")
        let userData: [String: Any] = [
            "uid": user.uid,
            "email": user.email ?? "",
            "fullName": fullName,
            "createdAt": Timestamp(),
            "lastLoginAt": Timestamp()
        ]
        
        db.collection("users").document(user.uid).setData(userData) { [weak self] error in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                if let error = error {
                    print("Firestore save error: \(error.localizedDescription)")
                    self?.errorMessage = "Account created but failed to save profile: \(error.localizedDescription)"
                } else {
                    print("User saved to Firestore successfully with name: \(fullName)")
                    self?.errorMessage = ""
                    
                    // Refresh the current user to get updated display name
                    user.reload { _ in
                        DispatchQueue.main.async {
                            self?.currentUser = Auth.auth().currentUser
                        }
                    }
                }
            }
        }
    }

    private func loadBiometricPreference() {
        requiresBiometricAuth = UserDefaults.standard.bool(forKey: "biometricAuthEnabled")
    }

    func setBiometricAuth(enabled: Bool) {
        requiresBiometricAuth = enabled
        UserDefaults.standard.set(enabled, forKey: "biometricAuthEnabled")
        
        if !enabled {
            biometricAuthManager.isAuthenticated = true
        }
    }
    
    func enableBiometricAuth() {
        setBiometricAuth(enabled: true)
    }
    
    func disableBiometricAuth() {
        setBiometricAuth(enabled: false)
    }

    func resetPassword(email: String) {
        guard !email.isEmpty else {
            emailError = "Please enter your email address"
            return
        }
        
        guard isValidEmail(email) else {
            emailError = "Please enter a valid email address"
            return
        }
        
        Auth.auth().sendPasswordReset(withEmail: email) { [weak self] error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.handleAuthError(error)
                } else {
                    self?.errorMessage = "Password reset email sent. Please check your inbox."
                }
            }
        }
    }

    func signOut() {
        do {
            try Auth.auth().signOut()
            errorMessage = ""
            userDataManager.clearUserData()
            biometricAuthManager.isAuthenticated = false
            print("User signed out successfully")
        } catch {
            errorMessage = "Failed to sign out: \(error.localizedDescription)"
            print("Sign out error: \(error.localizedDescription)")
        }
    }

    private func validateSignInInput(email: String, password: String) -> Bool {
        var isValid = true
        
        if email.isEmpty {
            emailError = "Email is required"
            isValid = false
        } else if !isValidEmail(email) {
            emailError = "Please enter a valid email address"
            isValid = false
        }
        
        if password.isEmpty {
            passwordError = "Password is required"
            isValid = false
        }
        
        return isValid
    }

    private func validateSignUpInput(fullName: String, email: String, password: String, confirmPassword: String) -> Bool {
        var isValid = true
        
        if fullName.isEmpty {
            errorMessage = "Full name is required"
            isValid = false
        }
        
        if email.isEmpty {
            emailError = "Email is required"
            isValid = false
        } else if !isValidEmail(email) {
            emailError = "Please enter a valid email address"
            isValid = false
        }
        
        if password.isEmpty {
            passwordError = "Password is required"
            isValid = false
        } else if password.count < 6 {
            passwordError = "Password must be at least 6 characters"
            isValid = false
        }
        
        if password != confirmPassword {
            errorMessage = "Passwords do not match"
            isValid = false
        }
        
        return isValid
    }

    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }

    private func handleAuthError(_ error: Error) {
        let authError = error as NSError
        
        switch authError.code {
        case AuthErrorCode.emailAlreadyInUse.rawValue:
            errorMessage = "This email address is already registered"
        case AuthErrorCode.invalidEmail.rawValue:
            emailError = "Please enter a valid email address"
        case AuthErrorCode.weakPassword.rawValue:
            passwordError = "Password is too weak. Please choose a stronger password"
        case AuthErrorCode.userNotFound.rawValue:
            errorMessage = "No account found with this email address"
        case AuthErrorCode.wrongPassword.rawValue:
            passwordError = "Incorrect password"
        case AuthErrorCode.userDisabled.rawValue:
            errorMessage = "This account has been disabled"
        case AuthErrorCode.tooManyRequests.rawValue:
            errorMessage = "Too many failed attempts. Please try again later"
        case AuthErrorCode.networkError.rawValue:
            errorMessage = "Network error. Please check your connection"
        default:
            errorMessage = error.localizedDescription
        }
    }

    private func clearErrors() {
        errorMessage = ""
        emailError = ""
        passwordError = ""
    }
}
