import SwiftUI

struct LoansListView: View {
    @EnvironmentObject var userDataManager: UserDataManager
    @Environment(\.colorScheme) var colorScheme
    @State private var isGeneratingReport = false
    @State private var showingReportAlert = false
    @State private var reportMessage = ""
    @State private var animateElements = false
    
    private var backgroundGradient: LinearGradient {
        if colorScheme == .dark {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.black,
                    Color(red: 0.05, green: 0.05, blue: 0.1),
                    Color(red: 0.1, green: 0.1, blue: 0.15)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.98, green: 0.99, blue: 1.0),
                    Color(red: 0.95, green: 0.97, blue: 0.99),
                    Color(red: 0.92, green: 0.95, blue: 0.98)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundGradient
                    .ignoresSafeArea()
                
                VStack {
                    if userDataManager.loans.isEmpty {
                        emptyStateView
                            .opacity(animateElements ? 1.0 : 0.0)
                            .scaleEffect(animateElements ? 1.0 : 0.9)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.2), value: animateElements)
                    } else {
                        ScrollView {
                            VStack(spacing: 20) {
                                // Progress Line Chart
                                DebtProgressChartView()
                                    .environmentObject(userDataManager)
                                    .opacity(animateElements ? 1.0 : 0.0)
                                    .offset(y: animateElements ? 0 : -30)
                                    .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.1), value: animateElements)
                                
                                // Loans List
                                loansListSection
                                    .opacity(animateElements ? 1.0 : 0.0)
                                    .offset(y: animateElements ? 0 : 30)
                                    .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.3), value: animateElements)
                            }
                            .padding(.vertical)
                        }
                    }
                }
            }
            .navigationTitle("Your Loans")
            .toolbar {
                if !userDataManager.loans.isEmpty {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("Generate Report") {
                            generateLoanReport()
                        }
                        .foregroundColor(.blue)
                        .disabled(isGeneratingReport)
                    }
                }
            }
            .overlay {
                if isGeneratingReport {
                    reportGeneratingOverlay
                }
            }
            .alert("Report Generation", isPresented: $showingReportAlert) {
                Button("OK") { }
            } message: {
                Text(reportMessage)
            }
            .onAppear {
                withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                    animateElements = true
                }
            }
        }
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 25) {
            ZStack {
                Circle()
                    .fill(Color.gray.opacity(0.1))
                    .frame(width: 100, height: 100)
                
                Image(systemName: "list.bullet.rectangle")
                    .font(.system(size: 50))
                    .foregroundColor(.gray)
            }
            
            VStack(spacing: 12) {
                Text("No Loans Added Yet")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text("Add your first loan to get started")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }
        .padding(40)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                )
                .shadow(color: colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1), radius: 15, x: 0, y: 8)
        )
        .padding()
    }
    
    private var loansListSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("All Loans")
                    .font(.headline)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Text("\(userDataManager.loans.count) loan\(userDataManager.loans.count == 1 ? "" : "s")")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(6)
            }
            .padding(.horizontal)
            
            LazyVStack(spacing: 12) {
                ForEach(Array(userDataManager.loans.enumerated()), id: \.element.id) { index, loan in
                    LoanRowView(loan: loan)
                        .padding(.horizontal)
                        .opacity(animateElements ? 1.0 : 0.0)
                        .offset(x: animateElements ? 0 : (index % 2 == 0 ? -50 : 50))
                        .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(Double(index) * 0.1 + 0.4), value: animateElements)
                }
            }
        }
    }
    
    private var reportGeneratingOverlay: some View {
        ZStack {
            Color.black.opacity(0.3)
                .ignoresSafeArea()
            
            VStack(spacing: 16) {
                ProgressView()
                    .scaleEffect(1.5)
                    .progressViewStyle(CircularProgressViewStyle(tint: .blue))
                
                Text("Generating Report...")
                    .font(.headline)
                    .foregroundColor(.primary)
            }
            .padding(30)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(.ultraThinMaterial)
                    .shadow(radius: 20)
            )
        }
    }
    
    private func generateLoanReport() {
        guard !userDataManager.loans.isEmpty else {
            reportMessage = "No loans found to generate report"
            showingReportAlert = true
            return
        }
        
        isGeneratingReport = true
        
        // Generate PDF report
        let reportGenerator = LoanReportGenerator()
        reportGenerator.generateComprehensiveReport(loans: userDataManager.loans, userProfile: userDataManager.userProfile) { success, message in
            DispatchQueue.main.async {
                isGeneratingReport = false
                reportMessage = message
                showingReportAlert = true
            }
        }
    }
}

#Preview {
    LoansListView()
        .environmentObject(UserDataManager())
}
