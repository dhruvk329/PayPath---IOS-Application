import SwiftUI
import Charts

struct DebtProgressChartView: View {
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        VStack(spacing: 16) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Debt Payoff Progress")
                        .font(.headline)
                        .fontWeight(.semibold)
                    
                    Text("Track your journey to financial freedom")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 4) {
                    Text("\(Int(overallProgress))%")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.green)
                    
                    Text("Complete")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            // Line Chart
            Chart(chartData, id: \.month) { dataPoint in
                LineMark(
                    x: .value("Month", dataPoint.month),
                    y: .value("Remaining Debt", dataPoint.remainingDebt)
                )
                .foregroundStyle(.blue)
                .lineStyle(StrokeStyle(lineWidth: 3))
                
                AreaMark(
                    x: .value("Month", dataPoint.month),
                    y: .value("Remaining Debt", dataPoint.remainingDebt)
                )
                .foregroundStyle(
                    LinearGradient(
                        gradient: Gradient(colors: [.blue.opacity(0.3), .blue.opacity(0.1)]),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                
                // Current position marker
                if dataPoint.isCurrent {
                    PointMark(
                        x: .value("Month", dataPoint.month),
                        y: .value("Remaining Debt", dataPoint.remainingDebt)
                    )
                    .foregroundStyle(.green)
                    .symbolSize(100)
                }
                
                // Goal line (zero debt)
                RuleMark(y: .value("Goal", 0))
                    .foregroundStyle(.green)
                    .lineStyle(StrokeStyle(lineWidth: 2, dash: [5, 5]))
            }
            .frame(height: 200)
            .chartXAxis {
                AxisMarks(values: .stride(by: 6)) { value in
                    AxisGridLine()
                    AxisTick()
                    AxisValueLabel {
                        if let month = value.as(Int.self) {
                            Text(monthLabel(for: month))
                                .font(.caption)
                        }
                    }
                }
            }
            .chartYAxis {
                AxisMarks { value in
                    AxisGridLine()
                    AxisTick()
                    AxisValueLabel {
                        if let debt = value.as(Double.self) {
                            Text(formatCurrency(debt))
                                .font(.caption)
                        }
                    }
                }
            }
            
            // Progress Summary
            HStack(spacing: 20) {
                ProgressSummaryItem(
                    title: "Total Debt",
                    value: formatCurrency(totalOriginalDebt),
                    color: .red
                )
                
                ProgressSummaryItem(
                    title: "Paid Off",
                    value: formatCurrency(totalPaidAmount),
                    color: .green
                )
                
                ProgressSummaryItem(
                    title: "Remaining",
                    value: formatCurrency(totalRemainingDebt),
                    color: .orange
                )
                
                ProgressSummaryItem(
                    title: "Goal Date",
                    value: goalDateString,
                    color: .blue
                )
            }
            
            // Motivational Message
            VStack(spacing: 8) {
                if overallProgress >= 75 {
                    Text("🎉 You're almost there! Keep going!")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.green)
                } else if overallProgress >= 50 {
                    Text("💪 Great progress! You're halfway to freedom!")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.blue)
                } else if overallProgress >= 25 {
                    Text("🚀 You're building momentum! Stay consistent!")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.orange)
                } else {
                    Text("🌟 Every payment brings you closer to your goal!")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.purple)
                }
                
                Text("At this rate, you'll be debt-free by \(goalDateString)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding(.top, 8)
        }
        .padding()
        .background(
            LinearGradient(
                gradient: Gradient(colors: [Color.blue.opacity(0.05), Color.green.opacity(0.05)]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .cornerRadius(16)
        .padding(.horizontal)
    }
    
    // MARK: - Computed Properties
    
    private var totalOriginalDebt: Double {
        userDataManager.loans.reduce(0) { $0 + $1.totalAmount }
    }
    
    private var totalRemainingDebt: Double {
        userDataManager.loans.reduce(0) { $0 + $1.remainingAmount }
    }
    
    private var totalPaidAmount: Double {
        totalOriginalDebt - totalRemainingDebt
    }
    
    private var totalMonthlyPayment: Double {
        userDataManager.loans.reduce(0) { $0 + $1.monthlyPayment }
    }
    
    private var overallProgress: Double {
        guard totalOriginalDebt > 0 else { return 0 }
        return (totalPaidAmount / totalOriginalDebt) * 100
    }
    
    private var monthsToPayoff: Int {
        guard totalMonthlyPayment > 0 else { return 0 }
        return Int(ceil(totalRemainingDebt / totalMonthlyPayment))
    }
    
    private var goalDateString: String {
        var dateComponents = DateComponents()
        dateComponents.month = monthsToPayoff
        let goalDate = Calendar.current.date(byAdding: dateComponents, to: Date()) ?? Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM yyyy"
        return formatter.string(from: goalDate)
    }
    
    private var chartData: [DebtProgressPoint] {
        var data: [DebtProgressPoint] = []
        let currentDate = Date()
        let calendar = Calendar.current
        
        // Calculate months since oldest loan start date
        let oldestStartDate = userDataManager.loans.map { $0.startDate }.min() ?? currentDate
        let monthsSinceStart = calendar.dateComponents([.month], from: oldestStartDate, to: currentDate).month ?? 0
        
        // Generate historical data points (simulated based on current progress)
        let totalMonths = monthsToPayoff + monthsSinceStart
        
        for month in 0...totalMonths {
            let remainingDebt: Double
            let isCurrent = month == monthsSinceStart
            
            if month <= monthsSinceStart {
                // Historical/current data
                let progressRatio = Double(month) / Double(monthsSinceStart + 1)
                remainingDebt = totalOriginalDebt - (totalPaidAmount * progressRatio)
            } else {
                // Future projection
                let futureMonths = month - monthsSinceStart
                let projectedPayment = totalMonthlyPayment * Double(futureMonths)
                remainingDebt = max(0, totalRemainingDebt - projectedPayment)
            }
            
            data.append(DebtProgressPoint(
                month: month,
                remainingDebt: max(0, remainingDebt),
                isCurrent: isCurrent
            ))
        }
        
        return data
    }
    
    // MARK: - Helper Methods
    
    private func monthLabel(for month: Int) -> String {
        let currentDate = Date()
        let calendar = Calendar.current
        let oldestStartDate = userDataManager.loans.map { $0.startDate }.min() ?? currentDate
        
        var dateComponents = DateComponents()
        dateComponents.month = month
        
        if let targetDate = calendar.date(byAdding: dateComponents, to: oldestStartDate) {
            let formatter = DateFormatter()
            formatter.dateFormat = "MMM"
            return formatter.string(from: targetDate)
        }
        return ""
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        formatter.maximumFractionDigits = 0
        return formatter.string(from: NSNumber(value: amount)) ?? "$0"
    }
}

struct DebtProgressPoint {
    let month: Int
    let remainingDebt: Double
    let isCurrent: Bool
}

struct ProgressSummaryItem: View {
    let title: String
    let value: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.subheadline)
                .fontWeight(.bold)
                .foregroundColor(color)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

#Preview {
    DebtProgressChartView()
        .environmentObject(UserDataManager())
}
