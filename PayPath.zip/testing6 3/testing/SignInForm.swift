import SwiftUI

struct SignInForm: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var email = ""
    @State private var password = ""
    @State private var showPassword = false
    @Environment(\.colorScheme) var colorScheme
    @FocusState private var isInputActive: Bool
    @State private var animateFields = false
    
    // Computed properties to break down complex expressions
    private var emailIconGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.blue.opacity(0.6)]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var passwordIconGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.purple.opacity(0.6)]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var fieldBackground: Color {
        colorScheme == .dark ?
        Color.white.opacity(0.08) :
        Color.gray.opacity(0.06)
    }
    
    private var buttonGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.blue,
                Color.blue.opacity(0.8),
                Color.purple.opacity(0.6)
            ]),
            startPoint: .leading,
            endPoint: .trailing
        )
    }
    
    var body: some View {
        VStack(spacing: 26) {
            headerSection
            emailField
            passwordField
            forgotPasswordButton
            signInButton
            errorMessage
        }
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Done") {
                    isInputActive = false
                }
                .foregroundColor(.blue)
                .fontWeight(.semibold)
            }
        }
        .onTapGesture {
            isInputActive = false
        }
        .onAppear {
            animateFields = true
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 10) {
            Text("Welcome Back")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(colorScheme == .dark ? .white : .primary)
                .scaleEffect(animateFields ? 1.0 : 0.9)
                .opacity(animateFields ? 1.0 : 0.0)
                .animation(.easeOut(duration: 0.6).delay(0.1), value: animateFields)
            
            Text("Sign in to your account")
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.7) : .secondary)
                .scaleEffect(animateFields ? 1.0 : 0.9)
                .opacity(animateFields ? 1.0 : 0.0)
                .animation(.easeOut(duration: 0.6).delay(0.2), value: animateFields)
        }
        .padding(.bottom, 12)
    }
    
    private var emailField: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Email Address")
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.9) : .primary)
            
            HStack(spacing: 14) {
                emailIcon
                emailTextField
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 16)
            .background(fieldBackground)
            .cornerRadius(16)
            .overlay(emailFieldBorder)
            .scaleEffect(isInputActive ? 1.02 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isInputActive)
            .scaleEffect(animateFields ? 1.0 : 0.9)
            .opacity(animateFields ? 1.0 : 0.0)
            .animation(.easeOut(duration: 0.6).delay(0.3), value: animateFields)
            
            if !authViewModel.emailError.isEmpty {
                emailErrorView
            }
        }
    }
    
    private var emailIcon: some View {
        ZStack {
            Circle()
                .fill(emailIconGradient)
                .frame(width: 36, height: 36)
            
            Image(systemName: "envelope.fill")
                .foregroundColor(.white)
                .font(.system(size: 16, weight: .medium))
        }
    }
    
    private var emailTextField: some View {
        TextField("Enter your email", text: $email)
            .textFieldStyle(PlainTextFieldStyle())
            .textContentType(.emailAddress)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .foregroundColor(colorScheme == .dark ? .white : .primary)
            .focused($isInputActive)
            .font(.system(size: 16, weight: .medium))
    }
    
    private var emailFieldBorder: some View {
        RoundedRectangle(cornerRadius: 16)
            .stroke(
                authViewModel.emailError.isEmpty ?
                (isInputActive ?
                 LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing) :
                 LinearGradient(gradient: Gradient(colors: [Color.gray.opacity(0.3)]), startPoint: .leading, endPoint: .trailing)) :
                LinearGradient(gradient: Gradient(colors: [Color.red]), startPoint: .leading, endPoint: .trailing),
                lineWidth: isInputActive ? 2 : 1
            )
    }
    
    private var emailErrorView: some View {
        HStack(spacing: 8) {
            Image(systemName: "exclamationmark.circle.fill")
                .foregroundColor(.red)
                .font(.caption)
            Text(authViewModel.emailError)
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.red)
        }
        .transition(.scale.combined(with: .opacity))
    }
    
    private var passwordField: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Password")
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.9) : .primary)
            
            HStack(spacing: 14) {
                passwordIcon
                passwordTextField
                passwordToggleButton
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 16)
            .background(fieldBackground)
            .cornerRadius(16)
            .overlay(passwordFieldBorder)
            .scaleEffect(isInputActive ? 1.02 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isInputActive)
            .scaleEffect(animateFields ? 1.0 : 0.9)
            .opacity(animateFields ? 1.0 : 0.0)
            .animation(.easeOut(duration: 0.6).delay(0.4), value: animateFields)
            
            if !authViewModel.passwordError.isEmpty {
                passwordErrorView
            }
        }
    }
    
    private var passwordIcon: some View {
        ZStack {
            Circle()
                .fill(passwordIconGradient)
                .frame(width: 36, height: 36)
            
            Image(systemName: "lock.fill")
                .foregroundColor(.white)
                .font(.system(size: 16, weight: .medium))
        }
    }
    
    private var passwordTextField: some View {
        Group {
            if showPassword {
                TextField("Enter your password", text: $password)
                    .textFieldStyle(PlainTextFieldStyle())
                    .foregroundColor(colorScheme == .dark ? .white : .primary)
                    .focused($isInputActive)
                    .font(.system(size: 16, weight: .medium))
            } else {
                SecureField("Enter your password", text: $password)
                    .textFieldStyle(PlainTextFieldStyle())
                    .foregroundColor(colorScheme == .dark ? .white : .primary)
                    .focused($isInputActive)
                    .font(.system(size: 16, weight: .medium))
            }
        }
    }
    
    private var passwordToggleButton: some View {
        Button(action: {
            withAnimation(.easeInOut(duration: 0.2)) {
                showPassword.toggle()
            }
        }) {
            ZStack {
                Circle()
                    .fill(Color.gray.opacity(0.1))
                    .frame(width: 32, height: 32)
                
                Image(systemName: showPassword ? "eye.slash.fill" : "eye.fill")
                    .foregroundColor(colorScheme == .dark ? .white.opacity(0.7) : .gray)
                    .font(.system(size: 14, weight: .medium))
            }
        }
    }
    
    private var passwordFieldBorder: some View {
        RoundedRectangle(cornerRadius: 16)
            .stroke(
                authViewModel.passwordError.isEmpty ?
                (isInputActive ?
                 LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing) :
                 LinearGradient(gradient: Gradient(colors: [Color.gray.opacity(0.3)]), startPoint: .leading, endPoint: .trailing)) :
                LinearGradient(gradient: Gradient(colors: [Color.red]), startPoint: .leading, endPoint: .trailing),
                lineWidth: isInputActive ? 2 : 1
            )
    }
    
    private var passwordErrorView: some View {
        HStack(spacing: 8) {
            Image(systemName: "exclamationmark.circle.fill")
                .foregroundColor(.red)
                .font(.caption)
            Text(authViewModel.passwordError)
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.red)
        }
        .transition(.scale.combined(with: .opacity))
    }
    
    private var forgotPasswordButton: some View {
        HStack {
            Spacer()
            Button("Forgot Password?") {
                authViewModel.resetPassword(email: email)
            }
            .font(.subheadline)
            .fontWeight(.semibold)
            .foregroundColor(.blue)
            .scaleEffect(animateFields ? 1.0 : 0.9)
            .opacity(animateFields ? 1.0 : 0.0)
            .animation(.easeOut(duration: 0.6).delay(0.5), value: animateFields)
        }
        .padding(.top, -8)
    }
    
    private var signInButton: some View {
        Button(action: {
            isInputActive = false
            authViewModel.signIn(email: email, password: password)
        }) {
            HStack(spacing: 12) {
                if authViewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .scaleEffect(0.9)
                } else {
                    Image(systemName: "arrow.right.circle.fill")
                        .font(.system(size: 20, weight: .medium))
                    Text("Sign In")
                        .fontWeight(.bold)
                        .font(.system(size: 17))
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .background(signInButtonBackground)
            .foregroundColor(.white)
        }
        .disabled(authViewModel.isLoading || email.isEmpty || password.isEmpty)
        .opacity(authViewModel.isLoading || email.isEmpty || password.isEmpty ? 0.6 : 1.0)
        .scaleEffect(authViewModel.isLoading ? 0.96 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: authViewModel.isLoading)
        .scaleEffect(animateFields ? 1.0 : 0.9)
        .opacity(animateFields ? 1.0 : 0.0)
        .animation(.easeOut(duration: 0.6).delay(0.6), value: animateFields)
        .padding(.top, 12)
    }
    
    private var signInButtonBackground: some View {
        RoundedRectangle(cornerRadius: 18)
            .fill(buttonGradient)
            .shadow(
                color: Color.blue.opacity(0.4),
                radius: 12,
                x: 0,
                y: 6
            )
    }
    
    @ViewBuilder
    private var errorMessage: some View {
        if !authViewModel.errorMessage.isEmpty {
            HStack(spacing: 12) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.red)
                    .font(.system(size: 16))
                Text(authViewModel.errorMessage)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.red)
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 14)
            .background(errorMessageBackground)
            .transition(.scale.combined(with: .opacity))
        }
    }
    
    private var errorMessageBackground: some View {
        RoundedRectangle(cornerRadius: 14)
            .fill(Color.red.opacity(0.08))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(Color.red.opacity(0.3), lineWidth: 1)
            )
    }
}

#Preview("Light Mode") {
    ZStack {
        Color.gray.opacity(0.1)
            .ignoresSafeArea()
        
        SignInForm()
            .environmentObject(AuthViewModel())
            .padding()
    }
    .preferredColorScheme(.light)
}

#Preview("Dark Mode") {
    ZStack {
        Color.black
            .ignoresSafeArea()
        
        SignInForm()
            .environmentObject(AuthViewModel())
            .padding()
    }
    .preferredColorScheme(.dark)
}
