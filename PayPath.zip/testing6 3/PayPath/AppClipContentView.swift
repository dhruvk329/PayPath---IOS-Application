import SwiftUI

struct AppClipContentView: View {
    @State private var principalAmount: String = ""
    @State private var interestRate: String = ""
    @State private var loanTerm: String = ""
    @State private var emiResult: Double = 0
    @State private var totalInterest: Double = 0
    @State private var totalAmount: Double = 0
    @State private var showingResults = false
    @State private var showingFullApp = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 25) {
                    // Header
                    VStack(spacing: 10) {
                        Image(systemName: "calculator.fill")
                            .font(.system(size: 50))
                            .foregroundColor(.blue)
                        
                        Text("EMI Calculator")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                        
                        Text("Quick loan payment calculator")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .padding(.top, 20)
                    
                    // Input Fields
                    VStack(spacing: 20) {
                        InputField(
                            title: "Loan Amount",
                            placeholder: "Enter principal amount",
                            text: $principalAmount,
                            keyboardType: .decimalPad
                        )
                        
                        InputField(
                            title: "Interest Rate (%)",
                            placeholder: "Enter annual interest rate",
                            text: $interestRate,
                            keyboardType: .decimalPad
                        )
                        
                        InputField(
                            title: "Loan Term (Months)",
                            placeholder: "Enter loan duration",
                            text: $loanTerm,
                            keyboardType: .numberPad
                        )
                    }
                    .padding(.horizontal)
                    
                    // Calculate Button
                    Button(action: calculateEMI) {
                        Text("Calculate EMI")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(12)
                    }
                    .padding(.horizontal)
                    .disabled(principalAmount.isEmpty || interestRate.isEmpty || loanTerm.isEmpty)
                    
                    // Results
                    if showingResults {
                        ResultsView(
                            emi: emiResult,
                            totalInterest: totalInterest,
                            totalAmount: totalAmount
                        )
                        .transition(.opacity.combined(with: .scale))
                    }
                    
                    // Get Full App Button
                    VStack(spacing: 15) {
                        Divider()
                            .padding(.horizontal)
                        
                        Text("Want to track your loans?")
                            .font(.headline)
                            .multilineTextAlignment(.center)
                        
                        Text("Get the full Loan Tracker app to manage multiple loans, track payments, and generate reports.")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        Button(action: {
                            showingFullApp = true
                        }) {
                            HStack {
                                Image(systemName: "arrow.down.circle.fill")
                                Text("Get Full App")
                            }
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(12)
                        }
                        .padding(.horizontal)
                    }
                    .padding(.top, 30)
                }
                .padding(.bottom, 30)
            }
            .navigationBarHidden(true)
            .onTapGesture {
                hideKeyboard()
            }
        }
        .appStoreOverlay(isPresented: $showingFullApp) {
            // This would link to your full app in the App Store
            // SKOverlay configuration would go here
        }
    }
    
    private func calculateEMI() {
        guard let principal = Double(principalAmount),
              let rate = Double(interestRate),
              let term = Double(loanTerm),
              principal > 0, rate > 0, term > 0 else {
            return
        }
        
        let monthlyRate = rate / (12 * 100)
        let denominator = pow(1 + monthlyRate, term) - 1
        
        if denominator != 0 {
            emiResult = principal * monthlyRate * pow(1 + monthlyRate, term) / denominator
            totalAmount = emiResult * term
            totalInterest = totalAmount - principal
        } else {
            emiResult = principal / term
            totalAmount = principal
            totalInterest = 0
        }
        
        withAnimation(.spring()) {
            showingResults = true
        }
    }
    
    private func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

struct InputField: View {
    let title: String
    let placeholder: String
    @Binding var text: String
    let keyboardType: UIKeyboardType
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)
                .foregroundColor(.primary)
            
            TextField(placeholder, text: $text)
                .keyboardType(keyboardType)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .font(.body)
        }
    }
}

struct ResultsView: View {
    let emi: Double
    let totalInterest: Double
    let totalAmount: Double
    
    var body: some View {
        VStack(spacing: 15) {
            Text("Calculation Results")
                .font(.headline)
                .padding(.bottom, 10)
            
            VStack(spacing: 12) {
                ResultRow(title: "Monthly EMI", value: formatCurrency(emi), color: .blue)
                ResultRow(title: "Total Interest", value: formatCurrency(totalInterest), color: .orange)
                ResultRow(title: "Total Amount", value: formatCurrency(totalAmount), color: .green)
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(12)
        }
        .padding(.horizontal)
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        return formatter.string(from: NSNumber(value: amount)) ?? "$0.00"
    }
}

struct ResultRow: View {
    let title: String
    let value: String
    let color: Color
    
    var body: some View {
        HStack {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
            
            Text(value)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(color)
        }
    }
}

#Preview {
    AppClipContentView()
}
