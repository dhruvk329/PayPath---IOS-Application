import SwiftUI
import Charts

struct LoanDetailView: View {
    let loan: LoanData
    @Environment(\.dismiss) private var dismiss
    @State private var showingAIStrategy = false
    @State private var aiStrategy = ""
    @State private var isLoadingStrategy = false
    @EnvironmentObject var authViewModel: AuthViewModel
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Loan Header
                    LoanHeaderView(loan: loan)
                    
                    // Interactive Pie Chart
                    LoanPieChartView(loan: loan) {
                        showingAIStrategy = true
                        generateAIStrategy()
                    }
                    
                    // Loan Details
                    LoanDetailsSection(loan: loan)
                    
                    // Payment History Section
                    PaymentHistorySection(loan: loan)
                    
                    // AI Strategy Section
                    if showingAIStrategy {
                        AIStrategySection(
                            strategy: aiStrategy,
                            isLoading: isLoadingStrategy
                        )
                    }
                }
                .padding()
            }
            .navigationTitle("Loan Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func generateAIStrategy() {
        isLoadingStrategy = true
        
        // Simulate AI processing (replace with actual AI API call)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            aiStrategy = generateLoanStrategy(for: loan, userDataManager: userDataManager)
            isLoadingStrategy = false
        }
    }
}

struct PaymentHistorySection: View {
    let loan: LoanData
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        VStack(spacing: 16) {
            HStack {
                Text("Payment History")
                    .font(.headline)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Text("\(loan.paymentHistory.count) payments")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            if loan.paymentHistory.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "clock.arrow.circlepath")
                        .font(.title2)
                        .foregroundColor(.secondary)
                    
                    Text("No payments processed yet")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Text("Payments will be processed automatically on due dates")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                .frame(height: 100)
            } else {
                LazyVStack(spacing: 8) {
                    ForEach(loan.paymentHistory.sorted { $0.date > $1.date }.prefix(5)) { payment in
                        PaymentRowView(payment: payment)
                    }
                    
                    if loan.paymentHistory.count > 5 {
                        Text("Showing latest 5 payments")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding(.top, 8)
                    }
                }
            }
            
            // Force Process Payment Button (for testing)
            Button("Force Process Payment (Testing)") {
                userDataManager.forceProcessPayment(for: loan.id)
            }
            .font(.caption)
            .foregroundColor(.orange)
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(Color.orange.opacity(0.1))
            .cornerRadius(8)
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(.ultraThinMaterial)
                .shadow(radius: 5)
        )
    }
}

struct PaymentRowView: View {
    let payment: PaymentRecord
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(payment.date, style: .date)
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Text("Payment: \(formatCurrency(payment.paymentAmount))")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            VStack(alignment: .trailing, spacing: 4) {
                HStack(spacing: 12) {
                    VStack(alignment: .trailing, spacing: 2) {
                        Text("Principal")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        Text(formatCurrency(payment.principalAmount))
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(.green)
                    }
                    
                    VStack(alignment: .trailing, spacing: 2) {
                        Text("Interest")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        Text(formatCurrency(payment.interestAmount))
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(.orange)
                    }
                }
                
                Text("Balance: \(formatCurrency(payment.remainingBalance))")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.gray.opacity(0.1))
        )
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
}

struct LoanHeaderView: View {
    let loan: LoanData
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        VStack(spacing: 18) {
            // Loan Icon and Name
            HStack {
                ZStack {
                    Circle()
                        .fill(LinearGradient(
                            gradient: Gradient(colors: loan.hasDefault ? [Color.red, Color.orange] : [Color.blue, Color.cyan]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                        .frame(width: 70, height: 70)
                        .shadow(color: (loan.hasDefault ? Color.red : Color.blue).opacity(0.3), radius: 10, x: 0, y: 5)
                    
                    Image(systemName: loan.hasDefault ? "exclamationmark.triangle.fill" : loan.loanType.icon)
                        .font(.system(size: 30))
                        .foregroundColor(.white)
                }
                
                VStack(alignment: .leading, spacing: 6) {
                    Text(loan.name)
                        .font(.title)
                        .fontWeight(.bold)
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                    
                    HStack {
                        Text(loan.loanType.rawValue)
                            .font(.body)
                            .foregroundColor(.secondary)
                        
                        if loan.hasDefault {
                            Text("• DEFAULT")
                                .font(.subheadline)
                                .fontWeight(.bold)
                                .foregroundColor(.red)
                        }
                    }
                }
                
                Spacer()
            }
            
            // Progress Bar
            VStack(spacing: 10) {
                HStack {
                    Text("Progress")
                        .font(.body)
                        .fontWeight(.medium)
                    
                    Spacer()
                    
                    Text("\(Int(progressPercentage * 100))% paid")
                        .font(.body)
                        .fontWeight(.semibold)
                        .foregroundColor(.green)
                }
                
                GeometryReader { geometry in
                    ZStack(alignment: .leading) {
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.gray.opacity(0.2))
                            .frame(height: 16)
                        
                        RoundedRectangle(cornerRadius: 8)
                            .fill(LinearGradient(
                                gradient: Gradient(colors: loan.hasDefault ? [Color.red, Color.orange] : [Color.green, Color.mint]),
                                startPoint: .leading,
                                endPoint: .trailing
                            ))
                            .frame(width: geometry.size.width * progressPercentage, height: 16)
                            .animation(.spring(response: 1.0, dampingFraction: 0.8), value: progressPercentage)
                    }
                }
                .frame(height: 16)
            }
        }
        .padding(24)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(.ultraThinMaterial)
                .shadow(radius: 8)
        )
    }
    
    private var progressPercentage: Double {
        guard loan.totalAmount > 0 else { return 0 }
        return (loan.totalAmount - loan.remainingAmount) / loan.totalAmount
    }
}

struct LoanDetailsSection: View {
    let loan: LoanData
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        VStack(spacing: 18) {
            Text("Loan Details")
                .font(.title2)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            LazyVGrid(columns: [
                GridItem(.flexible(), spacing: 12),
                GridItem(.flexible(), spacing: 12)
            ], spacing: 18) {
                DetailCard(
                    title: "Total Amount",
                    value: formatCurrency(loan.totalAmount),
                    icon: "dollarsign.circle",
                    color: .blue
                )
                
                DetailCard(
                    title: "Outstanding Principal",
                    value: formatCurrency(loan.outstandingPrincipal),
                    icon: "banknote",
                    color: .red
                )
                
                DetailCard(
                    title: "Interest Rate",
                    value: "\(String(format: "%.1f", loan.interestRate))%",
                    icon: "percent",
                    color: .orange
                )
                
                DetailCard(
                    title: "Monthly Payment",
                    value: formatCurrency(loan.monthlyPayment),
                    icon: "calendar",
                    color: .green
                )
                
                DetailCard(
                    title: "Start Date",
                    value: formatDate(loan.startDate),
                    icon: "calendar.badge.plus",
                    color: .mint
                )
                
                DetailCard(
                    title: "End Date",
                    value: formatDate(loan.endDate),
                    icon: "calendar.badge.minus",
                    color: .teal
                )
                
                DetailCard(
                    title: "Due Date",
                    value: "\(loan.dueDate)\(getOrdinalSuffix(loan.dueDate)) of month",
                    icon: "clock",
                    color: .cyan
                )
                
                DetailCard(
                    title: "Total Interest Paid",
                    value: formatCurrency(loan.totalInterestPaid),
                    icon: "chart.line.uptrend.xyaxis",
                    color: .pink
                )
                
                if loan.hasDefault {
                    DetailCard(
                        title: "Penalty Amount",
                        value: formatCurrency(loan.penaltyAmount),
                        icon: "exclamationmark.triangle",
                        color: .red
                    )
                    
                    DetailCard(
                        title: "Default Count",
                        value: "\(loan.defaultCount)",
                        icon: "exclamationmark.circle",
                        color: .red
                    )
                }
            }
        }
        .padding(24)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(.ultraThinMaterial)
                .shadow(radius: 8)
        )
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
    
    private func getOrdinalSuffix(_ number: Int) -> String {
        switch number {
        case 1, 21, 31: return "st"
        case 2, 22: return "nd"
        case 3, 23: return "rd"
        default: return "th"
        }
    }
}

struct DetailCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 14) {
            HStack {
                ZStack {
                    Circle()
                        .fill(color.opacity(0.2))
                        .frame(width: 36, height: 36)
                    
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(color)
                }
                
                Spacer()
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text(value)
                    .font(.body)
                    .fontWeight(.bold)
                    .lineLimit(2)
                    .minimumScaleFactor(0.7)
                    .fixedSize(horizontal: false, vertical: true)
                
                Text(title)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(minHeight: 110)
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(color.opacity(0.3), lineWidth: 1)
                )
        )
    }
}

struct LoanPieChartView: View {
    let loan: LoanData
    let onAIStrategyTap: () -> Void
    @EnvironmentObject var userDataManager: UserDataManager
    
    private var chartData: [(String, Double, Color)] {
        let paidAmount = loan.totalAmount - loan.remainingAmount
        return [
            ("Paid", paidAmount, .green),
            ("Remaining", loan.remainingAmount, .red)
        ]
    }
    
    var body: some View {
        VStack(spacing: 18) {
            Text("Payment Breakdown")
                .font(.title2)
                .fontWeight(.semibold)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            VStack(spacing: 20) {
                // Pie Chart
                ZStack {
                    Chart(chartData, id: \.0) { item in
                        SectorMark(
                            angle: .value("Amount", item.1),
                            innerRadius: .ratio(0.5),
                            angularInset: 2
                        )
                        .foregroundStyle(item.2)
                        .opacity(0.8)
                    }
                    .frame(width: 150, height: 150)
                    
                    VStack(spacing: 3) {
                        Text("\(Int(progressPercentage * 100))%")
                            .font(.title2)
                            .fontWeight(.bold)
                        Text("Paid")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                
                // Legend and Stats
                VStack(alignment: .leading, spacing: 14) {
                    ForEach(chartData, id: \.0) { item in
                        HStack(spacing: 10) {
                            Circle()
                                .fill(item.2)
                                .frame(width: 14, height: 14)
                            
                            VStack(alignment: .leading, spacing: 3) {
                                Text(item.0)
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                
                                Text(formatCurrency(item.1))
                                    .font(.body)
                                    .fontWeight(.semibold)
                            }
                            
                            Spacer()
                        }
                    }
                    
                    Divider()
                        .padding(.vertical, 8)
                    
                    Button("Get AI Financial Strategy") {
                        onAIStrategyTap()
                    }
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.blue)
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 12)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(10)
                }
            }
        }
        .padding(24)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(.ultraThinMaterial)
                .shadow(radius: 8)
        )
    }
    
    private var progressPercentage: Double {
        guard loan.totalAmount > 0 else { return 0 }
        return (loan.totalAmount - loan.remainingAmount) / loan.totalAmount
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        return userDataManager.formatCurrency(amount)
    }
}

struct AIStrategySection: View {
    let strategy: String
    let isLoading: Bool
    
    var body: some View {
        VStack(spacing: 18) {
            HStack {
                Image(systemName: "brain.head.profile")
                    .font(.title)
                    .foregroundColor(.purple)
                
                Text("AI Financial Strategy")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Spacer()
            }
            
            if isLoading {
                VStack(spacing: 14) {
                    ProgressView()
                        .scaleEffect(1.3)
                    
                    Text("Analyzing your loan and generating personalized strategy...")
                        .font(.body)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                .frame(height: 120)
            } else {
                ScrollView {
                    Text(strategy)
                        .font(.body)
                        .lineSpacing(6)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .frame(maxHeight: 300)
            }
        }
        .padding(24)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 18)
                        .stroke(Color.purple.opacity(0.3), lineWidth: 1)
                )
                .shadow(radius: 8)
        )
    }
}

// AI Strategy Generator Function
func generateLoanStrategy(for loan: LoanData, userDataManager: UserDataManager) -> String {
    let progressPercentage = (loan.totalAmount - loan.remainingAmount) / loan.totalAmount * 100
    let monthsRemaining = Calendar.current.dateComponents([.month], from: Date(), to: loan.endDate).month ?? 0
    
    var strategy = "📊 **Personalized Financial Strategy for \(loan.name)**\n\n"
    
    // Progress Analysis
    if progressPercentage < 25 {
        strategy += "🚀 **Early Stage Optimization:**\n"
        strategy += "• You're \(Int(progressPercentage))% through your loan journey\n"
        strategy += "• Consider making extra principal payments early to reduce total interest\n"
        strategy += "• Even an extra \(userDataManager.formatCurrency(50)) monthly can save thousands\n\n"
    } else if progressPercentage < 75 {
        strategy += "⚡ **Mid-Journey Acceleration:**\n"
        strategy += "• Great progress at \(Int(progressPercentage))% completion!\n"
        strategy += "• Focus on consistent payments to maintain momentum\n"
        strategy += "• Consider refinancing if rates have dropped significantly\n\n"
    } else {
        strategy += "🎯 **Final Sprint Strategy:**\n"
        strategy += "• Excellent! You're \(Int(progressPercentage))% complete\n"
        strategy += "• Consider paying off early to save on remaining interest\n"
        strategy += "• Start planning for your next financial goals\n\n"
    }
    
    // Interest Rate Analysis
    if loan.interestRate > 7.0 {
        strategy += "💡 **High Interest Alert:**\n"
        strategy += "• Your \(String(format: "%.1f", loan.interestRate))% rate is above average\n"
        strategy += "• Strongly consider refinancing or debt consolidation\n"
        strategy += "• Prioritize this loan for extra payments\n\n"
    } else if loan.interestRate < 4.0 {
        strategy += "✅ **Great Rate Advantage:**\n"
        strategy += "• Your \(String(format: "%.1f", loan.interestRate))% rate is excellent\n"
        strategy += "• Consider investing extra funds instead of early payoff\n"
        strategy += "• Maintain minimum payments and invest the difference\n\n"
    }
    
    // Default Status
    if loan.hasDefault {
        strategy += "⚠️ **Default Recovery Plan:**\n"
        strategy += "• Address default status immediately to avoid further penalties\n"
        strategy += "• Contact lender to negotiate payment plan\n"
        strategy += "• Consider debt counseling services\n"
        strategy += "• Penalty amount: \(userDataManager.formatCurrency(loan.penaltyAmount))\n\n"
    }
    
    // Time-based recommendations
    if monthsRemaining > 0 {
        strategy += "⏰ **Timeline Strategy:**\n"
        strategy += "• \(monthsRemaining) months remaining on your loan\n"
        if monthsRemaining < 12 {
            strategy += "• Consider paying off early to save on interest\n"
        } else if monthsRemaining > 60 {
            strategy += "• Long timeline allows for strategic extra payments\n"
        }
        strategy += "• Set up automatic payments to never miss due dates\n\n"
    }
    
    // Monthly payment optimization
    strategy += "💰 **Payment Optimization:**\n"
    strategy += "• Current monthly payment: \(userDataManager.formatCurrency(loan.monthlyPayment))\n"
    strategy += "• Outstanding principal: \(userDataManager.formatCurrency(loan.outstandingPrincipal))\n"
    strategy += "• Total interest paid so far: \(userDataManager.formatCurrency(loan.totalInterestPaid))\n\n"
    
    strategy += "🎯 **Next Steps:**\n"
    strategy += "1. Review your budget for potential extra payments\n"
    strategy += "2. Set up automatic payments for your due date (\(loan.dueDate)\(getOrdinalSuffix(loan.dueDate)))\n"
    strategy += "3. Monitor interest rates for refinancing opportunities\n"
    strategy += "4. Track your progress monthly using this app\n"
    
    return strategy
}

private func getOrdinalSuffix(_ number: Int) -> String {
    switch number {
    case 1, 21, 31: return "st"
    case 2, 22: return "nd"
    case 3, 23: return "rd"
    default: return "th"
    }
}

#Preview {
    LoanDetailView(loan: LoanData(
        name: "Sample Loan",
        totalAmount: 25000,
        remainingAmount: 15000,
        interestRate: 5.5,
        firstEMI: 500,
        lastEMI: 450,
        dueDate: 15,
        startDate: Date(),
        endDate: Calendar.current.date(byAdding: .year, value: 2, to: Date()) ?? Date(),
        loanType: .personal
    ))
    .environmentObject(AuthViewModel())
    .environmentObject(UserDataManager())
}
