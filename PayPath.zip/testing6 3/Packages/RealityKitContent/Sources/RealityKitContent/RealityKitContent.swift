import Foundation

/// Bundle for the RealityKitContent project
public let realityKitContentBundle = Bundle.module
