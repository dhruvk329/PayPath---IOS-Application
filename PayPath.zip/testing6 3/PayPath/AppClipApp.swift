import SwiftUI

@main
struct LoanTrackerAppClip: App {
    var body: some Scene {
        WindowGroup {
            AppClipContentView()
        }
    }
}
