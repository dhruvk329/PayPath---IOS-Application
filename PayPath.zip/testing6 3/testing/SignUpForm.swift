import SwiftUI

struct SignUpForm: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var fullName = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var showPassword = false
    @State private var showConfirmPassword = false
    @State private var agreeToTerms = false
    @Environment(\.colorScheme) var colorScheme
    @FocusState private var isInputActive: Bool
    @State private var animateFields = false
    @State private var showingTerms = false
    @State private var showingPrivacyPolicy = false
    
    // Computed properties to break down complex expressions
    private var nameIconGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [Color.green.opacity(0.8), Color.green.opacity(0.6)]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var emailIconGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.blue.opacity(0.6)]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var passwordIconGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [Color.purple.opacity(0.8), Color.purple.opacity(0.6)]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var confirmPasswordIconGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [Color.orange.opacity(0.8), Color.orange.opacity(0.6)]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    private var fieldBackground: Color {
        colorScheme == .dark ?
        Color.white.opacity(0.08) :
        Color.gray.opacity(0.06)
    }
    
    private var buttonGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [
                Color.blue,
                Color.purple,
                Color.blue.opacity(0.8)
            ]),
            startPoint: .leading,
            endPoint: .trailing
        )
    }
    
    private var checkboxGradient: LinearGradient {
        LinearGradient(
            gradient: Gradient(colors: [Color.blue, Color.purple]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
    
    var body: some View {
        VStack(spacing: 24) {
            headerSection
            nameField
            emailField
            passwordField
            confirmPasswordField
            termsSection
            signUpButton
            errorMessage
        }
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Done") {
                    isInputActive = false
                }
                .foregroundColor(.blue)
                .fontWeight(.semibold)
            }
        }
        .onTapGesture {
            isInputActive = false
        }
        .onAppear {
            animateFields = true
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 10) {
            Text("Create Account")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(colorScheme == .dark ? .white : .primary)
                .scaleEffect(animateFields ? 1.0 : 0.9)
                .opacity(animateFields ? 1.0 : 0.0)
                .animation(.easeOut(duration: 0.6).delay(0.1), value: animateFields)
            
            Text("Join PayPath to start tracking your loans")
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.7) : .secondary)
                .multilineTextAlignment(.center)
                .scaleEffect(animateFields ? 1.0 : 0.9)
                .opacity(animateFields ? 1.0 : 0.0)
                .animation(.easeOut(duration: 0.6).delay(0.2), value: animateFields)
        }
        .padding(.bottom, 8)
    }
    
    private var nameField: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Full Name")
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.9) : .primary)
            
            HStack(spacing: 14) {
                nameIcon
                nameTextField
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 16)
            .background(fieldBackground)
            .cornerRadius(16)
            .overlay(nameFieldBorder)
            .scaleEffect(isInputActive ? 1.02 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isInputActive)
            .scaleEffect(animateFields ? 1.0 : 0.9)
            .opacity(animateFields ? 1.0 : 0.0)
            .animation(.easeOut(duration: 0.6).delay(0.3), value: animateFields)
        }
    }
    
    private var nameIcon: some View {
        ZStack {
            Circle()
                .fill(nameIconGradient)
                .frame(width: 36, height: 36)
            
            Image(systemName: "person.fill")
                .foregroundColor(.white)
                .font(.system(size: 16, weight: .medium))
        }
    }
    
    private var nameTextField: some View {
        TextField("Enter your full name", text: $fullName)
            .textFieldStyle(PlainTextFieldStyle())
            .autocorrectionDisabled()
            .foregroundColor(colorScheme == .dark ? .white : .primary)
            .focused($isInputActive)
            .font(.system(size: 16, weight: .medium))
    }
    
    private var nameFieldBorder: some View {
        RoundedRectangle(cornerRadius: 16)
            .stroke(
                isInputActive ?
                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing) :
                LinearGradient(gradient: Gradient(colors: [Color.gray.opacity(0.3)]), startPoint: .leading, endPoint: .trailing),
                lineWidth: isInputActive ? 2 : 1
            )
    }
    
    private var emailField: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Email Address")
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.9) : .primary)
            
            HStack(spacing: 14) {
                emailIcon
                emailTextField
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 16)
            .background(fieldBackground)
            .cornerRadius(16)
            .overlay(emailFieldBorder)
            .scaleEffect(isInputActive ? 1.02 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isInputActive)
            .scaleEffect(animateFields ? 1.0 : 0.9)
            .opacity(animateFields ? 1.0 : 0.0)
            .animation(.easeOut(duration: 0.6).delay(0.4), value: animateFields)
            
            if !authViewModel.emailError.isEmpty {
                emailErrorView
            }
        }
    }
    
    private var emailIcon: some View {
        ZStack {
            Circle()
                .fill(emailIconGradient)
                .frame(width: 36, height: 36)
            
            Image(systemName: "envelope.fill")
                .foregroundColor(.white)
                .font(.system(size: 16, weight: .medium))
        }
    }
    
    private var emailTextField: some View {
        TextField("Enter your email", text: $email)
            .textFieldStyle(PlainTextFieldStyle())
            .textContentType(.emailAddress)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .foregroundColor(colorScheme == .dark ? .white : .primary)
            .focused($isInputActive)
            .font(.system(size: 16, weight: .medium))
    }
    
    private var emailFieldBorder: some View {
        RoundedRectangle(cornerRadius: 16)
            .stroke(
                authViewModel.emailError.isEmpty ?
                (isInputActive ?
                 LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing) :
                 LinearGradient(gradient: Gradient(colors: [Color.gray.opacity(0.3)]), startPoint: .leading, endPoint: .trailing)) :
                LinearGradient(gradient: Gradient(colors: [Color.red]), startPoint: .leading, endPoint: .trailing),
                lineWidth: isInputActive ? 2 : 1
            )
    }
    
    private var emailErrorView: some View {
        HStack(spacing: 8) {
            Image(systemName: "exclamationmark.circle.fill")
                .foregroundColor(.red)
                .font(.caption)
            Text(authViewModel.emailError)
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.red)
        }
        .transition(.scale.combined(with: .opacity))
    }
    
    private var passwordField: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Password")
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.9) : .primary)
            
            HStack(spacing: 14) {
                passwordIcon
                passwordTextField
                passwordToggleButton
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 16)
            .background(fieldBackground)
            .cornerRadius(16)
            .overlay(passwordFieldBorder)
            .scaleEffect(isInputActive ? 1.02 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isInputActive)
            .scaleEffect(animateFields ? 1.0 : 0.9)
            .opacity(animateFields ? 1.0 : 0.0)
            .animation(.easeOut(duration: 0.6).delay(0.5), value: animateFields)
            
            if !authViewModel.passwordError.isEmpty {
                passwordErrorView
            }
        }
    }
    
    private var passwordIcon: some View {
        ZStack {
            Circle()
                .fill(passwordIconGradient)
                .frame(width: 36, height: 36)
            
            Image(systemName: "lock.fill")
                .foregroundColor(.white)
                .font(.system(size: 16, weight: .medium))
        }
    }
    
    private var passwordTextField: some View {
        Group {
            if showPassword {
                TextField("Create a password", text: $password)
                    .textFieldStyle(PlainTextFieldStyle())
                    .foregroundColor(colorScheme == .dark ? .white : .primary)
                    .focused($isInputActive)
                    .font(.system(size: 16, weight: .medium))
            } else {
                SecureField("Create a password", text: $password)
                    .textFieldStyle(PlainTextFieldStyle())
                    .foregroundColor(colorScheme == .dark ? .white : .primary)
                    .focused($isInputActive)
                    .font(.system(size: 16, weight: .medium))
            }
        }
    }
    
    private var passwordToggleButton: some View {
        Button(action: {
            withAnimation(.easeInOut(duration: 0.2)) {
                showPassword.toggle()
            }
        }) {
            ZStack {
                Circle()
                    .fill(Color.gray.opacity(0.1))
                    .frame(width: 32, height: 32)
                
                Image(systemName: showPassword ? "eye.slash.fill" : "eye.fill")
                    .foregroundColor(colorScheme == .dark ? .white.opacity(0.7) : .gray)
                    .font(.system(size: 14, weight: .medium))
            }
        }
    }
    
    private var passwordFieldBorder: some View {
        RoundedRectangle(cornerRadius: 16)
            .stroke(
                authViewModel.passwordError.isEmpty ?
                (isInputActive ?
                 LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing) :
                 LinearGradient(gradient: Gradient(colors: [Color.gray.opacity(0.3)]), startPoint: .leading, endPoint: .trailing)) :
                LinearGradient(gradient: Gradient(colors: [Color.red]), startPoint: .leading, endPoint: .trailing),
                lineWidth: isInputActive ? 2 : 1
            )
    }
    
    private var passwordErrorView: some View {
        HStack(spacing: 8) {
            Image(systemName: "exclamationmark.circle.fill")
                .foregroundColor(.red)
                .font(.caption)
            Text(authViewModel.passwordError)
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.red)
        }
        .transition(.scale.combined(with: .opacity))
    }
    
    private var confirmPasswordField: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Confirm Password")
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.9) : .primary)
            
            HStack(spacing: 14) {
                confirmPasswordIcon
                confirmPasswordTextField
                confirmPasswordToggleButton
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 16)
            .background(fieldBackground)
            .cornerRadius(16)
            .overlay(confirmPasswordFieldBorder)
            .scaleEffect(isInputActive ? 1.02 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isInputActive)
            .scaleEffect(animateFields ? 1.0 : 0.9)
            .opacity(animateFields ? 1.0 : 0.0)
            .animation(.easeOut(duration: 0.6).delay(0.6), value: animateFields)
            
            if password != confirmPassword && !confirmPassword.isEmpty {
                confirmPasswordErrorView
            }
        }
    }
    
    private var confirmPasswordIcon: some View {
        ZStack {
            Circle()
                .fill(confirmPasswordIconGradient)
                .frame(width: 36, height: 36)
            
            Image(systemName: "lock.fill")
                .foregroundColor(.white)
                .font(.system(size: 16, weight: .medium))
        }
    }
    
    private var confirmPasswordTextField: some View {
        Group {
            if showConfirmPassword {
                TextField("Confirm your password", text: $confirmPassword)
                    .textFieldStyle(PlainTextFieldStyle())
                    .foregroundColor(colorScheme == .dark ? .white : .primary)
                    .focused($isInputActive)
                    .font(.system(size: 16, weight: .medium))
            } else {
                SecureField("Confirm your password", text: $confirmPassword)
                    .textFieldStyle(PlainTextFieldStyle())
                    .foregroundColor(colorScheme == .dark ? .white : .primary)
                    .focused($isInputActive)
                    .font(.system(size: 16, weight: .medium))
            }
        }
    }
    
    private var confirmPasswordToggleButton: some View {
        Button(action: {
            withAnimation(.easeInOut(duration: 0.2)) {
                showConfirmPassword.toggle()
            }
        }) {
            ZStack {
                Circle()
                    .fill(Color.gray.opacity(0.1))
                    .frame(width: 32, height: 32)
                
                Image(systemName: showConfirmPassword ? "eye.slash.fill" : "eye.fill")
                    .foregroundColor(colorScheme == .dark ? .white.opacity(0.7) : .gray)
                    .font(.system(size: 14, weight: .medium))
            }
        }
    }
    
    private var confirmPasswordFieldBorder: some View {
        RoundedRectangle(cornerRadius: 16)
            .stroke(
                password != confirmPassword && !confirmPassword.isEmpty ?
                LinearGradient(gradient: Gradient(colors: [Color.red]), startPoint: .leading, endPoint: .trailing) :
                (isInputActive ?
                 LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .leading, endPoint: .trailing) :
                 LinearGradient(gradient: Gradient(colors: [Color.gray.opacity(0.3)]), startPoint: .leading, endPoint: .trailing)),
                lineWidth: isInputActive ? 2 : 1
            )
    }
    
    private var confirmPasswordErrorView: some View {
        HStack(spacing: 8) {
            Image(systemName: "exclamationmark.circle.fill")
                .foregroundColor(.red)
                .font(.caption)
            Text("Passwords do not match")
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.red)
        }
        .transition(.scale.combined(with: .opacity))
    }
    
    private var termsSection: some View {
        HStack(alignment: .top, spacing: 14) {
            termsCheckbox
            termsText
            Spacer()
        }
        .scaleEffect(animateFields ? 1.0 : 0.9)
        .opacity(animateFields ? 1.0 : 0.0)
        .animation(.easeOut(duration: 0.6).delay(0.7), value: animateFields)
        .padding(.top, 8)
    }
    
    private var termsCheckbox: some View {
        Button(action: {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                agreeToTerms.toggle()
            }
        }) {
            ZStack {
                RoundedRectangle(cornerRadius: 6)
                    .fill(
                        agreeToTerms ?
                        AnyShapeStyle(checkboxGradient) :
                        AnyShapeStyle(Color.gray.opacity(0.2))
                    )

                    .frame(width: 24, height: 24)
                    .overlay(
                        RoundedRectangle(cornerRadius: 6)
                            .stroke(
                                agreeToTerms ? Color.clear : Color.gray.opacity(0.4),
                                lineWidth: 1
                            )
                    )
                
                if agreeToTerms {
                    Image(systemName: "checkmark")
                        .foregroundColor(.white)
                        .font(.system(size: 12, weight: .bold))
                        .scaleEffect(agreeToTerms ? 1.0 : 0.0)
                        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: agreeToTerms)
                }
            }
        }
    }
    
    private var termsText: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("I agree to the Terms of Service and Privacy Policy")
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(colorScheme == .dark ? .white.opacity(0.8) : .primary)
        
            HStack(spacing: 20) {
                Button("Terms of Service") {
                    showingTerms = true
                }
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(.blue)
                .underline()
            
                Button("Privacy Policy") {
                    showingPrivacyPolicy = true
                }
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(.blue)
                .underline()
            }
        }
        .sheet(isPresented: $showingTerms) {
            TermsOfServiceView()
        }
        .sheet(isPresented: $showingPrivacyPolicy) {
            NavigationView {
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        Text("Privacy Policy")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .padding(.bottom, 10)
                        
                        Text("Effective Date: January 1, 2025")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .padding(.bottom, 20)
                        
                        Group {
                            privacySection(
                                title: "1. Information We Collect",
                                content: """
                                We collect information you provide directly to us, such as:
                                • Personal information (name, email address)
                                • Financial information (loan details, payment amounts, interest rates)
                                • Device information and usage data
                                • Biometric data (if you enable Face ID/Touch ID)
                                """
                            )
                            
                            privacySection(
                                title: "2. How We Use Your Information",
                                content: """
                                We use your information to:
                                • Provide and maintain our loan tracking services
                                • Calculate loan payments and generate reports
                                • Send you notifications about your loans
                                • Improve our app and user experience
                                • Ensure the security of your account
                                """
                            )
                            
                            privacySection(
                                title: "3. Information Sharing",
                                content: """
                                We do not sell, trade, or rent your personal information to third parties. We may share your information only in the following circumstances:
                                • With your explicit consent
                                • To comply with legal obligations
                                • To protect our rights and safety
                                • With service providers who assist in app functionality
                                """
                            )
                        }
                        
                        Group {
                            privacySection(
                                title: "4. Data Security",
                                content: """
                                We implement appropriate security measures to protect your information:
                                • End-to-end encryption for sensitive data
                                • Secure cloud storage with industry-standard protocols
                                • Biometric authentication options
                                • Regular security audits and updates
                                """
                            )
                            
                            privacySection(
                                title: "5. Your Rights",
                                content: """
                                You have the right to:
                                • Access your personal information
                                • Correct inaccurate information
                                • Delete your account and data
                                • Export your data
                                • Opt-out of certain communications
                                """
                            )
                            
                            privacySection(
                                title: "6. Contact Us",
                                content: """
                                If you have questions about this privacy policy, please contact us at:
                                Email: privacy@paypath.app
                                Address: PayPath Privacy Team, 123 Finance St, Tech City, TC 12345
                                """
                            )
                        }
                    }
                    .padding()
                }
                .navigationTitle("Privacy Policy")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("Done") {
                            showingPrivacyPolicy = false
                        }
                    }
                }
            }
        }
    }
    
    private var signUpButton: some View {
        Button(action: {
            isInputActive = false
            authViewModel.signUp(
                fullName: fullName,
                email: email,
                password: password,
                confirmPassword: confirmPassword
            )
        }) {
            HStack(spacing: 12) {
                if authViewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .scaleEffect(0.9)
                } else {
                    Image(systemName: "person.badge.plus.fill")
                        .font(.system(size: 20, weight: .medium))
                    Text("Create Account")
                        .fontWeight(.bold)
                        .font(.system(size: 17))
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .background(signUpButtonBackground)
            .foregroundColor(.white)
        }
        .disabled(authViewModel.isLoading || !isFormValid)
        .opacity(authViewModel.isLoading || !isFormValid ? 0.6 : 1.0)
        .scaleEffect(authViewModel.isLoading ? 0.96 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: authViewModel.isLoading)
        .scaleEffect(animateFields ? 1.0 : 0.9)
        .opacity(animateFields ? 1.0 : 0.0)
        .animation(.easeOut(duration: 0.6).delay(0.8), value: animateFields)
        .padding(.top, 12)
    }
    
    private var signUpButtonBackground: some View {
        RoundedRectangle(cornerRadius: 18)
            .fill(buttonGradient)
            .shadow(
                color: Color.purple.opacity(0.4),
                radius: 12,
                x: 0,
                y: 6
            )
    }
    
    @ViewBuilder
    private var errorMessage: some View {
        if !authViewModel.errorMessage.isEmpty {
            HStack(spacing: 12) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.red)
                    .font(.system(size: 16))
                Text(authViewModel.errorMessage)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.red)
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 14)
            .background(errorMessageBackground)
            .transition(.scale.combined(with: .opacity))
        }
    }
    
    private var errorMessageBackground: some View {
        RoundedRectangle(cornerRadius: 14)
            .fill(Color.red.opacity(0.08))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(Color.red.opacity(0.3), lineWidth: 1)
            )
    }
    
    private var isFormValid: Bool {
        !fullName.isEmpty &&
        !email.isEmpty &&
        !password.isEmpty &&
        password == confirmPassword &&
        agreeToTerms &&
        password.count >= 6
    }
    
    private func privacySection(title: String, content: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Text(content)
                .font(.body)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 8)
    }
}

struct TermsOfServiceView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Terms of Service")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.bottom, 10)
                    
                    Text("Effective Date: January 1, 2025")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .padding(.bottom, 20)
                    
                    termsSection(
                        title: "1. Acceptance of Terms",
                        content: """
                        By downloading, installing, or using PayPath ("the App"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use the App.
                        """
                    )
                    
                    termsSection(
                        title: "2. Description of Service",
                        content: """
                        PayPath is a personal finance application designed to help users track and manage their loans, calculate payments, and monitor debt progress. The App provides:
                        • Loan tracking and management tools
                        • Payment calculators and schedules
                        • Progress reports and analytics
                        • Secure data storage and synchronization
                        """
                    )
                    
                    termsSection(
                        title: "3. User Account and Responsibilities",
                        content: """
                        You are responsible for:
                        • Maintaining the confidentiality of your account credentials
                        • All activities that occur under your account
                        • Providing accurate and up-to-date information
                        • Using the App in compliance with applicable laws
                        • Not sharing your account with others
                        """
                    )
                    
                    termsSection(
                        title: "4. Acceptable Use",
                        content: """
                        You agree not to:
                        • Use the App for any illegal or unauthorized purpose
                        • Attempt to gain unauthorized access to our systems
                        • Interfere with or disrupt the App's functionality
                        • Upload malicious code or harmful content
                        • Violate any applicable laws or regulations
                        """
                    )
                    
                    termsSection(
                        title: "5. Financial Information Disclaimer",
                        content: """
                        PayPath is a tracking tool only. We do not provide financial advice, and the App should not be considered as such. All calculations are estimates and may not reflect actual loan terms. Always consult with financial professionals for important decisions.
                        """
                    )
                    
                    termsSection(
                        title: "6. Data and Privacy",
                        content: """
                        Your privacy is important to us. Our collection and use of your information is governed by our Privacy Policy, which is incorporated into these Terms by reference.
                        """
                    )
                    
                    termsSection(
                        title: "7. Limitation of Liability",
                        content: """
                        PayPath is provided "as is" without warranties of any kind. We shall not be liable for any indirect, incidental, special, or consequential damages arising from your use of the App.
                        """
                    )
                    
                    termsSection(
                        title: "8. Termination",
                        content: """
                        You may terminate your account at any time by deleting the App and contacting us to remove your data. We may terminate or suspend your access if you violate these Terms.
                        """
                    )
                    
                    termsSection(
                        title: "9. Updates and Changes",
                        content: """
                        We may update the App and these Terms from time to time. Continued use of the App after changes constitutes acceptance of the new Terms.
                        """
                    )
                    
                    termsSection(
                        title: "10. Contact Information",
                        content: """
                        For questions about these Terms, please contact us at:
                        Email: support@paypath.app
                        Address: PayPath Support Team, 123 Finance St, Tech City, TC 12345
                        """
                    )
                }
                .padding()
            }
            .navigationTitle("Terms of Service")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func termsSection(title: String, content: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Text(content)
                .font(.body)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 8)
    }
}

#Preview("Light Mode") {
    ZStack {
        Color.gray.opacity(0.1)
            .ignoresSafeArea()
        
        SignUpForm()
            .environmentObject(AuthViewModel())
            .padding()
    }
    .preferredColorScheme(.light)
}

#Preview("Dark Mode") {
    ZStack {
        Color.black
            .ignoresSafeArea()
        
        SignUpForm()
            .environmentObject(AuthViewModel())
            .padding()
    }
    .preferredColorScheme(.dark)
}
