import SwiftUI
import FirebaseAuth

struct EditProfileView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @EnvironmentObject var userDataManager: UserDataManager
    @Environment(\.dismiss) private var dismiss
    
    @State private var fullName: String = ""
    @State private var email: String = ""
    @State private var currentPassword: String = ""
    @State private var isLoading = false
    @State private var showingAlert = false
    @State private var alertMessage = ""
    @State private var alertTitle = "Profile Update"
    @State private var showPasswordField = false
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Personal Information")) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Full Name")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        TextField("Enter your full name", text: $fullName)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Email Address")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        TextField("Enter your email", text: $email)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.emailAddress)
                            .autocapitalization(.none)
                    }
                }
                
                // Show password field only if email is being changed
                if showPasswordField {
                    Section(header: Text("Security Verification")) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Current Password")
                                .font(.subheadline)
                                .fontWeight(.medium)
                            SecureField("Enter your current password", text: $currentPassword)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                        
                        Text("Password required to change email address for security.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Section {
                    Button(action: updateProfile) {
                        if isLoading {
                            HStack {
                                ProgressView()
                                    .scaleEffect(0.8)
                                Text("Updating...")
                            }
                        } else {
                            Text("Update Profile")
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .disabled(isLoading || fullName.isEmpty || email.isEmpty || (showPasswordField && currentPassword.isEmpty))
                }
            }
            .navigationTitle("Edit Profile")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .onAppear {
                loadCurrentProfile()
            }
            .onChange(of: email) { newEmail in
                let originalEmail = userDataManager.userProfile?.email ?? ""
                showPasswordField = (newEmail != originalEmail && !newEmail.isEmpty)
                if !showPasswordField {
                    currentPassword = ""
                }
            }
            .alert(alertTitle, isPresented: $showingAlert) {
                Button("OK") {
                    if alertMessage.contains("successfully") {
                        dismiss()
                    }
                }
            } message: {
                Text(alertMessage)
            }
        }
    }
    
    private func loadCurrentProfile() {
        fullName = userDataManager.userProfile?.fullName ?? ""
        email = userDataManager.userProfile?.email ?? ""
    }
    
    private func updateProfile() {
        guard !fullName.isEmpty, !email.isEmpty else {
            alertTitle = "Error"
            alertMessage = "Please fill in all fields"
            showingAlert = true
            return
        }
        
        guard isValidEmail(email) else {
            alertTitle = "Error"
            alertMessage = "Please enter a valid email address"
            showingAlert = true
            return
        }
        
        let originalEmail = userDataManager.userProfile?.email ?? ""
        
        if email != originalEmail {
            // Email is changing, need re-authentication
            guard !currentPassword.isEmpty else {
                alertTitle = "Error"
                alertMessage = "Please enter your current password to change email"
                showingAlert = true
                return
            }
            
            isLoading = true
            reauthenticateAndUpdateEmail()
        } else {
            // Just updating name
            isLoading = true
            updateProfileData()
        }
    }
    
    private func reauthenticateAndUpdateEmail() {
        guard let currentUser = Auth.auth().currentUser,
              let userEmail = currentUser.email else {
            isLoading = false
            alertTitle = "Error"
            alertMessage = "No authenticated user found"
            showingAlert = true
            return
        }
        
        // Create credential for re-authentication
        let credential = EmailAuthProvider.credential(withEmail: userEmail, password: currentPassword)
        
        print("Re-authenticating user before email update...")
        
        currentUser.reauthenticate(with: credential) { result, error in
            DispatchQueue.main.async {
                if let error = error {
                    self.isLoading = false
                    self.alertTitle = "Authentication Error"
                    self.alertMessage = "Current password is incorrect. Please try again."
                    self.showingAlert = true
                    print("Re-authentication failed: \(error.localizedDescription)")
                    return
                }
                
                print("Re-authentication successful, updating email...")
                
                // Now update the email
                currentUser.updateEmail(to: self.email) { error in
                    DispatchQueue.main.async {
                        if let error = error {
                            self.isLoading = false
                            self.alertTitle = "Email Update Error"
                            self.alertMessage = "Failed to update email: \(error.localizedDescription)"
                            self.showingAlert = true
                            print("Email update failed: \(error.localizedDescription)")
                        } else {
                            print("Firebase email updated successfully")
                            // Update display name as well
                            self.updateDisplayName()
                        }
                    }
                }
            }
        }
    }
    
    private func updateDisplayName() {
        guard let currentUser = Auth.auth().currentUser else {
            updateProfileData()
            return
        }
        
        let changeRequest = currentUser.createProfileChangeRequest()
        changeRequest.displayName = fullName
        changeRequest.commitChanges { error in
            DispatchQueue.main.async {
                if let error = error {
                    print("Failed to update display name: \(error.localizedDescription)")
                } else {
                    print("Display name updated successfully")
                }
                // Continue with profile data update regardless
                self.updateProfileData()
            }
        }
    }
    
    private func updateProfileData() {
        userDataManager.updateUserProfile(fullName: fullName, email: email) { success, error in
            DispatchQueue.main.async {
                self.isLoading = false
                if success {
                    self.alertTitle = "Success"
                    self.alertMessage = "Profile updated successfully!"
                    print("Profile updated: Name=\(self.fullName), Email=\(self.email)")
                } else {
                    self.alertTitle = "Error"
                    self.alertMessage = error ?? "Failed to update profile"
                    print("Profile update failed: \(error ?? "Unknown error")")
                }
                self.showingAlert = true
            }
        }
    }
    
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
}

#Preview {
    EditProfileView()
        .environmentObject(AuthViewModel())
        .environmentObject(UserDataManager())
}
