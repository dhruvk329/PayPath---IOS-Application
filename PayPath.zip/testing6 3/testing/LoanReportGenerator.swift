import SwiftUI
import PDFKit
import UIKit

class LoanReportGenerator: ObservableObject {
    
    func generateComprehensiveReport(loans: [LoanData], userProfile: UserProfile?, completion: @escaping (Bool, String) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let pdfData = try self.createPDFReport(loans: loans, userProfile: userProfile)
                let fileName = "LoanReport_\(self.getCurrentDateString()).pdf"
                
                if self.savePDFToDocuments(data: pdfData, fileName: fileName) {
                    DispatchQueue.main.async {
                        completion(true, "Report generated successfully! Check 'My Reports' in your profile.")
                    }
                } else {
                    DispatchQueue.main.async {
                        completion(false, "Failed to save report")
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    completion(false, "Failed to generate report: \(error.localizedDescription)")
                }
            }
        }
    }
    
    private func createPDFReport(loans: [LoanData], userProfile: UserProfile?) throws -> Data {
        let pageRect = CGRect(x: 0, y: 0, width: 612, height: 792) // US Letter size
        
        let pdfData = NSMutableData()
        UIGraphicsBeginPDFContextToData(pdfData, pageRect, nil)
        
        var currentY: CGFloat = 50
        let margin: CGFloat = 50
        let contentWidth = pageRect.width - (margin * 2)
        
        // Page 1: Cover Page
        UIGraphicsBeginPDFPage()
        currentY = drawCoverPage(in: pageRect, userProfile: userProfile, currentY: currentY)
        
        // Page 2: Executive Summary with Charts
        UIGraphicsBeginPDFPage()
        currentY = 50
        currentY = drawExecutiveSummaryWithCharts(loans: loans, userProfile: userProfile, pageRect: pageRect, currentY: currentY)
        
        // Page 3: Portfolio Overview Chart
        UIGraphicsBeginPDFPage()
        currentY = 50
        currentY = drawPortfolioOverviewChart(loans: loans, pageRect: pageRect, currentY: currentY)
        
        // Page 4+: Individual Loan Details with Charts
        for (index, loan) in loans.enumerated() {
            UIGraphicsBeginPDFPage()
            currentY = 50
            currentY = drawLoanDetailsWithChart(loan: loan, index: index + 1, pageRect: pageRect, currentY: currentY)
        }
        
        // Final Page: Consolidated Strategy
        UIGraphicsBeginPDFPage()
        currentY = 50
        currentY = drawConsolidatedStrategy(loans: loans, pageRect: pageRect, currentY: currentY)
        
        UIGraphicsEndPDFContext()
        
        return pdfData as Data
    }
    
    private func drawCoverPage(in pageRect: CGRect, userProfile: UserProfile?, currentY: CGFloat) -> CGFloat {
        var y = currentY + 100
        let margin: CGFloat = 50
        let contentWidth = pageRect.width - (margin * 2)
        
        // Title
        let titleAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 32),
            .foregroundColor: UIColor.systemBlue
        ]
        let title = "Comprehensive Loan Report"
        let titleSize = title.size(withAttributes: titleAttributes)
        let titleRect = CGRect(x: (pageRect.width - titleSize.width) / 2, y: y, width: titleSize.width, height: titleSize.height)
        title.draw(in: titleRect, withAttributes: titleAttributes)
        y += titleSize.height + 40
        
        // Subtitle
        let subtitleAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 18),
            .foregroundColor: UIColor.darkGray
        ]
        let subtitle = "Financial Analysis & Strategic Recommendations"
        let subtitleSize = subtitle.size(withAttributes: subtitleAttributes)
        let subtitleRect = CGRect(x: (pageRect.width - subtitleSize.width) / 2, y: y, width: subtitleSize.width, height: subtitleSize.height)
        subtitle.draw(in: subtitleRect, withAttributes: subtitleAttributes)
        y += subtitleSize.height + 60
        
        // User Info
        if let profile = userProfile {
            let userInfoAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 16),
                .foregroundColor: UIColor.black
            ]
            
            let userInfo = """
            Prepared for: \(profile.fullName)
            Email: \(profile.email)
            Report Date: \(getCurrentDateString())
            Total Loans: \(profile.totalLoansCount)
            """
            
            let userInfoRect = CGRect(x: margin, y: y, width: contentWidth, height: 120)
            userInfo.draw(in: userInfoRect, withAttributes: userInfoAttributes)
            y += 120
        }
        
        // Disclaimer
        y += 100
        let disclaimerAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.italicSystemFont(ofSize: 12),
            .foregroundColor: UIColor.gray
        ]
        let disclaimer = """
        DISCLAIMER: This report is generated for informational purposes only. 
        Please consult with a qualified financial advisor before making any financial decisions.
        The strategies and recommendations provided are based on the information you have provided 
        and general financial principles.
        """
        
        let disclaimerRect = CGRect(x: margin, y: y, width: contentWidth, height: 80)
        disclaimer.draw(in: disclaimerRect, withAttributes: disclaimerAttributes)
        
        return y + 80
    }
    
    private func drawExecutiveSummaryWithCharts(loans: [LoanData], userProfile: UserProfile?, pageRect: CGRect, currentY: CGFloat) -> CGFloat {
        var y = currentY
        let margin: CGFloat = 50
        let contentWidth = pageRect.width - (margin * 2)
        
        // Section Title
        y = drawSectionTitle("Executive Summary", at: y, pageRect: pageRect)
        
        // Summary Stats
        let totalAmount = loans.reduce(0) { $0 + $1.totalAmount }
        let totalRemaining = loans.reduce(0) { $0 + $1.remainingAmount }
        let totalMonthlyPayment = loans.reduce(0) { $0 + $1.monthlyPayment }
        let totalPaid = totalAmount - totalRemaining
        
        let summaryText = """
        FINANCIAL OVERVIEW
        
        Total Loan Amount: \(formatCurrency(totalAmount))
        Amount Paid: \(formatCurrency(totalPaid))
        Remaining Balance: \(formatCurrency(totalRemaining))
        Monthly Payment Obligation: \(formatCurrency(totalMonthlyPayment))
        
        LOAN PORTFOLIO BREAKDOWN
        • Number of Active Loans: \(loans.count)
        • Average Interest Rate: \(String(format: "%.1f", loans.reduce(0) { $0 + $1.interestRate } / Double(loans.count)))%
        • Overall Progress: \(String(format: "%.1f", (totalPaid / totalAmount) * 100))%
        """
        
        let textAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 12),
            .foregroundColor: UIColor.black
        ]
        
        let textRect = CGRect(x: margin, y: y, width: contentWidth, height: 200)
        summaryText.draw(in: textRect, withAttributes: textAttributes)
        y += 220
        
        // Draw Progress Pie Chart
        y = drawProgressPieChart(totalPaid: totalPaid, totalRemaining: totalRemaining, at: y, pageRect: pageRect)
        
        return y
    }

    private func drawPortfolioOverviewChart(loans: [LoanData], pageRect: CGRect, currentY: CGFloat) -> CGFloat {
        var y = currentY
        let margin: CGFloat = 50
        let contentWidth = pageRect.width - (margin * 2)
        
        // Section Title
        y = drawSectionTitle("Portfolio Overview", at: y, pageRect: pageRect)
        
        // Draw Loan Distribution Chart
        y = drawLoanDistributionChart(loans: loans, at: y, pageRect: pageRect)
        y += 40
        
        // Draw Interest Rate Comparison Chart
        y = drawInterestRateChart(loans: loans, at: y, pageRect: pageRect)
        
        return y
    }

    private func drawLoanDetailsWithChart(loan: LoanData, index: Int, pageRect: CGRect, currentY: CGFloat) -> CGFloat {
        var y = currentY
        let margin: CGFloat = 50
        let contentWidth = pageRect.width - (margin * 2)
        
        // Loan Title
        y = drawSectionTitle("Loan #\(index): \(loan.name)", at: y, pageRect: pageRect)
        
        // Draw Individual Loan Progress Chart
        y = drawIndividualLoanChart(loan: loan, at: y, pageRect: pageRect)
        y += 40
        
        // Loan Details
        let progress = ((loan.totalAmount - loan.remainingAmount) / loan.totalAmount) * 100
        let monthsRemaining = Int(ceil(loan.remainingAmount / loan.monthlyPayment))
        
        let loanDetailsText = """
        LOAN INFORMATION
        Type: \(loan.loanType.rawValue)
        Original Amount: \(formatCurrency(loan.totalAmount))
        Remaining Balance: \(formatCurrency(loan.remainingAmount))
        Monthly Payment: \(formatCurrency(loan.monthlyPayment))
        Interest Rate: \(String(format: "%.1f", loan.interestRate))%
        Due Date: \(loan.dueDate)\(getOrdinalSuffix(loan.dueDate)) of each month
        Progress: \(String(format: "%.1f", progress))% complete
        Estimated Payoff: ~\(monthsRemaining) months
        
        AI STRATEGIC ANALYSIS
        \(generateLoanStrategy(for: loan))
        """
        
        let textAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 11),
            .foregroundColor: UIColor.black
        ]
        
        let textRect = CGRect(x: margin, y: y, width: contentWidth, height: 400)
        loanDetailsText.draw(in: textRect, withAttributes: textAttributes)
        
        return y + 400
    }

    private func drawProgressPieChart(totalPaid: Double, totalRemaining: Double, at y: CGFloat, pageRect: CGRect) -> CGFloat {
        let chartSize: CGFloat = 200
        let centerX = pageRect.width / 2
        let centerY = y + chartSize / 2
        let radius: CGFloat = 80
        
        guard let context = UIGraphicsGetCurrentContext() else { return y + chartSize + 40 }
        
        let total = totalPaid + totalRemaining
        let paidAngle = (totalPaid / total) * 2 * .pi
        
        // Draw Paid portion (Green)
        context.setFillColor(UIColor.systemGreen.cgColor)
        context.move(to: CGPoint(x: centerX, y: centerY))
        context.addArc(center: CGPoint(x: centerX, y: centerY), radius: radius, startAngle: 0, endAngle: paidAngle, clockwise: false)
        context.closePath()
        context.fillPath()
        
        // Draw Remaining portion (Orange)
        context.setFillColor(UIColor.systemOrange.cgColor)
        context.move(to: CGPoint(x: centerX, y: centerY))
        context.addArc(center: CGPoint(x: centerX, y: centerY), radius: radius, startAngle: paidAngle, endAngle: 2 * .pi, clockwise: false)
        context.closePath()
        context.fillPath()
        
        // Draw border
        context.setStrokeColor(UIColor.black.cgColor)
        context.setLineWidth(2)
        context.addArc(center: CGPoint(x: centerX, y: centerY), radius: radius, startAngle: 0, endAngle: 2 * .pi, clockwise: false)
        context.strokePath()
        
        // Add labels
        let titleAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 14),
            .foregroundColor: UIColor.black
        ]
        
        let labelAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 12),
            .foregroundColor: UIColor.black
        ]
        
        let title = "Overall Progress"
        let titleSize = title.size(withAttributes: titleAttributes)
        title.draw(at: CGPoint(x: centerX - titleSize.width/2, y: y - 20), withAttributes: titleAttributes)
        
        // Legend
        let legendY = centerY + radius + 20
        
        // Paid legend
        context.setFillColor(UIColor.systemGreen.cgColor)
        context.fill(CGRect(x: centerX - 80, y: legendY, width: 15, height: 15))
        
        let paidText = "Paid: \(formatCurrency(totalPaid))"
        paidText.draw(at: CGPoint(x: centerX - 60, y: legendY), withAttributes: labelAttributes)
        
        // Remaining legend
        context.setFillColor(UIColor.systemOrange.cgColor)
        context.fill(CGRect(x: centerX - 80, y: legendY + 20, width: 15, height: 15))
        
        let remainingText = "Remaining: \(formatCurrency(totalRemaining))"
        remainingText.draw(at: CGPoint(x: centerX - 60, y: legendY + 20), withAttributes: labelAttributes)
        
        return y + chartSize + 80
    }

    private func drawLoanDistributionChart(loans: [LoanData], at y: CGFloat, pageRect: CGRect) -> CGFloat {
        let chartHeight: CGFloat = 150
        let margin: CGFloat = 50
        let chartWidth = pageRect.width - (margin * 2)
        let barWidth = chartWidth / CGFloat(loans.count) - 10
        
        guard let context = UIGraphicsGetCurrentContext() else { return y + chartHeight + 40 }
        
        let titleAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 14),
            .foregroundColor: UIColor.black
        ]
        
        let title = "Loan Amount Distribution"
        let titleSize = title.size(withAttributes: titleAttributes)
        title.draw(at: CGPoint(x: (pageRect.width - titleSize.width)/2, y: y), withAttributes: titleAttributes)
        
        let chartStartY = y + 30
        let maxAmount = loans.map { $0.totalAmount }.max() ?? 1
        
        for (index, loan) in loans.enumerated() {
            let barHeight = (loan.totalAmount / maxAmount) * (chartHeight - 40)
            let x = margin + CGFloat(index) * (barWidth + 10)
            let barY = chartStartY + (chartHeight - 40) - barHeight
            
            // Draw bar
            context.setFillColor(UIColor.systemBlue.cgColor)
            context.fill(CGRect(x: x, y: barY, width: barWidth, height: barHeight))
            
            // Draw border
            context.setStrokeColor(UIColor.black.cgColor)
            context.setLineWidth(1)
            context.stroke(CGRect(x: x, y: barY, width: barWidth, height: barHeight))
            
            // Add loan name
            let labelAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 8),
                .foregroundColor: UIColor.black
            ]
            
            let loanName = loan.name.count > 8 ? String(loan.name.prefix(8)) + "..." : loan.name
            let labelSize = loanName.size(withAttributes: labelAttributes)
            loanName.draw(at: CGPoint(x: x + (barWidth - labelSize.width)/2, y: chartStartY + chartHeight - 20), withAttributes: labelAttributes)
            
            // Add amount
            let amount = formatCurrency(loan.totalAmount)
            let amountSize = amount.size(withAttributes: labelAttributes)
            amount.draw(at: CGPoint(x: x + (barWidth - amountSize.width)/2, y: chartStartY + chartHeight - 10), withAttributes: labelAttributes)
        }
        
        return y + chartHeight + 60
    }

    private func drawInterestRateChart(loans: [LoanData], at y: CGFloat, pageRect: CGRect) -> CGFloat {
        let chartHeight: CGFloat = 120
        let margin: CGFloat = 50
        let chartWidth = pageRect.width - (margin * 2)
        let barWidth = chartWidth / CGFloat(loans.count) - 10
        
        guard let context = UIGraphicsGetCurrentContext() else { return y + chartHeight + 40 }
        
        let titleAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 14),
            .foregroundColor: UIColor.black
        ]
        
        let title = "Interest Rate Comparison"
        let titleSize = title.size(withAttributes: titleAttributes)
        title.draw(at: CGPoint(x: (pageRect.width - titleSize.width)/2, y: y), withAttributes: titleAttributes)
        
        let chartStartY = y + 30
        let maxRate = loans.map { $0.interestRate }.max() ?? 1
        
        for (index, loan) in loans.enumerated() {
            let barHeight = (loan.interestRate / maxRate) * (chartHeight - 40)
            let x = margin + CGFloat(index) * (barWidth + 10)
            let barY = chartStartY + (chartHeight - 40) - barHeight
            
            // Color based on interest rate (red for high, green for low)
            let color = loan.interestRate > 7.0 ? UIColor.systemRed : (loan.interestRate > 4.0 ? UIColor.systemOrange : UIColor.systemGreen)
            
            // Draw bar
            context.setFillColor(color.cgColor)
            context.fill(CGRect(x: x, y: barY, width: barWidth, height: barHeight))
            
            // Draw border
            context.setStrokeColor(UIColor.black.cgColor)
            context.setLineWidth(1)
            context.stroke(CGRect(x: x, y: barY, width: barWidth, height: barHeight))
            
            // Add rate label
            let labelAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 10),
                .foregroundColor: UIColor.black
            ]
            
            let rateText = "\(String(format: "%.1f", loan.interestRate))%"
            let rateSize = rateText.size(withAttributes: labelAttributes)
            rateText.draw(at: CGPoint(x: x + (barWidth - rateSize.width)/2, y: chartStartY + chartHeight - 15), withAttributes: labelAttributes)
        }
        
        return y + chartHeight + 40
    }

    private func drawIndividualLoanChart(loan: LoanData, at y: CGFloat, pageRect: CGRect) -> CGFloat {
        let chartSize: CGFloat = 150
        let centerX = pageRect.width / 2
        let centerY = y + chartSize / 2
        let radius: CGFloat = 60
        
        guard let context = UIGraphicsGetCurrentContext() else { return y + chartSize + 40 }
        
        let paidAmount = loan.totalAmount - loan.remainingAmount
        let paidAngle = (paidAmount / loan.totalAmount) * 2 * .pi
        
        // Draw Paid portion (Green)
        context.setFillColor(UIColor.systemGreen.cgColor)
        context.move(to: CGPoint(x: centerX, y: centerY))
        context.addArc(center: CGPoint(x: centerX, y: centerY), radius: radius, startAngle: 0, endAngle: paidAngle, clockwise: false)
        context.closePath()
        context.fillPath()
        
        // Draw Remaining portion (Red)
        context.setFillColor(UIColor.systemRed.cgColor)
        context.move(to: CGPoint(x: centerX, y: centerY))
        context.addArc(center: CGPoint(x: centerX, y: centerY), radius: radius, startAngle: paidAngle, endAngle: 2 * .pi, clockwise: false)
        context.closePath()
        context.fillPath()
        
        // Draw border
        context.setStrokeColor(UIColor.black.cgColor)
        context.setLineWidth(2)
        context.addArc(center: CGPoint(x: centerX, y: centerY), radius: radius, startAngle: 0, endAngle: 2 * .pi, clockwise: false)
        context.strokePath()
        
        // Add center text
        let progressText = "\(String(format: "%.1f", (paidAmount / loan.totalAmount) * 100))%"
        let textAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 16),
            .foregroundColor: UIColor.black
        ]
        let textSize = progressText.size(withAttributes: textAttributes)
        progressText.draw(at: CGPoint(x: centerX - textSize.width/2, y: centerY - textSize.height/2), withAttributes: textAttributes)
        
        return y + chartSize + 20
    }
    
    private func drawSectionTitle(_ title: String, at y: CGFloat, pageRect: CGRect) -> CGFloat {
        let titleAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 18),
            .foregroundColor: UIColor.systemBlue
        ]
        
        let titleRect = CGRect(x: 50, y: y, width: pageRect.width - 100, height: 30)
        title.draw(in: titleRect, withAttributes: titleAttributes)
        
        // Draw underline
        let context = UIGraphicsGetCurrentContext()
        context?.setStrokeColor(UIColor.systemBlue.cgColor)
        context?.setLineWidth(1.0)
        context?.move(to: CGPoint(x: 50, y: y + 25))
        context?.addLine(to: CGPoint(x: pageRect.width - 50, y: y + 25))
        context?.strokePath()
        
        return y + 40
    }
    
    private func drawConsolidatedStrategy(loans: [LoanData], pageRect: CGRect, currentY: CGFloat) -> CGFloat {
        var y = currentY
        let margin: CGFloat = 50
        let contentWidth = pageRect.width - (margin * 2)
        
        // Section Title
        y = drawSectionTitle("Consolidated Financial Strategy", at: y, pageRect: pageRect)
        
        let strategy = generateConsolidatedStrategy(loans: loans)
        
        let textAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 11),
            .foregroundColor: UIColor.black
        ]
        
        let textRect = CGRect(x: margin, y: y, width: contentWidth, height: 600)
        strategy.draw(in: textRect, withAttributes: textAttributes)
        
        return y + 600
    }
    
    private func generateConsolidatedStrategy(loans: [LoanData]) -> String {
        let totalRemaining = loans.reduce(0) { $0 + $1.remainingAmount }
        let totalMonthly = loans.reduce(0) { $0 + $1.monthlyPayment }
        let highestInterestLoan = loans.max { $0.interestRate < $1.interestRate }
        
        return """
        DEBT AVALANCHE STRATEGY RECOMMENDATION
        
        🎯 PRIORITY RANKING (Pay minimums on all, extra on highest interest):
        \(loans.sorted { $0.interestRate > $1.interestRate }.enumerated().map { index, loan in
            "\(index + 1). \(loan.name) - \(String(format: "%.1f", loan.interestRate))% interest"
        }.joined(separator: "\n"))
        
        💰 FINANCIAL OPTIMIZATION PLAN
        
        Current Situation:
        • Total Monthly Obligation: \(formatCurrency(totalMonthly))
        • Total Remaining Debt: \(formatCurrency(totalRemaining))
        • Weighted Average Interest: \(String(format: "%.1f", loans.reduce(0) { $0 + ($1.interestRate * $1.remainingAmount) } / totalRemaining))%
        
        Recommended Actions:
        1. EMERGENCY FUND: Ensure 3-6 months expenses saved before aggressive payoff
        2. AVALANCHE METHOD: Focus extra payments on \(highestInterestLoan?.name ?? "highest interest loan")
        3. REFINANCING: Consider refinancing loans above 7% interest rate
        4. CONSOLIDATION: Evaluate consolidating multiple high-interest debts
        
        📊 PROJECTED SAVINGS SCENARIOS
        
        Scenario 1 - Extra $200/month to highest interest loan:
        • Interest Saved: ~\(formatCurrency(calculateInterestSavings(loans: loans, extraPayment: 200)))
        • Time Saved: ~6-12 months earlier payoff
        
        Scenario 2 - Extra $500/month to highest interest loan:
        • Interest Saved: ~\(formatCurrency(calculateInterestSavings(loans: loans, extraPayment: 500)))
        • Time Saved: ~12-24 months earlier payoff
        
        🚀 ADVANCED STRATEGIES
        
        • Bi-weekly Payments: Switch to bi-weekly payments (26 payments/year vs 12)
        • Windfall Allocation: Use tax refunds, bonuses for principal reduction
        • Side Income: Dedicate additional income streams to debt payoff
        • Balance Transfers: Consider 0% APR cards for high-interest debt
        
        📈 CREDIT SCORE OPTIMIZATION
        
        • Keep utilization below 30% on all accounts
        • Never miss minimum payments
        • Don't close old accounts after payoff
        • Monitor credit report monthly
        
        ⚠️ IMPORTANT REMINDERS
        
        • Review and update this strategy quarterly
        • Adjust for life changes (income, expenses)
        • Celebrate milestones to stay motivated
        • Consider professional financial advice for complex situations
        
        🎉 MOTIVATION
        
        You're on track to be debt-free! Stay consistent with payments and you'll achieve financial freedom sooner than you think. Every extra dollar toward principal saves you multiple dollars in interest.
        """
    }
    
    // Fixed generateLoanStrategy function using string-based approach
    private func generateLoanStrategy(for loan: LoanData) -> String {
        let progress = ((loan.totalAmount - loan.remainingAmount) / loan.totalAmount) * 100
        let monthsRemaining = Int(ceil(loan.remainingAmount / loan.monthlyPayment))
        
        var strategy = ""
        
        // Interest rate analysis
        if loan.interestRate > 8.0 {
            strategy += "🚨 HIGH PRIORITY: This loan has a high interest rate (\(String(format: "%.1f", loan.interestRate))%). Consider refinancing or making extra payments.\n\n"
        } else if loan.interestRate > 5.0 {
            strategy += "⚠️ MODERATE PRIORITY: Interest rate is moderate. Focus on this after paying off higher-rate debts.\n\n"
        } else {
            strategy += "✅ LOW PRIORITY: Low interest rate. Pay minimum while focusing on higher-rate debts.\n\n"
        }
        
        // Progress analysis
        if progress > 75 {
            strategy += "🎯 ALMOST THERE: You're \(String(format: "%.1f", progress))% complete! Consider making extra payments to finish strong.\n\n"
        } else if progress > 50 {
            strategy += "📈 GOOD PROGRESS: You're halfway there at \(String(format: "%.1f", progress))% complete. Keep up the momentum!\n\n"
        } else if progress > 25 {
            strategy += "🏃‍♂️ BUILDING MOMENTUM: \(String(format: "%.1f", progress))% complete. Stay consistent with payments.\n\n"
        } else {
            strategy += "🚀 GETTING STARTED: Early stages at \(String(format: "%.1f", progress))% complete. Focus on building good payment habits.\n\n"
        }
        
        // Specific recommendations based on loan type using string comparison
        strategy += "SPECIFIC RECOMMENDATIONS:\n"
        strategy += "• Estimated payoff in ~\(monthsRemaining) months with current payments\n"
        strategy += "• Extra $100/month could save ~\(monthsRemaining/4) months\n"
        strategy += "• Consider bi-weekly payments to reduce interest\n"
        
        // Use string-based comparison to avoid enum issues
        let loanTypeString = loan.loanType.rawValue.lowercased()
        
        if loanTypeString.contains("personal") {
            strategy += "• Personal loan: Focus on paying this off quickly due to typically higher rates\n"
        } else if loanTypeString.contains("home") || loanTypeString.contains("mortgage") {
            strategy += "• Home loan: Consider if extra payments align with other investment opportunities\n"
        } else if loanTypeString.contains("auto") || loanTypeString.contains("car") {
            strategy += "• Auto loan: Balance between loan payments and car maintenance savings\n"
        } else if loanTypeString.contains("education") || loanTypeString.contains("student") {
            strategy += "• Education loan: Check for income-driven repayment options if needed\n"
        } else if loanTypeString.contains("business") {
            strategy += "• Business loan: Ensure loan payments don't impact business cash flow\n"
        } else {
            strategy += "• Review loan terms and consider refinancing options if available\n"
        }
        
        return strategy
    }
    
    private func calculateInterestSavings(loans: [LoanData], extraPayment: Double) -> Double {
        // Simplified calculation - in reality this would be more complex
        let highestInterestLoan = loans.max(by: { $0.interestRate < $1.interestRate })
        guard let loan = highestInterestLoan else { return 0 }
        
        let monthlyRate = loan.interestRate / (12 * 100)
        let currentMonths = loan.remainingAmount / loan.monthlyPayment
        let newMonths = loan.remainingAmount / (loan.monthlyPayment + extraPayment)
        let monthsSaved = currentMonths - newMonths
        
        return monthsSaved * loan.monthlyPayment * 0.3 // Rough estimate
    }
    
    private func savePDFToDocuments(data: Data, fileName: String) -> Bool {
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            return false
        }
        
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        
        do {
            try data.write(to: fileURL)
            return true
        } catch {
            print("Error saving PDF: \(error)")
            return false
        }
    }
    
    private func getCurrentDateString() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        return formatter.string(from: NSNumber(value: amount)) ?? "$0"
    }
    
    private func getOrdinalSuffix(_ number: Int) -> String {
        switch number {
        case 1, 21, 31: return "st"
        case 2, 22: return "nd"
        case 3, 23: return "rd"
        default: return "th"
        }
    }
    
    private func getNextDueDate(from loans: [LoanData]) -> String {
        let today = Calendar.current.component(.day, from: Date())
        let upcomingDueDates = loans.map { $0.dueDate }.filter { $0 >= today }.sorted()
        
        if let nextDue = upcomingDueDates.first {
            return "\(nextDue)\(getOrdinalSuffix(nextDue)) of this month"
        } else if let earliestNext = loans.map { $0.dueDate }.min() {
            return "\(earliestNext)\(getOrdinalSuffix(earliestNext)) of next month"
        }
        return "Not available"
    }
}
