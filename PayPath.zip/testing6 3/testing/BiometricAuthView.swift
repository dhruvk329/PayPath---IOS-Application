import SwiftUI
import LocalAuthentication

struct BiometricAuthView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var isAuthenticating = false
    @State private var showingPasscodeOption = false

    var body: some View {
        VStack(spacing: 40) {
            VStack(spacing: 20) {
                Image(systemName: getBiometricIcon())
                    .font(.system(size: 80))
                    .foregroundColor(.blue)
                
                VStack(spacing: 8) {
                    Text("Secure Authentication")
                        .font(.title2)
                        .fontWeight(.semibold)
                    
                    Text("Use \(authViewModel.biometricAuthManager.biometricTypeString) to access your loan tracker")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
            }
            
            if authViewModel.biometricAuthManager.isAuthenticated {
                VStack(spacing: 15) {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 60))
                        .foregroundColor(.green)
                    Text("Authenticated!")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.green)
                }
            } else {
                VStack(spacing: 20) {
                    Button(action: {
                        authenticateWithBiometrics()
                    }) {
                        HStack {
                            if isAuthenticating {
                                ProgressView()
                                    .scaleEffect(0.8)
                                    .foregroundColor(.white)
                            }
                            Image(systemName: getBiometricIcon())
                            Text(isAuthenticating ? "Authenticating..." : "Authenticate with \(authViewModel.biometricAuthManager.biometricTypeString)")
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(.blue)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                        .font(.headline)
                    }
                    .disabled(isAuthenticating)
                    .padding(.horizontal)

                    if authViewModel.biometricAuthManager.authenticationError != nil {
                        VStack(spacing: 12) {
                            Text("Authentication failed")
                                .foregroundColor(.red)
                                .font(.subheadline)
                                .fontWeight(.medium)
                            
                            if let error = authViewModel.biometricAuthManager.authenticationError {
                                Text(error)
                                    .foregroundColor(.secondary)
                                    .font(.caption)
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal)
                            }
                            
                            Button("Use Passcode Instead") {
                                authenticateWithPasscode()
                            }
                            .foregroundColor(.blue)
                            .font(.subheadline)
                        }
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                        .padding(.horizontal)
                    }
                    
                    Button("Skip Authentication") {
                        authViewModel.biometricAuthManager.isAuthenticated = true
                    }
                    .foregroundColor(.secondary)
                    .font(.subheadline)
                }
            }
        }
        .padding()
        .onAppear {
            // Automatically attempt authentication when view appears
            if authViewModel.biometricAuthManager.canUseBiometrics {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    authenticateWithBiometrics()
                }
            }
        }
    }
    
    private func getBiometricIcon() -> String {
        return authViewModel.biometricAuthManager.biometricIcon
    }

    private func authenticateWithBiometrics() {
        guard !isAuthenticating else { return }
        
        isAuthenticating = true
        
        Task {
            let success = await authViewModel.biometricAuthManager.authenticateWithBiometrics()
            
            await MainActor.run {
                isAuthenticating = false
                if success {
                    print("✅ Biometric authentication successful")
                } else {
                    print("❌ Biometric authentication failed")
                }
            }
        }
    }
    
    private func authenticateWithPasscode() {
        guard !isAuthenticating else { return }
        
        isAuthenticating = true
        
        Task {
            let success = await authViewModel.biometricAuthManager.authenticateWithPasscode()
            
            await MainActor.run {
                isAuthenticating = false
                if success {
                    print("✅ Passcode authentication successful")
                } else {
                    print("❌ Passcode authentication failed")
                }
            }
        }
    }
}

struct BiometricAuthView_Previews: PreviewProvider {
    static var previews: some View {
        BiometricAuthView()
            .environmentObject(AuthViewModel())
    }
}
