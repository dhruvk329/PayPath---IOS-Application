import SwiftUI
import UserNotifications

struct NotificationSettingsView: View {
    @EnvironmentObject var userDataManager: UserDataManager
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) var colorScheme
    
    @State private var notificationsEnabled = false
    @State private var reminderDays = 3
    @State private var showingPermissionAlert = false
    @State private var animateElements = false
    
    let reminderOptions = [1, 2, 3, 5, 7, 10]
    
    private var backgroundGradient: LinearGradient {
        if colorScheme == .dark {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color.black,
                    Color(red: 0.05, green: 0.05, blue: 0.1),
                    Color(red: 0.1, green: 0.1, blue: 0.15)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        } else {
            return LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 0.98, green: 0.99, blue: 1.0),
                    Color(red: 0.95, green: 0.97, blue: 0.99),
                    Color(red: 0.92, green: 0.95, blue: 0.98)
                ]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                backgroundGradient
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Payment Reminders Section
                        paymentRemindersSection
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : -30)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.1), value: animateElements)
                        
                        // Info Section
                        infoSection
                            .opacity(animateElements ? 1.0 : 0.0)
                            .offset(y: animateElements ? 0 : 30)
                            .animation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.2), value: animateElements)
                    }
                    .padding()
                }
            }
            .navigationTitle("Notifications")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                    .foregroundColor(.blue)
                }
            }
            .onAppear {
                loadNotificationSettings()
                withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                    animateElements = true
                }
            }
            .alert("Notification Permission", isPresented: $showingPermissionAlert) {
                Button("Settings") {
                    openAppSettings()
                }
                Button("Cancel", role: .cancel) {
                    notificationsEnabled = false
                }
            } message: {
                Text("Please enable notifications in Settings to receive payment reminders.")
            }
        }
    }
    
    private var paymentRemindersSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeader(title: "Payment Reminders", icon: "bell.fill", color: .orange)
            
            VStack(spacing: 16) {
                // Enable Notifications Toggle
                HStack {
                    ZStack {
                        Circle()
                            .fill(LinearGradient(
                                gradient: Gradient(colors: [Color.orange, Color.orange.opacity(0.7)]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ))
                            .frame(width: 35, height: 35)
                            .shadow(color: Color.orange.opacity(0.3), radius: 3, x: 0, y: 2)
                        
                        Image(systemName: "bell")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.white)
                    }
                    
                    Text("Enable Notifications")
                        .font(.headline)
                        .fontWeight(.medium)
                    
                    Spacer()
                    
                    Toggle("", isOn: $notificationsEnabled)
                        .onChange(of: notificationsEnabled) { enabled in
                            if enabled {
                                requestNotificationPermission()
                            } else {
                                cancelAllNotifications()
                            }
                        }
                }
                
                if notificationsEnabled {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Remind me")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        
                        Picker("Reminder Days", selection: $reminderDays) {
                            ForEach(reminderOptions, id: \.self) { days in
                                Text("\(days) day\(days == 1 ? "" : "s") before")
                                    .tag(days)
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .onChange(of: reminderDays) { _ in
                            scheduleNotifications()
                        }
                    }
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
            .padding(20)
            .background(cardBackground)
        }
    }
    
    private var infoSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(LinearGradient(
                            gradient: Gradient(colors: [Color.blue, Color.blue.opacity(0.7)]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                        .frame(width: 35, height: 35)
                        .shadow(color: Color.blue.opacity(0.3), radius: 3, x: 0, y: 2)
                    
                    Image(systemName: "info.circle")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.white)
                }
                
                Text("About Notifications")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
            }
            
            Text("We'll send you reminders before your loan payments are due to help you stay on track.")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .padding(.leading, 47)
        }
        .padding(20)
        .background(cardBackground)
    }
    
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 15)
            .fill(.ultraThinMaterial)
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
            )
            .shadow(color: colorScheme == .dark ? Color.white.opacity(0.05) : Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
    }
    
    private func sectionHeader(title: String, icon: String, color: Color) -> some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(LinearGradient(
                        gradient: Gradient(colors: [color, color.opacity(0.7)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                    .frame(width: 35, height: 35)
                    .shadow(color: color.opacity(0.3), radius: 3, x: 0, y: 2)
                
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.white)
            }
            
            Text(title)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Spacer()
        }
    }
    
    private func loadNotificationSettings() {
        notificationsEnabled = UserDefaults.standard.bool(forKey: "notificationsEnabled")
        reminderDays = UserDefaults.standard.integer(forKey: "reminderDays")
        if reminderDays == 0 { reminderDays = 3 } // Default value
    }
    
    private func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            DispatchQueue.main.async {
                if granted {
                    UserDefaults.standard.set(true, forKey: "notificationsEnabled")
                    scheduleNotifications()
                } else {
                    notificationsEnabled = false
                    showingPermissionAlert = true
                }
            }
        }
    }
    
    private func scheduleNotifications() {
        guard notificationsEnabled else { return }
        
        // Cancel existing notifications
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        
        // Schedule new notifications for each loan
        for loan in userDataManager.loans {
            let content = UNMutableNotificationContent()
            content.title = "Payment Reminder"
            content.body = "Your \(loan.name) payment of \(formatCurrency(loan.monthlyPayment)) is due in \(reminderDays) day\(reminderDays == 1 ? "" : "s")"
            content.sound = .default
            
            // Calculate notification date (due date minus reminder days)
            var dateComponents = Calendar.current.dateComponents([.year, .month], from: Date())
            dateComponents.day = loan.dueDate - reminderDays
            
            // If the reminder date has passed this month, schedule for next month
            if let reminderDate = Calendar.current.date(from: dateComponents),
               reminderDate < Date() {
                dateComponents.month = (dateComponents.month ?? 1) + 1
            }
            
            let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
            let request = UNNotificationRequest(identifier: "loan-\(loan.id)", content: content, trigger: trigger)
            
            UNUserNotificationCenter.current().add(request)
        }
        
        UserDefaults.standard.set(reminderDays, forKey: "reminderDays")
    }
    
    private func cancelAllNotifications() {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        UserDefaults.standard.set(false, forKey: "notificationsEnabled")
    }
    
    private func openAppSettings() {
        if let settingsUrl = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(settingsUrl)
        }
    }
    
    private func formatCurrency(_ amount: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale.current
        return formatter.string(from: NSNumber(value: amount)) ?? "$0"
    }
}

#Preview {
    NotificationSettingsView()
        .environmentObject(UserDataManager())
}
