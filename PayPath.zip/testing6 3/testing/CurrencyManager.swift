import Foundation

class CurrencyManager: ObservableObject {
    @Published var selectedCurrency: Currency = .usd
    
    private let userDefaults = UserDefaults.standard
    private let currencyKey = "selectedCurrency"
    
    init() {
        loadSelectedCurrency()
    }
    
    func loadSelectedCurrency() {
        if let currencyCode = userDefaults.string(forKey: currencyKey),
           let currency = Currency.allCases.first(where: { $0.code == currencyCode }) {
            selectedCurrency = currency
            print("📱 Loaded currency from UserDefaults: \(currency.code)")
        }
    }
    
    func setSelectedCurrency(_ currencyCode: String) {
        if let currency = Currency.allCases.first(where: { $0.code == currencyCode }) {
            selectedCurrency = currency
            userDefaults.set(currency.code, forKey: currencyKey)
            print("💾 Saved currency to UserDefaults: \(currency.code)")
            
            // Post notification for currency change
            NotificationCenter.default.post(name: .currencyDidChange, object: currency)
        }
    }
    
    func updateCurrency(_ currency: Currency) {
        print("🔄 CurrencyManager updating to: \(currency.code)")
        selectedCurrency = currency
        userDefaults.set(currency.code, forKey: currencyKey)
        
        // Post notification for currency change
        NotificationCenter.default.post(name: .currencyDidChange, object: currency)
        print("✅ CurrencyManager update completed")
    }
    
    func formatCurrency(_ amount: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = selectedCurrency.code
        formatter.locale = selectedCurrency.locale
        return formatter.string(from: NSNumber(value: amount)) ?? "\(selectedCurrency.symbol)0"
    }
}

// Notification for currency changes
extension Notification.Name {
    static let currencyDidChange = Notification.Name("currencyDidChange")
}

enum Currency: String, CaseIterable {
    case usd = "USD"
    case eur = "EUR"
    case gbp = "GBP"
    case jpy = "JPY"
    case cad = "CAD"
    case aud = "AUD"
    case chf = "CHF"
    case cny = "CNY"
    case inr = "INR"
    case krw = "KRW"
    case sgd = "SGD"
    case hkd = "HKD"
    case nzd = "NZD"
    case sek = "SEK"
    case nok = "NOK"
    case mxn = "MXN"
    case brl = "BRL"
    case rub = "RUB"
    case zar = "ZAR"
    case try_ = "TRY"
    
    var code: String {
        switch self {
        case .try_: return "TRY"
        default: return rawValue
        }
    }
    
    var name: String {
        switch self {
        case .usd: return "US Dollar"
        case .eur: return "Euro"
        case .gbp: return "British Pound"
        case .jpy: return "Japanese Yen"
        case .cad: return "Canadian Dollar"
        case .aud: return "Australian Dollar"
        case .chf: return "Swiss Franc"
        case .cny: return "Chinese Yuan"
        case .inr: return "Indian Rupee"
        case .krw: return "South Korean Won"
        case .sgd: return "Singapore Dollar"
        case .hkd: return "Hong Kong Dollar"
        case .nzd: return "New Zealand Dollar"
        case .sek: return "Swedish Krona"
        case .nok: return "Norwegian Krone"
        case .mxn: return "Mexican Peso"
        case .brl: return "Brazilian Real"
        case .rub: return "Russian Ruble"
        case .zar: return "South African Rand"
        case .try_: return "Turkish Lira"
        }
    }
    
    var symbol: String {
        switch self {
        case .usd, .cad, .aud, .nzd, .sgd, .hkd, .mxn: return "$"
        case .eur: return "€"
        case .gbp: return "£"
        case .jpy, .cny: return "¥"
        case .chf: return "CHF"
        case .inr: return "₹"
        case .krw: return "₩"
        case .sek, .nok: return "kr"
        case .brl: return "R$"
        case .rub: return "₽"
        case .zar: return "R"
        case .try_: return "₺"
        }
    }
    
    var locale: Locale {
        switch self {
        case .usd: return Locale(identifier: "en_US")
        case .eur: return Locale(identifier: "en_EU")
        case .gbp: return Locale(identifier: "en_GB")
        case .jpy: return Locale(identifier: "ja_JP")
        case .cad: return Locale(identifier: "en_CA")
        case .aud: return Locale(identifier: "en_AU")
        case .chf: return Locale(identifier: "de_CH")
        case .cny: return Locale(identifier: "zh_CN")
        case .inr: return Locale(identifier: "en_IN")
        case .krw: return Locale(identifier: "ko_KR")
        case .sgd: return Locale(identifier: "en_SG")
        case .hkd: return Locale(identifier: "en_HK")
        case .nzd: return Locale(identifier: "en_NZ")
        case .sek: return Locale(identifier: "sv_SE")
        case .nok: return Locale(identifier: "nb_NO")
        case .mxn: return Locale(identifier: "es_MX")
        case .brl: return Locale(identifier: "pt_BR")
        case .rub: return Locale(identifier: "ru_RU")
        case .zar: return Locale(identifier: "en_ZA")
        case .try_: return Locale(identifier: "tr_TR")
        }
    }
}
